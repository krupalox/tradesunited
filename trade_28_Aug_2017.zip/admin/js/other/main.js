$(document).ready(function() {

	$("#passchange").click(function(event)
	{
   $( ".passtohide" ).toggle();
   return false;
 });

 
  $("#alert").click(function()
  {
    $("#alert").fadeOut("slow");
  });
	$("#alert").hover(function(event)
	{
    $(this).fadeOut("slow");
  });
$("#datatable tbody").click(function(event)
{
  if ($(event.target.parentNode).hasClass('row_selected'))
  {
    $(event.target.parentNode).removeClass('row_selected');
  }
  else
  {
    $(event.target.parentNode).addClass('row_selected');
  }
});
$(".reload").click(function(event)
{
 oTable.fnDraw(false);
});

});

function validateRemove(id,adrs)
{
  $confirm= confirm("Are you sure you want to delete this?");
  if($confirm==true)
  {
    var keys =[];
    keys.push(id);
    var form_data = { rows:keys }
    $.ajax({
      url: BASEURL+adrs,
      type: 'POST',
      data:  form_data,
      success: function(output_string){
        if (output_string=='1')
        {
          $("#"+id).remove();
        }
        else
        {
          $("#divtoappend").append('<div id="alert"><div class="alert alert-danger center">Please try after some time</div></div>');
        }
      }
    });
  }
  else
  {
    return false;
  }
}

function deleteerows(adrs)
{
  $confirm= confirm("Are you sure you want to delete this?");
  if($confirm==true)
  {
    var keys =[];
    var anSelected = fnGetSelected( oTable );
    $.each(anSelected, function(index, val)
    {
      keys.push($(val).attr('id'));
    });
    var form_data = { rows:keys }
    $.ajax(
    {
      url: BASEURL+adrs,
      type: 'POST',
      data:  form_data,
      success: function(output_string)
      {
        if (output_string=='1')
        {
          $(anSelected).remove();
        }
        else
        {
          $("#divtoappend").append('<div class="alert alert-block alert-danger fade in col-sm-12 borderradius0">Please try after some time<a class="close" data-dismiss="alert" href="#" aria-hidden="true">×</a></div>');

        }
      }
    });
  }
  else{
    return false;
  }
}

function fnGetSelected( oTableLocal )
{
  return oTableLocal.$('tr.row_selected');
}

// main datatable function
function initializeDatatableMain(tableId,paginateAdrs,exportAdrs,deleteAllAdrs,changeStatusAllAdrs,columnsObj,columnDefsObj,orderColumn)
{
   if(orderColumn == '') {
    orderColumn = 0;
  }
  
   table = $('#'+tableId).DataTable({
    responsive: true,
    processing: true,
    serverSide: true,
    //bSort: true,
    ajax:{
      url : BASEURL+paginateAdrs,
      type : "POST"
    },
    columns:columnsObj,
    columnDefs:columnDefsObj,
	
	order: [[ orderColumn['no'], orderColumn['order'] ]],
	
    oLanguage: {
                sProcessing: "<img src=" + BASEURL + "/images/common/35.GIF width=25 height=25 />"
    },

    "fnDrawCallback": function () {
      // $(".fancy_box").fancybox({
      // 'width' : '80%',
      // 'height'  : '60%',
      // 'autoScale' : false,
      // 'type'  : 'iframe'
      // });

        $('a.fancy_box').fancybox({
        helpers : {
         title: { type: 'inside'}
        },
        afterLoad: function(){
         this.title = $(this.element).attr('data-caption');
        }
       });
    }
  });

  $(".dataTables_filter input")
    .unbind() // Unbind previous default bindings
    .bind("keyup", function(e) { // Bind our desired behavior
        // If the length is 3 or more characters, or the user pressed ENTER, search
        if(this.value.length >= 3 || e.keyCode == 13) {
            // Call the API search function
            table.search(this.value).draw();
        }
        // Ensure we clear the search if they backspace far enough
        if(this.value == "") {
            table.search("").draw();
        }
        return;
    });

  $('#'+tableId+' tbody').on( 'click', 'tr', function (e) {
    $(this).toggleClass('selected');

  });

  var btnArr = [ ];
    if(exportAdrs!=''){
    var addArr = {
                text: 'Export CSV',
                className:'btn-info btn-sm',
                action: function ( e, dt, node, conf ) {
                  // csv ajax call
                  document.location = BASEURL+exportAdrs;
                  return false;
                }
                };
    btnArr.push(addArr);
  }
 
 if(deleteAllAdrs != ''){
    var addArr = [{
                  text: 'Delete',
                  className:'btn-danger btn-sm',
                  action: function ( e, dt, node, conf ) {
                  //delete ajax
                  deleteAll(tableId,deleteAllAdrs);
                }
               }, {
      text: 'Select all',
      className:'btn-primary btn-sm',
      action: function ( e, dt, node, conf ) {
        $('#'+tableId+' tbody tr').addClass('selected');
      }
    },
    {
      text: 'Deselect all',
      className:'btn-sm',
      action: function ( e, dt, node, conf ) {
        $('#'+tableId+' tbody tr').removeClass('selected');
      }
    }];
      btnArr.push(addArr);
  }

   if(changeStatusAllAdrs!=''){
    var addArr = {
                  text: 'Active/Inactive',
                  className:'btn-success btn-sm',
                  action: function ( e, dt, node, conf ) {
                    // status toggle ajax
                    changeStatusAll(tableId,changeStatusAllAdrs);
                  }
                };
      btnArr.push(addArr);
  }


  new $.fn.dataTable.Buttons( table, {
    buttons: btnArr
} );

  table.buttons( 0, null ).container().appendTo('#'+tableId+'_wrapper .row:eq(0) > .col-sm-6:eq(0)');
  $('.dataTables_length').parent().removeClass('col-sm-6').addClass('col-sm-9');
  $('.dataTables_filter').parent().removeClass('col-sm-6').addClass('col-sm-3');
  $('.dt-buttons').removeClass('btn-group').find('.btn').addClass('marginleftright');
}

function changeStatus(id,event,tableId,controllerName) {
  alertify.confirm('Status', 
    'Are you sure want to change status ?', function(){ 
      $.ajax(
          {
            url: BASEURL +controllerName+'/status/'+id,
            type: 'POST',
            success: function(output_string)
            {
              if (output_string!='')
              {
                table.draw();
                alertify.success('Status changed') 
              }
              else
              {
                table.draw( false );
                alertify.error('Status not changed') 
              }
            }
          });
    event.stopPropagation();
    }, function(){
  });
}

function changegroupEventStatus(id,event,tableId,controllerName){
    alertify.confirm('Status', 
    'Are you sure want to change status ?', function(){ 
      $.ajax(
          {
            url: BASEURL +controllerName+'/'+id,
            type: 'POST',
            success: function(output_string)
            {
              if (output_string!='')
              {
                table.draw();
                alertify.success('Status changed') 
              }
              else
              {
                table.draw( false );
                alertify.error('Status not changed') 
              }
            }
          });
    event.stopPropagation();
    }, function(){
  });
}



function deleteOne(id,event,tableId,controllerName,type="") {
    alertify.confirm('Delete', 
    'Are you sure want to delete this ?', function(){ 
        var urlsrc= BASEURL+'/'+controllerName+'/remove/'+id;
        $.ajax(
        {
          url: urlsrc,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
              alertify.success('Deleted.') 
              table.draw();
            }
            else
            {
              alertify.error('Not deleted') 
            }
          }
        });
      event.stopPropagation();
    }, function(){
  });
}

function deletegroupEvent(id,event,tableId,controllerName) {
  alertify.confirm('Delete', 
    'Are you sure want to delete this ?', function(){ 
        var urlsrc= BASEURL+'/'+controllerName+'/'+id;
        $.ajax(
        {
          url: urlsrc,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
              alertify.success('Deleted.') 
              table.draw();
            }
            else
            {
              alertify.error('Not deleted') 
            }
          }
        });
      event.stopPropagation();
    }, function(){
  });
}


function deleteReportedPost(id,post_id,event,tableId,controllerName,type=""){
    $('#confirmModal').find('#innerText').text('');
    $('#confirmModal').find('#innerText').text('Are you sure you want to delete this?');
    $('#confirmModal').modal('show');
    $('#deleteRecordOk').unbind().click(function() {
      var urlsrc= BASEURL+'/'+controllerName+'/removeReportedPost/'+id+'/'+post_id;
    $.ajax(
    {
      
      url: urlsrc,
      
      type: 'POST',
      success: function(output_string)
      {
        if (output_string)
        {
          table.draw();
        }
        else
        {
          alert('Please try again after some time.');
          
        }
        $('#confirmModal').modal('hide');
      }
    });
    event.stopPropagation();
  });
}

function deleteReportedUser(id,to_user_id,event,tableId,controllerName,type=""){
    $('#confirmModal').find('#innerText').text('');
    $('#confirmModal').find('#innerText').text('Are you sure you want to delete this?');
    $('#confirmModal').modal('show');
    $('#deleteRecordOk').unbind().click(function() {
      var urlsrc= BASEURL+'/'+controllerName+'/removeReportedUser/'+id+'/'+to_user_id;
    $.ajax(
    {
      
      url: urlsrc,
      
      type: 'POST',
      success: function(output_string)
      {
        if (output_string)
        {
          table.draw();
        }
        else
        {
          alert('Please try again after some time.');
          
        }
        $('#confirmModal').modal('hide');
      }
    });
    event.stopPropagation();
  });
}


function deleteAll(tableId,deleteAllAdrs){
  var keys =[];
  var rows = $('#'+tableId+' tbody tr.selected');
  $.each(rows, function()
  {
    keys.push(parseInt($(this).attr('id')));
  });
    if(keys.length === 0) {
        alertify.alert("Confirmation","Please select at least one record.", function(){
          //return false;
        });
    }
    else
    {
      alertify.confirm('Status', 
      'Are you sure want to delete this records ?', function(){ 
          var form_data =
          {
            rows:keys
          }
          $.ajax(
          {
            url: BASEURL+deleteAllAdrs,
            type: 'POST',
            data:  form_data,
            success: function(output_string)
            {
              if (output_string=='1')
              {
                table.draw();
                alertify.success('Recors deleted.');
              }
              else
              {
                alert(output_string);
                alertify.error('Recors not deleted!.');
                table.draw( false );
              }
            }
          });
      }, function(){

      });
    }
}

  function changeStatusAll(tableId,changeStatusAllAdrs) {
      var keys =[];
      var rows = $('#'+tableId+' tbody tr.selected');
      $.each(rows, function()
      {
        keys.push(parseInt($(this).attr('id')));
      });
      if(keys.length === 0){
        alertify.alert("Confirmation","Please select at least one record.", function(){
         //table.draw( false );
        });
         return false;
      }
      else
      {
         alertify.confirm('Status', 
          'Are you sure want to change status ?', function() { 
          var form_data =
          {
            rows:keys
          }

            $.ajax(
            {
              url: BASEURL+changeStatusAllAdrs,
              type: 'POST',
              data:  form_data,
              success: function(output_string) {
                $('#confirmModal').modal('hide');
                if (output_string=='1')
                {
                  table.draw();
                  alertify.success('Status changed') 
                }
                else
                {
                  table.draw( false );
                  alertify.error('Status not changed') 
                }
              }
            });
        }, function(){
      });
    }
  }

  function viewDetails(id,event,tableId,controllerName){

        $('#waitingModal').modal('show');
        $.ajax(
        {
          url: BASEURL+'/'+controllerName+'/getDetails/'+id,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
               $('#waitingModal').modal('hide');
               $('#myModal').find('.modal-title').html('User\'s Detail');
               $('#myModal').find('.modal-body').html('');
               $('#myModal').find('.modal-body').html(output_string);
               $('#myModal').modal('show');              
            }
            else
            {
              alert('Please try again after some time.');
              table.draw( false );
            }
            event.stopPropagation();
          }
        });
       event.stopPropagation();
    }
    function viewGroupMembers(id,event,tableId,controllerName,name,admin_id){
        $('#waitingModal').modal('show');
        $.ajax(
        {
          url: BASEURL+'/'+controllerName+'/viewGroupMembers/'+id+'/'+admin_id,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
               $('#waitingModal').modal('hide');
               $('#myModal').find('.modal-title').html(decodeURIComponent(name)+' member list');
               $('#myModal').find('.modal-body').html('');
               $('#myModal').find('.modal-body').html(output_string);
               $('#myModal').modal('show');              
            }
            else
            {
              alert('Please try again after some time.');
              table.draw( false );
            }
            event.stopPropagation();
          }
        });
       event.stopPropagation();
    }
    function viewEventDetails(id,event,tableId,controllerName){
        $('#waitingModal').modal('show');
        $.ajax(
        {
          url: BASEURL+'/'+controllerName+'/viewEventDetails/'+id,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
               $('#waitingModal').modal('hide');
               $('#myModal').find('.modal-title').html('Event details');
               $('#myModal').find('.modal-body').html('');
               $('#myModal').find('.modal-body').html(output_string);
               $('#myModal').modal('show');              
            }
            else
            {
              alert('Please try again after some time.');
              table.draw( false );
            }
            event.stopPropagation();
          }
        });
       event.stopPropagation();
    }
    function viewUserQuestions(id,event,tableId,controllerName){
      $('#waitingModal').modal('show');
        $.ajax(
        {
          url: BASEURL+'/'+controllerName+'/viewUserQuestions/'+id,
          type: 'POST',
          success: function(output_string)
          {
            if (output_string)
            {
               $('#waitingModal').modal('hide');
               $('#myModal').find('.modal-title').html('User Question details');
               $('#myModal').find('.modal-body').html('');
               $('#myModal').find('.modal-body').html(output_string);
               $('#myModal').modal('show');              
            }
            else
            {
              alert('Please try again after some time.');
              table.draw( false );
            }
            event.stopPropagation();
          }
        });
       event.stopPropagation();      
    }


  