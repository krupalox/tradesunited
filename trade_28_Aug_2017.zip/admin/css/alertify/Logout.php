<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
@Openxcell
@Amit Kumar Varshney
@Pathik Vejani
**/
require(APPPATH.'/libraries/REST_Controller.php');
class Logout extends REST_Controller
{
	var $client;

	protected $methods = array(
		'index_post' => array('level' => 10, 'limit' => 10000000),
		);

	public function __construct()
	{
		parent::__construct();
		if (!checkmac())
		{
			$row = array("MESSAGE"=>"You are not authorize to use this service","SUCCESS" =>'0');
			$this->response($row, 401);
		}
		$this->load->model('admin_model');
	}

	/**
	  This function is for logout the user
	 */
	public function index_post()
	{
		$postData =$this->post();
		if (checkparams($postData,array('iUserID')))
		{
			$logout = $this->admin_model->logout($postData);
			if($logout)
			{
				$row = array("MESSAGE" => "You are successfully logged out.","SUCCESS" => '1');
				$this->response($row,200);
			}
			else
			{
				$row = array("MESSAGE" => "Some error occurred...Please try again!!!","SUCCESS" => '0');
				$this->response($row,200);
			}
		}
		else
		{
			$row = array("MESSAGE"=>"Insufficient Data","SUCCESS" =>'0');
			$this->response($row, 200);
		}
	}

}
/* End of file profile.php */