<html>
   <head>
      <title>Connecting MySQL Server</title>
   </head>
   <body>
      <?php
         $dbhost = 'localhost';
		 //$servername = "13.54.42.201";
          $dbuser = 'root';
         $dbpass = 'ordertest123';
         $conn = mysql_connect($dbhost, $dbuser, $dbpass);
         if(! $conn ) {
            die('Could not connect: ' . mysql_error());
         }
         echo 'Connected successfully';
 		 
 		 
	  $sql = 'SELECT * FROM tbl_user';
	
	   mysql_select_db('tradesUnit');
	   $retval = mysql_query( $sql, $conn );
	   
	   if(! $retval ) {
		  die('Could not get data: ' . mysql_error());
	   }
	   
	   while($row = mysql_fetch_array($retval, MYSQL_NUM)) {
		  echo "KEY :{$row[1]}  <br> ".
  			 "Value: {$row[2]} <br> ".
			 "--------------------------------<br>";
	   }
	   echo "Fetched data successfully\n";
	   mysql_close($conn);
   
   
   
      ?>
   </body>
</html>