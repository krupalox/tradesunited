<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logbook extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Logbook_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"Logbook");
        $viewData['type'] = base64_decode($type);
        $this->load->view('Logbook/logbook_view',$viewData);
    }


	/*$result = $this->db->query("SELECT ul.iLogID,
     									FROM_UNIXTIME(ul.iStartDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iStartDatetimeUnix,
     									FROM_UNIXTIME(ul.iEndDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iEndDatetimeUnix,
										ul.vStartArea as vStartArea,
    									ul.vEndArea as vEndArea,
    									ul.vStartAddress,
        								if(ul.eCompleted = 'Yes', CONCAT(if(u.eDistance = 'Km', if(ul.dDistance= '0','0.00',ul.dDistance), if(ul.dDistance= '0','0.00',ul.dDistance_mile)),' ',UPPER(u.eDistance)),'' ) as dDistance,
    									if(ul.eCompleted = 'Yes', ul.vEndAddress,'' ) as vEndAddress,
    									ul.eCompleted
    									FROM tbl_user_log ul 
    									LEFT JOIN tbl_user u
    									ON u.iUserID = ul.iUserID
    									WHERE ul.iUserID = $iUserID 
    									ORDER BY ul.iLogID DESC
     								 ");*/
		
		
		
    function datatable_source()
    {
		/* ul.dDate,
		ul.tStartTime,
		ul.tEndTime, 
 
		DATE_FORMAT(ul.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
 		*/
 		
        $this->datatables->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vFullName,
									ul.vStartAddress,
									if(ul.eCompleted = 'Yes', ul.vEndAddress,'' ) as vEndAddress,
                               		if(ul.eCompleted = 'Yes', CONCAT(if(u.eDistance = 'Km', if(ul.dDistance= '0','0.00',ul.dDistance), if(ul.dDistance= '0','0.00',ul.dDistance_mile)),' ',UPPER(u.eDistance)),'' ) as dDistance,
									FROM_UNIXTIME(ul.iStartDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as tStartTime,
									FROM_UNIXTIME(ul.iEndDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as tEndTime,
                                    ul.vDuration,
                                     ul.dtCreated as dtCreated_default,
                                    ul.iLogID,
                                    ul.iLogID as DT_RowId",false);
        $this->datatables->from('tbl_user_log as ul');
        $this->datatables->join('tbl_user u','u.iUserID = ul.iUserID','LEFT');
        echo  $this->datatables->generate('json');
    }

    // function datatable_source_export($name) {
    //     $this->datatables->select("CONCAT(u.vFirstName,' ',u.vLastName) as vFullName,
    //                                 ul.dDate,
    //                                 ul.tStartTime,
    //                                 ul.vStartAddress,
    //                                 ul.tEndTime,
    //                                 ul.vEndAddress,
    //                                 ul.dDistance,
    //                                 DATE_FORMAT(ul.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated",false);
    //     $this->db->from('tbl_user_log as ul');
    //     $this->db->join('tbl_user u','u.iUserID = ul.iUserID','LEFT');
    //     $this->db->order_by('ul.dtCreated','desc');
    //     $query = $this->db->get();
    //     $data = $this->load->helper('csv');
    //     $name .= "(".date('Y-m-d').").csv";
    //     query_to_csv($query,true,$name);
    // }

    // function deleteAll()
    // {
    //     mprd($_POST['rows']);
    //     $data = $_POST['rows'];
    //     $removeUser = $this->User_model->removeUserAll($_POST['rows']);
    //     if($removeUser != '') {
    //         echo '1';
    //     } else {
    //         echo '0';
    //     }
    // }

    // function changeStatusAll()
    // {
    //     $data = $_POST['rows'];
    //     if(!empty($data)){
    //         foreach ($data as $key => $value) {
    //             $this->User_model->changeUserStatus($value);
    //         }
    //         echo '1';
    //     }else{
    //         echo '0';
    //     }
    // }

    // function status($id) {
    //     if($id != '') {
    //         $changstatus = $this->User_model->changeUserStatus($id);
    //         if($changstatus != '') {
    //             echo USER_EDITED;
    //         } else {
    //             echo USER_NOT_EDITED;
    //         }
    //     }
    //     else {
    //         echo '';
    //     }
    // }

    // function remove($id) {
    //     if($id != '') {
    //         $removeUser = $this->User_model->removeUser($id);
    //         if($removeUser != '') {
    //             echo 1;
    //         }
    //         else {
    //             echo 0;
    //         }
    //     }
    //     exit;
    // }
    
}