<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	var $viewData = array();
	function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model');
	}
	
	function index()
	{
		$data['title']= "Dashboard";
		$data['total_admin'] = $this->Dashboard_model->getTotalAdmin();	
		$data['total_user'] = $this->Dashboard_model->getTotalUsers();	
		$data['total_TradeCategory'] = $this->Dashboard_model->getTotalCategories();	
		$data['total_postCategory'] = $this->Dashboard_model->getTotalPostCat();	
		$data['total_expensecategory'] = $this->Dashboard_model->getTotalExpenseCate();	
		$data['total_Userpost'] = $this->Dashboard_model->getTotalUserPost();	
		$data['total_logbook'] = $this->Dashboard_model->getTotalLoogbook();	

		$this->load->view('dashboard/dashboard_view',$data);
	}
}