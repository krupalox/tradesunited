<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Expensecategory extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Expensecat_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"User");
        $viewData['type'] = base64_decode($type);
        $this->load->view('Expensecategory/ecategory_view',$viewData);
    }

    function datatable_source()
    {
        $this->datatables->select(" ec.vCatName as vCatName,
                                    DATE_FORMAT(ec.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    ec.eStatus,
                                    ec.iExpenseCateID as iExpenseCateID,
                                    ec.iExpenseCateID as DT_RowId",false);
        $this->datatables->where('ec.eIsDeleted','no');
        $this->datatables->from('tbl_expense_category as ec');
        echo  $this->datatables->generate('json');
    }

    function datatable_source_export($name) {
        $this->datatables->select(" ec.iExpenseCateID as iExpenseCateID,
                                    ec.vCatName as vCatName,
                                    DATE_FORMAT(ec.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    ec.eStatus",false);
        $this->db->where('ec.eIsDeleted','no');
        $this->db->from('tbl_expense_category as ec');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }

    function deleteAll()
    {
        $data = $_POST['rows'];
        $removeUser = $this->Expensecat_model->removeUserAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

     function remove($id) {
        if($id != '') {
            $removeUser = $this->Expensecat_model->removeUser($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->Expensecat_model->changeUserStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function status($id) {
        if($id != '') {
            $changstatus = $this->Expensecat_model->changeUserStatus($id);
            if($changstatus != '') {
                echo USER_EDITED;
            } else {
                echo USER_NOT_EDITED;
            }
        }
        else {
            echo '';
        }
    }

   

    function add($id='',$ed='')
    {   
        if($id!='' && $ed !='' && $ed == 'y')
        {   $id =  base64_decode($id);
            $getData = $this->Expensecat_model->getpCatDataById($id);
            $viewData['getUserData'] = $getData;
            $viewData['title'] =    "Expense Category Edit";
            $viewData['ACTION_LABEL'] = "Edit";
        }else{
            $viewData['title'] =    "Expense Category Add";
            $viewData['ACTION_LABEL'] = "Add";
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminadd')
        {
            if($this->Expensecat_model->checkCatAvailable($this->input->post('vCatName')))
            {
                $adminAdd = $this->Expensecat_model->addPcat($_POST);
                if($adminAdd != '')
                {
                    $succ = array('0' => ECAT_ADDED);
                    $this->session->set_userdata('SUCCESS',$succ);

                }else{
                    $err = array('0' => ECAT_NOT_ADDED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => ECAT_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('Expensecategory');
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminedit')
        {   
            if($this->Expensecat_model->checkCatAvailable($this->input->post('vCatName'),$this->input->post('id')))
            {  
                $adminEdit = $this->Expensecat_model->editPcat($_POST);
                if($adminEdit != '')
                {
                    $succ = array('0' => ECAT_EDITED);
                    $this->session->set_userdata('SUCCESS',$succ);
                }
                else
                {
                    $err = array('0' => ECAT_NOT_EDITED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => ECAT_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('Expensecategory');
        }
        $this->load->view('Expensecategory/ecategory_add_edit',$viewData);
    }
    
}