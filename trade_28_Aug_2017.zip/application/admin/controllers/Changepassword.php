<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Changepassword extends CI_Controller
{
	function __construct()
	{
		 parent::__construct();
		 $_POST = request_clean($_POST);  
	}

	function index()
	{
		$data = array('title'=>'Change Password');

		if($this->input->post('oldpassword') && $this->input->post('password'))
		{
				$checkPassword = $this->Admin_model->checkOldPassword();
				if($checkPassword == 1)
				{
					$updatePassword = $this->Admin_model->changePassword();

					if($updatePassword)
					{
						$succ = array('0' => PASSWORD_CHANGED);
						$this->session->set_userdata('SUCCESS',$succ);
					}else{
						$err = array('0' => PASSWORD_CHANGED);
						$this->session->set_userdata('SUCCESS',$err);
					}
				}
				else
				{
					$err = array('0' => OLD_PASSWORD_NOT_OK);
					$this->session->set_userdata('ERROR',$err);
				}
		}

		$this->load->view('changepassword/changepassword_view',$data);
  	}
  	public function checkpass()
  	{
		if($this->Admin_model->checkOldPassword())
			echo "true";
		else
			echo "false";

  	}
}
