<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactus extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Contactus_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
         $viewData   =   array("title"=>"Contactus");
        $viewData['type'] = base64_decode($type);
        $this->load->view('Contactus/contactus_view',$viewData);
    }
 		
    function datatable_source()
    {
        $this->datatables->select(" c.vSubject,
									c.vComment,
									c.dtCreated,
                                    u.vFirstName,
                                    u.vLastName,
                                    u.vUserName,
                                    c.iContactUsID as DT_RowId",false);
        $this->datatables->from('tbl_contact_us as c');
        $this->datatables->join('tbl_user u','u.iUserID = c.iFromUserID','LEFT');
        echo  $this->datatables->generate('json');
    }
     
}