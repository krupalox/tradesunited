<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reportedpost extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Userpost_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"Reported Post");
        $viewData['type'] = base64_decode($type);
        $this->load->view('Reportedpost/Reportedpost_view',$viewData);
    }
 		
    function datatable_source()
    {
		$POST_IMAGE_URL = POST_IMAGE_URL;
        $POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
        $USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;
		
		//SELECT r.iUserPostID, p.vTitle, p.vDetail, p.vPostImage, count(*) as reported_count, r.dtCreated  FROM `tbl_reported_post` r LEFT JOIN tbl_user_post p ON r.iUserPostID = p.iUserPostID group by r.iUserPostID
         $this->datatables->select("r.iReportedPost,
		 							r.iUserPostID, 
		 							p.vTitle, 
									IF(LENGTH(p.vDetail)> 100, CONCAT(substr(p.vDetail,1,150),'...'), p.vDetail) as vDetail, 
                                    IF(p.vPostImage != '',CONCAT('$POST_IMAGE_URL',p.vPostImage),'$USER_NO_IMAGE_URL') as vPostImage,
                                    IF(p.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',p.vPostImage),'$USER_NO_IMAGE_URL') as vPostImageThumb,
									count(*) as reported_count, 
									r.dtCreated,		  
                                    r.iReportedPost as DT_RowId ",false);
        $this->datatables->from('tbl_reported_post as r');
        $this->datatables->group_by('r.iUserPostID');
        $this->datatables->join('tbl_user_post p','r.iUserPostID = p.iUserPostID','LEFT');
        echo  $this->datatables->generate('json');
    }
	
	function detail($iPostID)
    {
        $PostDetail = $this->userpost_model->ReportedpostDetail($iPostID);
         
		$viewData   =   array("title"=>"Reported Post - User List","iUserPostID"=>$iPostID,"PostDetail"=>$PostDetail);
		$this->load->view('Userpost/ReportedpostDetail_view',$viewData);
           
    }

 
}