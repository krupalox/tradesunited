<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    var $viewData = array();

    function __construct() {
        parent::__construct();
        $_POST = request_clean($_POST);  
    }

    function index()
    {
        if (!empty($_POST) && count($_POST) > 0) 
        {
            $isLoginTrue = $this->Admin_model->login_check();   
            if($isLoginTrue) 
            {
                redirect('dashboard');
            }        
        } 
        else 
        {
            $this->load->view('login/login_view', $this->viewData);
        }
    }


    function activate($id)
    {
        $id1    = base64_decode($id);
        if (is_numeric($id1)) 
        {
            $data   =   array(
                'id'    =>  $id1,
                'title' =>  'Reset Password'
            );
            $this->load->view('email/Reset_password_view',$data);
        } 
        else 
        {
            redirect();
        }
    }

    /*
    | -------------------------------------------------------------------
    |  RESET PASSWORD
    | -------------------------------------------------------------------
    */
    function reset_pass()
    {
        echo "Dfgfdsd";
        exit;
        mprd($this->input->post());
    }

}