<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
        $_POST = request_clean($_POST);       
    }

    function index()
    {
        $viewData   =   array("title"=>"Admin Management");
        $this->load->view('admin/admin_view',$viewData);
    }

    function status($id)
    {
        if($id != '')
        {
            $changstatus = $this->Admin_model->changeAdminStatus($id);
            if($changstatus != '')
            {
                echo ADMIN_EDITED;
            }
            else
            {
                echo ADMIN_NOT_EDITED;
            }
        }
        else
        {
            echo '';
        }
    }

    function remove($id)
    {
        if($id != '')
        {
            $removeUser = $this->Admin_model->removeAdmin($id);

            if($removeUser != '')
            {
                echo 1;
            }
            else
            {
                echo 0;
            }
        }
        exit;
    }

    function add($id='',$ed='')
    {   
        if($id!='' && $ed !='' && $ed == 'y')
        {   $id =  base64_decode($id);
            $getData = $this->Admin_model->getAdminDataById($id);
            $viewData['getUserData'] = $getData;
            $viewData['title'] =    "Admin Edit";
            $viewData['ACTION_LABEL'] = "Edit";
        }else{
            $viewData['title'] =    "Admin Add";
            $viewData['ACTION_LABEL'] = "Add";
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminadd')
        {
            if($this->Admin_model->checkAdminEmailAvailable($this->input->post('email')))
            {
                $adminAdd = $this->Admin_model->addAdmin($_POST);

                if($adminAdd != '')
                {
                    $succ = array('0' => ADMIN_ADDED);

                    $this->session->set_userdata('SUCCESS',$succ);

                }else{
                    $err = array('0' => ADMIN_NOT_ADDED);

                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => ADMIN_EXISTS);

                $this->session->set_userdata('ERROR',$err);
            }
            redirect('admin');
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminedit')
        {
            
            if($this->Admin_model->checkAdminEmailAvailable($this->input->post('email'),$this->input->post('id')))
            {
               
                $adminEdit = $this->Admin_model->editAdmin($_POST);
                if($adminEdit != '')
                {
                    $succ = array('0' => ADMIN_EDITED);

                    $this->session->set_userdata('SUCCESS',$succ);

                }
                else
                {
                    $err = array('0' => ADMIN_NOT_EDITED);

                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => ADMIN_EXISTS);

                $this->session->set_userdata('ERROR',$err);
            }

            redirect('admin');
        }
        $this->load->view('admin/admin_add_view',$viewData);
    }

    // function edit($id='',$ed='')
    // {
    //     $viewData['title'] =    "Admin Management";

    //     $viewData['ACTION_LABEL'] = (isset($id) && $id != '' && $ed !='' && $ed == 'y')?"Edit":"Add";

    //     if($id!='' && $ed !='' && $ed == 'y')
    //     {
    //         $getData = $this->Admin_model->getAdminDataById($id);
    //         $viewData['getUserData'] = $getData;
    //     }
    //     if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminedit')
    //     {
    //         if($this->Admin_model->checkAdminEmailAvailable($this->input->post('email_address'),$this->input->post('id')))
    //         {
    //             // mprd($_POST);
    //             $adminEdit = $this->Admin_model->editAdmin($_POST);

    //             if($adminEdit != '')
    //             {
    //                 $succ = array('0' => ADMIN_EDITED);

    //                 $this->session->set_userdata('SUCCESS',$succ);

    //             }
    //             else
    //             {
    //                 $err = array('0' => ADMIN_NOT_EDITED);

    //                 $this->session->set_userdata('ERROR',$err);
    //             }
    //         }
    //         else
    //         {
    //             $err = array('0' => ADMIN_EXISTS);

    //             $this->session->set_userdata('ERROR',$err);
    //         }

    //         redirect('admin');
    //     }
    //     $this->load->view('admin/admin_edit_view',$viewData);
    // }

    function deleteAll()
    {
        $data = $_POST['rows'];

        $removeUser = $this->Admin_model->removeAdminAll($_POST['rows']);

        if($removeUser != '')
        {
            echo '1';
        }
        else
        {
            echo '0';
        }
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->Admin_model->changeAdminStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function datatable_source()
    {
        if(isset($_POST['order'][0]['column']))
        {
            if($_POST['order'][0]['column'] == 0)
            {
                $orderBy = 'Name';
                $orderType = $_POST['order'][0]['dir'];
            }elseif ($_POST['order'][0]['column'] == 1) {
                $orderBy = 'Email';
                $orderType = $_POST['order'][0]['dir'];
            }elseif ($_POST['order'][0]['column'] == 2) {
                $orderBy = 'added_date_time';
                $orderType = $_POST['order'][0]['dir'];
            }elseif ($_POST['order'][0]['column'] == 3) {
                $orderBy = 'eStatus';
                $orderType = $_POST['order'][0]['dir'];
            } else {
                $orderBy = 'id';
                $orderType = $_POST['order'][0]['dir'];
            }
        }

        $this->load->library('datatables');
        $this->datatables->select('CONCAT(firstname," ",lastname) as Name, email as Email, DATE_FORMAT(added_date_time,"%d %M , %Y %H:%i:%s") as added_date_time, status as Status,id,id as DT_RowId',false);
        $this->datatables->from('tbl_admin');
        $this->datatables->where('id !=',$this->session->userdata('ADMINID'));        
        $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');
    }

    function export_csv($name)
    {
        $this->db->select('CONCAT(firstname, " ", lastname) AS Name,email as Email,status as Status,DATE_FORMAT(added_date_time,"%d %M , %Y %H:%i:%s") as Added_date_time', FALSE);
        $query = $this->db->get('tbl_admin');
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }
}