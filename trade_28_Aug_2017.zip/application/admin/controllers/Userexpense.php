<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userexpense extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    // function index()
    // {
    //     $viewData   =   array("title"=>"User");
    //     $UserDetail = $this->User_model->getUserDetailByuserId($iUserID);
    //     $viewData['iUserID'] = $iUserID;
    //     $viewData['fullname'] = $UserDetail['fullname'];
    //     $viewData['vTradeName'] = $UserDetail['vTradeName'];
    //     $this->load->view('user/user_expense_view',$viewData);
    // }
    
    function getUserExpenseDetail($iUserID) {
        $viewData   =   array("title"=>"User");
        $UserDetail = $this->User_model->getUserDetailByuserId($iUserID);
        $viewData['iUserID'] = $iUserID;
        $viewData['fullname'] = $UserDetail['fullname'];
        $viewData['vTradeName'] = $UserDetail['vTradeName'];
        $this->load->view('user/user_expense_view',$viewData);
    }

    function getUserExpenseById($iUserID) {
        $EXPENSE_IMAGE_URL = EXPENSE_IMAGE_URL;
        $EXPENSE_IMAGE_URL_THUMB = EXPENSE_IMAGE_URL_THUMB;
        $EXPENSE_NO_IMAGE_URL = EXPENSE_NO_IMAGE_URL;

        $this->datatables->select(" ue.vExpanseTitle,
                                    ec.vCatName,
                                    ue.dAmount,
                                    IF(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL',ue.vExpenseImage),'$EXPENSE_NO_IMAGE_URL') as vExpenseImage,
                                    ue.dDate as dDate,
                                    ue.iUserExpenseID,
                                    IF(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL_THUMB',ue.vExpenseImage),'$EXPENSE_NO_IMAGE_URL') as vExpenseImageThumb,
                                    ue.iUserExpenseID as DT_RowId",false);
        $this->datatables->where('ue.iUserID',$iUserID);
        $this->datatables->where('ue.eIsDeleted','no');
        $this->datatables->from('tbl_user_expense as ue');
        $this->datatables->join('tbl_expense_category ec','ec.iExpenseCateID = ue.iExpenseCateID','LEFT');
       // $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');
    }

    //Created By :: Ila Darji on 20-4-2017
    //Created for :: Get User Expense for export records 
    public function datatable_user_source_export($name) {
        $this->datatables->select("ue.iUserExpenseID as iUserExpenseID,
                                    ec.vCatName,
                                    ue.vExpanseTitle as vExpanseTitle,
                                    DATE_FORMAT(ue.dDate,'%d %M , %Y %H:%i:%s') as ExpenseDate",false);
        $this->db->where('ue.eIsDeleted','no');
        $this->db->from('tbl_user_expense as ue');
        $this->db->join('tbl_expense_category ec','ec.iExpenseCateID = ue.iExpenseCateID','LEFT');
        $this->db->order_by('ue.dtCreated','desc');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }

    public function deleteAllUserExpense() {
        $data = $_POST['rows'];
        $removeUser = $this->User_model->removeUserExpenseAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

     function remove($id) {
        if($id != '') {
            $removeUser = $this->User_model->removeUserExpense($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }
}