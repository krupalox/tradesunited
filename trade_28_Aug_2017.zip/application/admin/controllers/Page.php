<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Page extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Page_model');
        $_POST = $this->clean_input($_POST);
    }
    function clean_input($array){
         foreach($array as $Key => $Value){               
            if(is_array($Value)){
                request_clean($Value);
            }else{
               $array[$Key] = $this->security->xss_clean(trim($Value));
            }
         }
         return $array;

    }

    function index()
    {
        $viewData   =   array("title" => "Page Management");
        $this->load->view('page/page_view',$viewData);
    }

    
    function remove($id)
    {
        if($id != '')
        {
            $removeData = $this->Page_model->remove($id);

            if($removeData != '')
            {
                echo 1;
            }
            else
            {
                echo 0;
            }
        }
        exit;
    }

    function add($id='',$ed='')
    {
        if($id!='' && $ed !='' && $ed == 'y')
        {
            $id = base64_decode($id);
            $getData = $this->Page_model->getPageDataById($id);
            $viewData['getPageData'] = $getData;
            $viewData['title_txt'] =    "Edit page details";
            $viewData['ACTION_LABEL'] = "Edit";
        }else{
            $viewData['title_txt'] =    "Add new page";
            $viewData['ACTION_LABEL'] = "Add";
        }


        if($this->input->post('action') && $this->input->post('action') == 'backoffice.add')
        {
            if($this->Page_model->checkPageExists($this->input->post('title')))
            {
                $Add = $this->Page_model->addPage($_POST);

                if($Add != '')
                {
                    $succ = array('0' => PAGE_ADDED);

                    $this->session->set_userdata('SUCCESS',$succ);

                }else{
                    $err = array('0' => PAGE_NOT_ADDED);

                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => PAGE_EXISTS);

                $this->session->set_userdata('ERROR',$err);
            }
            redirect('page');
        }
        else if($this->input->post('action') && $this->input->post('action') == 'backoffice.edit')
        {
            if($this->Page_model->checkPageExists($this->input->post('title'),$this->input->post('id')))
            {
                $editData = $this->Page_model->editPage($_POST);

                if($editData != '')
                {
                    $succ = array('0' => PAGE_EDITED);
                    $this->session->set_userdata('SUCCESS',$succ);

                }
                else
                {
                    $err = array('0' => PAGE_NOT_EDITED);

                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => PAGE_EXISTS);

                $this->session->set_userdata('ERROR',$err);
            }
            redirect('page');
        }
        $this->load->view('page/page_add_view',$viewData);
    }

    
    function datatable_source()
    {
        $this->load->library('datatables');
        $this->datatables->select('id,title,id as DT_RowId',false);
        $this->datatables->from('tbl_page');
       // $this->datatables->order_by('id','desc');
        echo $this->datatables->generate('json');
    }
}