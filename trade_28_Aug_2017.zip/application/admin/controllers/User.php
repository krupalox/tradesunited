<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"User");
        $viewData['type'] = base64_decode($type);
        $this->load->view('user/user_view',$viewData);
    }

    function datatable_source()
    {

        $USER_IMAGE_URL = USER_IMAGE_URL;
        $USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
        $USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

        $this->datatables->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vFullName,
                                    u.vEmail,
                                    IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),'$USER_NO_IMAGE_URL') as vProfileImage,
                                    u.vAddress as vAddress,
                                    tt.vTradeName as vTradeName,
                                    DATE_FORMAT(u.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    u.iUserID,
                                    IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),'$USER_NO_IMAGE_URL') as vProfileImageThumb,
                                    (SELECT count(iUserExpenseID) From tbl_user_expense WHERE iUserID = u.iUserID AND eIsDeleted != 'yes') as expenseCount,
                                    u.eStatus,
                                    u.iUserID as DT_RowId",false);
        $this->datatables->where('u.eIsDeleted','no');
        $this->datatables->from('tbl_user as u');
        $this->datatables->join('tbl_trade tt','tt.iTradeID = u.iTradeID','LEFT');
       // $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');
    }

    function datatable_source_export($name) {
        $this->datatables->select("u.iUserID as UserID,
                                    CONCAT(u.vFirstName,' ',u.vLastName) as Fullname,
                                    u.iPhoneNumber as Phone_number,
                                    u.vEmail as Email,
                                    u.vAddress as Address,
                                    t.vTradeName as TradeName,
                                    DATE_FORMAT(u.dtCreated,'%d %M , %Y %H:%i:%s') as Created_at, 
                                    u.eStatus",false);
        $this->db->where('u.eIsDeleted','no');
        $this->db->from('tbl_user as u');
        $this->db->join('tbl_trade t','t.iTradeID = u.iTradeID','LEFT');
        $this->db->order_by('u.dtCreated','desc');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }

    function deleteAll()
    {
        mprd($_POST['rows']);
        $data = $_POST['rows'];
        $removeUser = $this->User_model->removeUserAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->User_model->changeUserStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function status($id) {
        if($id != '') {
            $changstatus = $this->User_model->changeUserStatus($id);
            if($changstatus != '') {
                echo "USER_EDITED"; 
            } else {
                echo USER_NOT_EDITED;
            }
        }
        else {
            echo '';
        }
    }

    function remove($id) {
        if($id != '') {
            $removeUser = $this->User_model->removeUser($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }
    
}