<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userpost extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('userpost_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"User");
        $viewData['type'] = base64_decode($type);
        $this->load->view('Userpost/Userpost_view',$viewData);
    }

    function datatable_source()
    {
        $POST_IMAGE_URL = POST_IMAGE_URL;
        $POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
        $USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;
		
		// DATE_FORMAT(up.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,


        $this->datatables->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vfullname,
                                    up.vTitle as vTitle,
                                    IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'$USER_NO_IMAGE_URL') as vPostImage,
                                    pc.vCatName as vCatName,
                                    up.iUserPostID,
                                    up.dtCreated as dtCreated_default,
                                    up.eStatus,
                                    IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'$USER_NO_IMAGE_URL') as vPostImageThumb,
                                    u.iUserID as iUserID,
                                    (SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID = up.iUserPostID) as LikeCount,
                                    (SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID = up.iUserPostID) as CommentCount,
                                    up.iUserPostID as DT_RowId",false);
        $this->datatables->where('up.eIsDeleted','no');
        $this->datatables->from('tbl_user_post as up');
        $this->datatables->join('tbl_post_category pc','pc.iPostCatID = up.iPostCatID','LEFT');
        $this->datatables->join('tbl_user u','u.iUserID = up.iUserID','LEFT');
       // $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');
    }



    function datatable_source_export($name) {
        $this->datatables->select("up.iUserPostID as iUserPostID,
                                    up.vTitle as vTitle,
                                    pc.vCatName as vCatName,
                                    DATE_FORMAT(up.dtCreated,'%d %M , %Y %H:%i:%s') as Created_at, 
                                    up.eStatus",false);
        $this->db->where('up.eIsDeleted','no');
        $this->db->from('tbl_user_post as up');
        $this->db->join('tbl_post_category pc','pc.iPostCatID = up.iPostCatID','LEFT');
        $this->db->order_by('pc.dtCreated','desc');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }
    

    function deleteAll()
    {
        $data = $_POST['rows'];
        $removeUser = $this->userpost_model->removeUserAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->userpost_model->changeUserStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function status($id) {
        if($id != '') {
            $changstatus = $this->userpost_model->changeUserStatus($id);
            if($changstatus != '') {
                echo USER_EDITED;
            } else {
                echo USER_NOT_EDITED;
            }
        }
        else {
            echo '';
        }
    }

    function remove($id) {
        if($id != '') {
            $removeUser = $this->userpost_model->removeUser($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }

    function getLikeCommentList($iPostID,$lable)
    {
        $PostDetail = $this->userpost_model->getPostDetailBypostID($iPostID);
        if($lable=='Likes')
        {
            $viewData   =   array("title"=>"Post Likes","iUserPostID"=>$iPostID,"PostDetail"=>$PostDetail);
            $this->load->view('Userpost/UserLikes_view',$viewData);
        } 
        elseif ($lable=='Comments')  
        {
            $viewData   =   array("title"=>"Post Comments","iUserPostID"=>$iPostID,"PostDetail"=>$PostDetail);
            $this->load->view('Userpost/Usercomment_view',$viewData);
        }   
    }

    function getPostLikesDetail($iPostID) {
        $this->datatables->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vfullname,
                                    DATE_FORMAT(pl.dtCreated,'%d %M , %Y %H:%i:%s') as Created_at, 
                                    pl.iPostLikeID as DT_RowId",false);
        $this->datatables->where('pl.iPostID',$iPostID);
        $this->datatables->from('tbl_post_like as pl');
        $this->datatables->join('tbl_user u','u.iUserID = pl.iUserID','LEFT');
       // $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');
    }

    function getPostCommentDetail($iPostID) {

        $this->datatables->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vfullname,
                                    pc.vComment as vComment,
                                    DATE_FORMAT(pc.dtCreated,'%d %M , %Y %H:%i:%s') as Created_at, 
                                    pc.iPostCommentID as DT_RowId",false);
        $this->datatables->where('pc.iPostID',$iPostID);
        $this->datatables->from('tbl_post_comment as pc');
        $this->datatables->join('tbl_user u','u.iUserID = pc.iUserID','LEFT');
       // $this->db->order_by($orderBy,$orderType);
        echo  $this->datatables->generate('json');

    }
    
}