<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class PCategory extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('pcategory_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"User");
        $viewData['type'] = base64_decode($type);
        $this->load->view('pcategory/pcategory_view',$viewData);
    }

    function datatable_source()
    {
        $this->datatables->select(" pc.vCatName as vCatName,
                                    DATE_FORMAT(pc.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    pc.eStatus,
                                    pc.iPostCatID as iPostCatID,
                                    pc.vColorCode,
                                    pc.eIsInnerPurchase,
                                    pc.iPostCatID as DT_RowId",false);
        $this->datatables->where('pc.eIsDeleted','no');
        $this->datatables->from('tbl_post_category as pc');
        echo  $this->datatables->generate('json');
    }

    function datatable_source_export($name) {
        $this->datatables->select("pc.iPostCatID as iPostCatID,
                                    pc.vCatName as vCatName,
                                    pc.vColorCode as vColorCode,
                                    DATE_FORMAT(pc.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    pc.eStatus",false);
        $this->db->where('pc.eIsDeleted','no');
        $this->db->from('tbl_post_category as pc');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }

    function deleteAll()
    {
        $data = $_POST['rows'];
        $removeUser = $this->pcategory_model->removeUserAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

     function remove($id) {
        if($id != '') {
            $removeUser = $this->pcategory_model->removeUser($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->pcategory_model->changeUserStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function status($id) {
        if($id != '') {
            $changstatus = $this->pcategory_model->changeUserStatus($id);
            if($changstatus != '') {
                echo USER_EDITED;
            } else {
                echo USER_NOT_EDITED;
            }
        }
        else {
            echo '';
        }
    }

   

    function add($id='',$ed='')
    {   
        if($id!='' && $ed !='' && $ed == 'y')
        {   $id =  base64_decode($id);
            $getData = $this->pcategory_model->getpCatDataById($id);
            $viewData['getUserData'] = $getData;
            $viewData['title'] =    "Post Category Edit";
            $viewData['ACTION_LABEL'] = "Edit";
        }else{
            $viewData['title'] =    "Post Category Add";
            $viewData['ACTION_LABEL'] = "Add";
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminadd')
        {
            if($this->pcategory_model->checkCatAvailable($this->input->post('vCatName')))
            {
                $adminAdd = $this->pcategory_model->addPcat($_POST);
                if($adminAdd != '')
                {
                    $succ = array('0' => PCAT_ADDED);
                    $this->session->set_userdata('SUCCESS',$succ);

                }else{
                    $err = array('0' => PCAT_NOT_ADDED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => PCAT_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('pCategory');
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminedit')
        {   
            if($this->pcategory_model->checkCatAvailable($this->input->post('vCatName'),$this->input->post('id')))
            {  
                $adminEdit = $this->pcategory_model->editPcat($_POST);
                if($adminEdit != '')
                {
                    $succ = array('0' => PCAT_EDITED);
                    $this->session->set_userdata('SUCCESS',$succ);
                }
                else
                {
                    $err = array('0' => PCAT_NOT_EDITED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => PCAT_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('pCategory');
        }
        $this->load->view('pcategory/pcategory_add_view',$viewData);
    }
    
}