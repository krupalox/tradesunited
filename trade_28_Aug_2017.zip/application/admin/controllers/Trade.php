<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Trade extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Trade_model');
        $this->load->library('datatables');
        $_POST = request_clean($_POST);  
    }

    function index($type='')
    {
        $viewData   =   array("title"=>"User");
        $viewData['type'] = base64_decode($type);
        $this->load->view('trade/trade_view',$viewData);
    }

    function datatable_source()
    {
        $USER_IMAGE_URL = USER_IMAGE_URL;
        $USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
        $USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;
        $this->datatables->select(" t.vTradeName as vTradeName,
                                    DATE_FORMAT(t.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    t.eStatus,
                                    t.iTradeID as iTradeID,
                                    t.iTradeID as DT_RowId",false);
        $this->datatables->where('t.eIsDeleted','no');
        $this->datatables->from('tbl_trade as t');
        echo  $this->datatables->generate('json');
    }

    function datatable_source_export($name) {
        $this->datatables->select("t.iTradeID as iTradeID,
                                    t.vTradeName as vTradeName,
                                    DATE_FORMAT(t.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    t.eStatus",false);
        $this->db->where('t.eIsDeleted','no');
        $this->db->from('tbl_trade as t');
        $query = $this->db->get();
        $data = $this->load->helper('csv');
        $name .= "(".date('Y-m-d').").csv";
        query_to_csv($query,true,$name);
    }

    function deleteAll()
    {
        $data = $_POST['rows'];
        $removeUser = $this->Trade_model->removeUserAll($_POST['rows']);
        if($removeUser != '') {
            echo '1';
        } else {
            echo '0';
        }
    }

    function changeStatusAll()
    {
        $data = $_POST['rows'];
        if(!empty($data)){
            foreach ($data as $key => $value) {
                $this->Trade_model->changeUserStatus($value);
            }
            echo '1';
        }else{
            echo '0';
        }
    }

    function status($id) {
        if($id != '') {
            $changstatus = $this->Trade_model->changeUserStatus($id);
            if($changstatus != '') {
                echo USER_EDITED;
            } else {
                echo USER_NOT_EDITED;
            }
        }
        else {
            echo '';
        }
    }

    function remove($id) {
        if($id != '') {
            $removeUser = $this->Trade_model->removeUser($id);
            if($removeUser != '') {
                echo 1;
            }
            else {
                echo 0;
            }
        }
        exit;
    }

    function add($id='',$ed='')
    {   
        if($id!='' && $ed !='' && $ed == 'y')
        {   $id =  base64_decode($id);
            $getData = $this->Trade_model->getTradeDataById($id);
            $viewData['getUserData'] = $getData;
            $viewData['title'] =    "Trade Edit";
            $viewData['ACTION_LABEL'] = "Edit";
        }else{
            $viewData['title'] =    "Trade Add";
            $viewData['ACTION_LABEL'] = "Add";
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminadd')
        {
            if($this->Trade_model->checkTradeAvailable($this->input->post('vTradeName')))
            {
                $adminAdd = $this->Trade_model->addTrade($_POST);

                if($adminAdd != '')
                {
                    $succ = array('0' => TRADE_ADDED);
                    $this->session->set_userdata('SUCCESS',$succ);

                }else{
                    $err = array('0' => TRADE_NOT_ADDED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => TRADE_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('Trade');
        }
        if($this->input->post('action') && $this->input->post('action') == 'backoffice.adminedit')
        {   
            if($this->Trade_model->checkTradeAvailable($this->input->post('vTradeName'),$this->input->post('id')))
            {  
                $adminEdit = $this->Trade_model->editTrade($_POST);
                if($adminEdit != '')
                {
                    $succ = array('0' => TRADE_EDITED);
                    $this->session->set_userdata('SUCCESS',$succ);
                }
                else
                {
                    $err = array('0' => TRADE_NOT_EDITED);
                    $this->session->set_userdata('ERROR',$err);
                }
            }
            else
            {
                $err = array('0' => TRADE_CAT_EXISTS);
                $this->session->set_userdata('ERROR',$err);
            }
            redirect('Trade');
        }
        $this->load->view('trade/trade_add_view',$viewData);
    }
    
}