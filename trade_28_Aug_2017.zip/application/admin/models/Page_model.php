<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page_model extends CI_Model
{
	var $table;

	function __construct()
	{
		parent::__construct();
		$this->table = 'tbl_page';
	}

	function chk_admin_session()
	{
		$user = $this->session->userdata('ADMINLOGIN');
		$session_login = $this->session->userdata("ADMINLOGIN");
		if($session_login == '' && $this->uri->segment(1) != 'login' && $this->uri->segment(1) != 'forgot_pass' && $this->uri->segment(1) != 'confirmation')
		{
			redirect('login');
		}
		if($session_login == 1 && $session_login == TRUE && ($this->uri->segment(1) == '' || $this->uri->segment(1) == 'login' || $this->uri->segment(1) == 'forgot_pass' || $this->uri->segment(1) == 'confirmation')){
			redirect('dashboard');
		}
	}

	function getAdminDataAll()
	{
		$this->db->from($this->table);
		$result = $this->db->get();
		if($result->num_rows() > 0)
			return $result->result_array();
		else
			return '';
	}

	function getPageDataById($id)
	{
		$result = $this->db->get_where($this->table, array('id' => $id));

		if($result->num_rows() > 0) {
			return $result->row_array();
		}
		else {
			return '';
		}
	}

	function changeStatus($ws_id)
	{
		$query = $this->db->query("UPDATE $this->table SET status = IF (status = 'Active', 'Inactive','Active') WHERE ws_id = $ws_id");

		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function remove($id)
	{
		$query=$this->db->query("DELETE from $this->table WHERE id = $id");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function removeAll($ws_id)
	{
		$adid=implode(',', $ws_id);
		$query=$this->db->query("DELETE from $this->table WHERE ws_id in ($adid)");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function addPage($postData)
	{
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$data = array('title'  => $title,
			'description' => $description,
			'added_date_time' => $currentDateTime
			);

		$query = $this->db->insert($this->table, $data);

		if($this->db->affected_rows() > 0)
			return $this->db->insert_id();
		else
			return '';
	}

	function editPage($postData)
	{
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$updateData = array(  'title' => $title,
			'description' => $description,
			'updated_date_time'  => $currentDateTime
			);
		$query = $this->db->update($this->table,$updateData, array('id' => $id));
		return $query;
	}

	function checkPageExists($title,$id ='')
	{
		if($id !='')
		{
			$check = array('title' => $title,'id<>'=>$id );
		}
		else
		{
			$check = array('title' => $title);
		}

		$result = $this->db->get_where($this->table,$check);
		if($result->num_rows() >= 1 )
			return 0;
		else
			return 1;
	}

}
