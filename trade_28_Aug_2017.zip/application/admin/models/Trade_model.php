<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trade_model extends CI_Model{

	var $table;

	function __construct()
	{
		parent::__construct();
		$this->table = 'tbl_trade';
	}

	function removeUserAll($data)
	{
		$adid=implode(',', $data);
		$query=$this->db->query("UPDATE $this->table set eIsDeleted = 'yes' WHERE iTradeID in ($adid)");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function changeUserStatus($iTradeID) {
		$query = $this->db->query("UPDATE $this->table SET eStatus = IF (eStatus = 'Active', 'Inactive','Active') WHERE iTradeID = $iTradeID");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function removeUser($iTradeID) {
		$this->db->update('tbl_trade',array('eIsDeleted'=>'yes'),array('iTradeID'=>$iTradeID));
		$this->db->where('iTradeID',$iTradeID);
		if($this->db->affected_rows() > 0){
			return 1;
		}else{
			return 0;
		}
	}

	function getTradeDataById($iTradeID)
	{
		$result = $this->db->get_where($this->table, array('iTradeID' => $iTradeID));
		if($result->num_rows() > 0)
			return $result->row_array();
		else
			return '';
	}

	function checkTradeAvailable($vTradeName,$id ='')
	{
		if($id !='')
			$check = array('vTradeName' => $vTradeName,'iTradeID<>'=>$id,'eIsDeleted'=>'no');
		else
			$check = array('vTradeName' => $vTradeName,'eIsDeleted'=>'no');

		$result = $this->db->get_where($this->table,$check);

		if($result->num_rows() >= 1 )
			return 0;
		else
			return 1;
	}

	function addTrade($postData)
	{
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$data = array(
			'vTradeName'  => $vTradeName ,
			'dtCreated' => date('Y-m-d H:i:s')
			);
		$query = $this->db->insert($this->table, $data);
		if($this->db->affected_rows() > 0)
			return $this->db->insert_id();
		else
			return '';
	}

	function editTrade($postData)
	{
		$currentDateTime = date('Y-m-d H:i:s');
		extract($postData);
		$updateData = array('vTradeName' => $vTradeName);
		$query = $this->db->update($this->table,$updateData, array('iTradeID' => $id));
		return $query;

	}
}

