<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

	var $tbl_admin;
    var $tbl_user;

    public function __construct() {
        parent::__construct();
    	$this->tbl_admin = 'tbl_admin';
        $this->tbl_user = 'tbl_user';
    }

    function getTotalAdmin(){
    	$admins = $this->db->get($this->tbl_admin);
    	if($admins->num_rows() > 0){
    		return $admins->num_rows();
    	}else{
    		return 0;
    	}
    }

    function getTotalUsers(){
        $users = $this->db->get_where('tbl_user',array('eIsDeleted'=>'no'));
        if($users->num_rows() > 0){
            return $users->num_rows();
        }else{
            return 0;
        }
    }

    function getTotalCategories(){
        $group = $this->db->get_where('tbl_trade',array('eIsDeleted'=>'no'));
        if($group->num_rows() > 0){
            return $group->num_rows();
        }else{
            return 0;
        }
    }
 
    function getTotalPostCat() {
        $collage = $this->db->get_where('tbl_post_category',array('eIsDeleted'=>'no'));
        if($collage->num_rows() > 0){
            return $collage->num_rows();
        }else{
            return 0;
        }
    }

    function getTotalExpenseCate() {
        $collage = $this->db->get_where('tbl_expense_category',array('eIsDeleted'=>'no'));
        if($collage->num_rows() > 0){
            return $collage->num_rows();
        }else{
            return 0;
        }
    }
	
	 function getTotalUserPost(){
        $event = $this->db->get_where('tbl_user_post',array('eIsDeleted'=>'no'));
        if($event->num_rows() > 0){
            return $event->num_rows();
        }else{
            return 0;
        }
    }
	
	 function getTotalLoogbook(){
        $event = $this->db->get_where('tbl_user_log');
        if($event->num_rows() > 0){
            return $event->num_rows();
        }else{
            return 0;
        }
    }
    
}
