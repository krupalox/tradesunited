<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactus_model extends CI_Model{

    var $table;

    function __construct()
    {
        parent::__construct();
        $this->table = 'tbl_contact_us';
    }
 
}

