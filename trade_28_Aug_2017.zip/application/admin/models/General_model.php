<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class General_model extends CI_Model

{

	function __construct()
	{
		parent::__construct();
	}

	//************************************************************

	//Error Or success Msg View

	//************************************************************

	function getMessages()
	{

		if($this->session->userdata('ERROR') && array_count_values($this->session->userdata('ERROR')) > 0)

		{

			return $this->load->view('messages/error_view');

		}

		else if($this->session->userdata('SUCCESS') && array_count_values($this->session->userdata('SUCCESS')) > 0)

		{

			return $this->load->view('messages/success_view');

		}

	}



//************************************************************

//If not find any record

//************************************************************

	function noRecordsHere()

	{

		echo '<div class="alert i_magnifying_glass yellow"><strong>Opps!!&nbsp;&nbsp;:</strong>&nbsp;&nbsp;No Records available here.</div>';

	}



//**************************************************

// filter input data before storing it in DB by AMIT

//**************************************************

	function test_input($data) {



		if(is_array($data)){



			foreach ($data as $key=>$value) {

				$value = trim($value);

				$value = stripslashes($value);

				$value = htmlspecialchars($value);

				$data[$key] = $value;

			}



			return $data;

		}

		else {



			$data = trim($data);

			$data = stripslashes($data);

			$data = htmlspecialchars($data);

			return $data;



		}

	}

}

