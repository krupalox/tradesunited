<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Admin_model extends CI_Model
{

	var $table;
	function __construct()
	{
		parent::__construct();
		$this->table = 'tbl_admin';
		$this->chk_admin_cookie();
		$this->chk_admin_session();
		$this->load->library('encrypt');
	}



	function chk_admin_session()
	{
		$user = $this->session->userdata('ADMINLOGIN');
		$session_login = $this->session->userdata("ADMINLOGIN");
		if($session_login == '' && $this->uri->segment(1) != 'login' && $this->uri->segment(1) != 'forgot_pass' && $this->uri->segment(1) != 'confirmation')
		{
			redirect('login');
		}

		if($session_login == 1 && $session_login == TRUE && ($this->uri->segment(1) == '' || $this->uri->segment(1) == 'login' || $this->uri->segment(1) == 'forgot_pass' || $this->uri->segment(1) == 'confirmation')){
			redirect('dashboard');
		}
	}



	function chk_admin_cookie()
	{

		$loggedin = $this->chk_cookie();
		if($loggedin === TRUE)
		{
			redirect('dashboard');
		}
	}


	function chk_cookie()
	{
		$cookie = md5('loggedin');
		if($cookie_value = get_cookie($cookie))
		{
			$query = $this->db->get_where($this->table,array('md5(email)'=>$cookie_value));
			if($query->num_rows == 1)
			{
				$row = $query->row();
				if($row != '')
				{
					$userdata = array(
						'ADMINLOGIN'        => TRUE,
						'ADMINID'           => $row->id,
						'ADMINFIRSTNAME'    => $row->firstname,
						'ADMINLASTNAME'     => $row->lastname,
						'ADMINEMAIL'        => $row->email
						);
					$this->session->set_userdata($userdata);
					return true;
				}
			}
			return false;
		}
	}



	function getPasswordFromEmail($emailid)
	{
		$q = $this->db->query("SELECT password FROM tbl_admin WHERE email = '$emailid' ");
		if($q->num_rows() > 0) {
			$d = $q->row_array();
			return $d['password'];
		} else {
			return '';
		}
	}



	function login_check()
	{
		$email     = $this->input->post('email',TRUE);
		$password  = $this->input->post('password',TRUE);

				$array = array('email' => $email);
				$query = $this->db->get_where($this->table,$array);
				$queryData = $query->row_array();
				$checkPass = password_verify($password, $queryData['password']);				
				if($query->num_rows() == 1 && $checkPass)
				{
					$row = $query->row();
					if($row->status == "Active")
					{
						if($row != '')
						{
							$userdata = array(
								'ADMINLOGIN'        => TRUE,
								'ADMINID'           => $row->id,
								'ADMINFIRSTNAME'    => $row->firstname,
								'ADMINLASTNAME'     => $row->lastname,
								'ADMINEMAIL'        => $row->email
								);
							$this->session->set_userdata($userdata);

							return 1;
						}

					} else {
						$err = array('0' => ACCOUNT_NOT_ACTIVE);
						$this->session->set_userdata('ERROR',$err);
						$this->load->view('login/login_view','');
					}
				}
				else
				{		
					$ers = array('0' => LOGIN_ERROR);
					$this->session->set_userdata('ERROR',$ers);
					$this->load->view('login/login_view','');
				}
	}



	function check_admin_email_valid()

	{

		$admin_email = $this->input->post('email');



		if(isset($admin_email) && $admin_email != '')

		{

			$query  = $this->db->get_where($this->table,array('email'=>$admin_email));

			if($query->num_rows() == 0)

			{

				return "notfound";

			}

			else

			{

				$row = $query->row();

				if($row->status == "Inactive")

				{

					return "inactive";

				}

				else

				{

					$newPass = uniqid();

					$this->load->library('email');

					$this->email->from('no-reply@openxcell.com', 'CI 3');

					$this->email->to($admin_email);

					$this->email->subject('Password reset');

					$this->email->message('Your new password is : '.$newPass);

					if($this->email->send()){

						$this->db->set('password',md5($newPass));

						$this->db->where('email',$admin_email);

						$this->db->update($this->table);

						return 'valid';

					}



				}

			}

		}

		else

		{

			return "notfound";

		}

	}



	function reset_admin_pass($password)

	{

		$id     = $this->input->post('admin_id');



		$this->db->update($this->table, array('password'=>md5($password)), array('id' => $id));



		$query  = $this->db->get_where($this->table,array('id ' => $id));

		$row    = $query->row();

		if($row != '')

		{

			$userdata = array(

				'ADMINLOGIN'        => TRUE,

				'ADMINID'           => $row->id,

				'ADMINFIRSTNAME'    => $row->firstname,

				'ADMINLASTNAME'     => $row->lastname,

				'ADMINEMAIL'        => $row->email

				);

			$this->session->set_userdata($userdata);

			$email      = $row->email;

			$password   = md5($row->password);

			$subject    = "Password Reset";



			$this->load->library('email');

			$data = array(

				'link'      =>  BASEURL."login",

				'email'     =>  $email,

				'subject'   =>  $subject,

				'password'  =>  $password

				);

			$this->load->view('email/reset_pass_view',$data);

		}

		else

		{

			return false;

		}

	}



	function admin_setting()

	{

		$query  = $this->db->get_where($this->table,array('id ' => $this->session->userdata('ADMINID')));



		if($query->num_rows() > 0)

			return $query->row_array();

		else

			return '';

	}



	function edit_admin_setting()

	{

		$admin_id        = $this->session->userdata('ADMINID');

		$updateData = array('firstname'        =>$this->input->post('firstname'),

			'lastname'     =>$this->input->post('lastname'),

			'email'        =>$this->input->post('email')

			);



		$query = $this->db->update($this->table,$updateData, array('id ' => $id));



		if($this->db->affected_rows() > 0)

		{

			$userdata = array(

				'ADMINLOGIN'        => TRUE,

				'ADMINID'           => $id,

				'ADMINFIRSTNAME'    => $this->input->post('firstname'),

				'ADMINLASTNAME'     =>$this->input->post('lastname'),

				'ADMINEMAIL'        => $this->input->post('email')

				);

			$this->session->set_userdata($userdata);

			return $query;

		}

		else

			return '';

	}



	function checkOldPassword()
	{
		$admin_email = $this->session->userdata('ADMINEMAIL');
		$oldpassword  = $this->input->post('oldpassword',TRUE);
		$adminData =  $this->db->get_where('tbl_admin',array('email'=>$admin_email))->row_array();
		if(password_verify($oldpassword,$adminData['password']))
		{	
			return 1;
			
		}
		else
		{
			return 0;
		}
	}

	function changePassword()
	{
		$p = password_hash($this->input->post('password'),PASSWORD_BCRYPT);
		$data = array('password' => $p);
		$where = "email ='".$this->session->userdata('ADMINEMAIL')."'";
		$query = $this->db->update('tbl_admin', $data, $where);
		return $query;
	}



	function getAdminDataAll()

	{

		$this->db->from($this->table);

		$result = $this->db->get();

		if($result->num_rows() > 0)

			return $result->result_array();

		else

			return '';

	}



	function getAdminDataById($id)

	{

		$result = $this->db->get_where($this->table, array('id' => $id));





		if($result->num_rows() > 0)



			return $result->row_array();



		else

			return '';

	}



	function changeAdminStatus($id)

	{

		$query = $this->db->query("UPDATE $this->table SET status = IF (status = 'Active', 'Inactive','Active') WHERE id = $id");



		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function removeAdmin($id)

	{

		// $adid=implode(',', $id);

		$query=$this->db->query("DELETE from tbl_admin WHERE id=$id");

		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function removeAdminAll($id)

	{

		$adid=implode(',', $id);

		$query=$this->db->query("DELETE from tbl_admin WHERE id in ($adid)");

		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function addAdmin($postData)
	{
		extract($postData);
		$password_secure = password_hash($password, PASSWORD_BCRYPT);
		$currentDateTime = date('Y-m-d H:i:s');
		$data = array(
			'firstname'  => $firstname ,
			'lastname' => $lastname,
			'email'    => $email,
			'status'   => 'Active',
			'added_date_time' => $currentDateTime,
			'password'    =>  $password_secure
			);
		$query = $this->db->insert($this->table, $data);
		if($this->db->affected_rows() > 0)
			return $this->db->insert_id();
		else
			return '';
	}
	function editAdmin($postData)
	{
		$currentDateTime = date('Y-m-d H:i:s');
		extract($postData);
		$updateData = array(  'firstname' => $firstname,

			'lastname'  => $lastname,

			'email'       => $email,

			'updated_date_time'  => $currentDateTime

			);

		if (isset($password) && $password != "")

		{

			// $updateData['password']=md5($password);

			$updateData['password'] = password_hash($password, PASSWORD_BCRYPT);;

		}



		$query = $this->db->update($this->table,$updateData, array('id' => $id));

		return $query;

	}



	function checkAdminEmailAvailable($email,$id ='')

	{

		if($id !='')

			$check = array('email' => $email,'id<>'=>$id );

		else

			$check = array('email' => $email);





		$result = $this->db->get_where($this->table,$check);

		if($result->num_rows() >= 1 )

			return 0;

		else

			return 1;

	}



	function checkAdminIDAvailable($id ='')

	{

		if($id !=''){

			$check = array('id  '=>$id );

		}else{

			return '';

		}

		$result = $this->db->get_where($this->table,$check);

		if($result->num_rows() >= 1 )

			return 1;

		else

			return 0;

	}





	function getAdminRoleListById($admin_role)

	{

		$result = $this->db->get_where($this->role_tbl,array('admin_role'=>$admin_role));



		if($result->num_rows() > 0)

			return $result->result_array();

		else

			return '';

	}



	function changeAdminRoladmin_status($iRoleId)

	{

		$query = $this->db->query("UPDATE $this->role_tbl SET admin_status = IF (admin_status = 'Active', 'Inactive','Active') WHERE iRoleId = $iRoleId");



		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function removeAdminRole($iRoleId)

	{

		$query = $this->db->delete($this->role_tbl, array('iRoleId' => $iRoleId));



		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function getRoleDataById($iRoleId,$admin_role)

	{

		$result = $this->db->get_where($this->role_tbl, array('admin_role' => $admin_role,'iRoleId'=>$iRoleId));



		if($result->num_rows() > 0)

			return $result->row_array();

		else

			return '';

	}



	function checkAdminRoleAvailable($vRoleName,$admin_role,$iRoleId='')

	{

		if($iRoleId!='')

			$check = array('vRoleName' => $vRoleName,'admin_role' => $admin_role,'iRoleId <>'=>$iRoleId);

		else

			$check = array('vRoleName' => $vRoleName,'admin_role' => $admin_role);





		$result = $this->db->get_where($this->role_tbl,$check);

		if($result->num_rows() >= 1 )

			return 0;

		else

			return 1;

	}



	function addRole($postData)

	{



		extract($postData);



		$data = array('vRoleName'       => $vRoleName ,

			'admin_role'        => $admin_role,

			'admin_status'  => $admin_status

			);



		$query = $this->db->insert($this->role_tbl, $data);



		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function editRole($postData)

	{

		extract($postData);



		$updateData = array('vRoleName'     => $vRoleName ,

			'admin_status'      => $admin_status

			);



		$query = $this->db->update($this->role_tbl,$updateData, array('iRoleId ' => $iRoleId));



		if($this->db->affected_rows() > 0)

			return $query;

		else

			return '';

	}



	function sendActivationMailToAdmin($admin_id,$admin_pwd)

	{

		$query  = $this->db->get_where($this->table,array('admin_id'=>$admin_id));

		$row = $query->row();





		$this->load->library('email');

		$this->load->library('encrypt');



		$encrypted_id   = $this->encrypt->encode($row->admin_email);



		$subject = "Your account has been created.";

		$data = array(

			'sitelink'          =>  BASEURL."login/",

			'acvtivation_link'  =>  BASEURL."confirmation/index/".$encrypted_id,

			'email'             =>  $row->admin_email,

			'subject'           =>  $subject,

			'password'          =>  $admin_pwd

			);



		$this->load->view('email/company_activation_view',$data);

	}



	function activateAccount($admin_email,$admin_pwd)

	{

		$updateData = array('admin_status' => 'Active','admin_pwd' => md5($admin_pwd));

		$query = $this->db->update($this->table,$updateData, array('admin_email' => $admin_email));

		if($this->db->affected_rows() > 0)

			return 1;

		else

			return 0;

	}



	function checkAccountActivate($admin_email)

	{

		$checkData = array('admin_status' => 'Active','admin_email' => $admin_email);

		$query = $this->db->get_where($this->table,$checkData);

		if($query->num_rows() == 0)

			return 1;

		else

			return 0;

	}



	function get_result()

	{

		$this->db->select('id,firstname,lastname,email');

		$this->db->limit(

			$this->input->post('iDisplayLength'),

			$this->input->post('iDisplayStart')

			);

		$query = $this->db->get('tbl_admin');

		return $query->result_array();

	}



	public function getcompanyemail()

	{

		$this->db->select('vCompanymail');

		$cmpdata=$this->db->get('tbl_setting');

		if ($cmpdata->num_rows() > 0)

		{

			$cmpdata=$cmpdata->row_array();

			return $cmpdata['vCompanymail'];

		}

		else

		{

			return "";

		}

	}

}

