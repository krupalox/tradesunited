<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userpost_model extends CI_Model{

	var $table;

	function __construct()
	{
		parent::__construct();
		$this->table = 'tbl_user_post';
	}

	function removeUserAll($data)
	{
		$adid=implode(',', $data);
		$query=$this->db->query("UPDATE $this->table set eIsDeleted = 'yes' WHERE iUserPostID in ($adid)");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}


	function changeUserStatus($iUserPostID) {
		$query = $this->db->query("UPDATE $this->table SET eStatus = IF (eStatus = 'Active', 'Inactive','Active') WHERE iUserPostID = $iUserPostID");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function removeUserExpenseAll($data)
	{
		$adid=implode(',', $data);
		$query=$this->db->query("UPDATE tbl_user_expense set eIsDeleted = 'yes' WHERE iUserExpenseID in ($adid)");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function removeUser($iUserID) {
		$this->db->update('tbl_user',array('eIsDeleted'=>'yes'),array('iUserID'=>$iUserID));
		$this->db->where('iUserID',$iUserID);
		if($this->db->affected_rows() > 0){
			return 1;
		}else{
			return 0;
		}
	}

	function getUserDetailByuserId($iUserID) {

		$result = $this->db->select("CONCAT(u.vFirstName,' ',u.vLastName) as fullname,t.vTradeName",False)->join('tbl_trade t','t.iTradeID=u.iTradeID','LEFT')->get_where('tbl_user u',array('u.iUserID'=>$iUserID))->row_array();
		//mprd($this->db->last_query());
		return $result;

	}

	function removeUserExpense($iUserExpenseID) {
		$this->db->update('tbl_user_expense',array('eIsDeleted'=>'yes'),array('iUserExpenseID'=>$iUserExpenseID));
		$this->db->where('iUserExpenseID',$iUserExpenseID);
		if($this->db->affected_rows() > 0){
			return 1;
		}else{
			return 0;
		}
	}

	function getPostDetailBypostID($iUserPostID) {

		$POST_IMAGE_URL = POST_IMAGE_URL;
        $POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
        $USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

		$this->db->select(" CONCAT(u.vFirstName,' ',u.vLastName) as vfullname,
                                    up.vTitle as vTitle,
                                    IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'$USER_NO_IMAGE_URL') as vPostImage,
                                    pc.vCatName as vCatName,
                                    up.iUserPostID,
                                    DATE_FORMAT(up.dtCreated,'%d %M , %Y %H:%i:%s') as dtCreated,
                                    up.eStatus,
                                    IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'$USER_NO_IMAGE_URL') as vPostImageThumb,
                                    u.iUserID as iUserID,
                                    (SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID = up.iUserPostID) as LikeCount,
                                    (SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID = up.iUserPostID) as CommentCount,
                                    up.iUserPostID as DT_RowId",false);
        $this->db->where('up.iUserPostID',$iUserPostID);
        $this->db->join('tbl_post_category pc','pc.iPostCatID = up.iPostCatID','LEFT');
        $this->db->join('tbl_user u','u.iUserID = up.iUserID','LEFT');
        $result = $this->db->get('tbl_user_post as up');
        $resultArr = $result->row_array();
        return $resultArr;
	}
	
	function ReportedpostDetail($iUserID) {

		$result = $this->db->select("CONCAT(u.vFirstName,' ',u.vLastName) as fullname,t.vTradeName",False)->join('tbl_trade t','t.iTradeID=u.iTradeID','LEFT')->get_where('tbl_user u',array('u.iUserID'=>$iUserID))->row_array();
		//mprd($this->db->last_query());
		return $result;

	}


}

