<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pcategory_model extends CI_Model{
	var $table;
	function __construct()
	{
		parent::__construct();
		$this->table = 'tbl_post_category';
	}

	function removeUserAll($data)
	{
		$adid=implode(',', $data);
		$query=$this->db->query("UPDATE $this->table set eIsDeleted = 'yes' WHERE iPostCatID in ($adid)");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function changeUserStatus($iPostCatID) {
		$query = $this->db->query("UPDATE $this->table SET eStatus = IF (eStatus = 'Active', 'Inactive','Active') WHERE iPostCatID = $iPostCatID");
		if($this->db->affected_rows() > 0)
			return $query;
		else
			return '';
	}

	function removeUser($iPostCatID) {
		$this->db->update('tbl_post_category',array('eIsDeleted'=>'yes'),array('iPostCatID'=>$iPostCatID));
		$this->db->where('iPostCatID',$iPostCatID);
		if($this->db->affected_rows() > 0){
			return 1;
		}else{
			return 0;
		}
	}

	function getpCatDataById($iPostCatID)
	{
		$result = $this->db->get_where($this->table, array('iPostCatID' => $iPostCatID));
		if($result->num_rows() > 0) 
		{
			$resultArr = $result->row_array();
			if($resultArr['eIsInnerPurchase'] == '1')
			{
				$postCatResult = $this->db->select('vPurchaseTitle,dAmount')->get_where('tbl_category_inner_purchase',array('iPostCatID'=>$resultArr['iPostCatID'],'eIsDeleted'=>'no','eStatus'=>'Active'))->result_array();
				$resultArr['postCatResult'] = $postCatResult;
			}
			else
			{
				$resultArr['postCatResult'] = array();
			}
			return $resultArr;
		}
		else
		{
			return '';
		}	
	}

	function checkCatAvailable($vCatName,$id ='')
	{
		if($id !='')
			$check = array('vCatName' => $vCatName,'iPostCatID<>'=>$id,'eIsDeleted'=>'no');
		else
			$check = array('vCatName' => $vCatName,'eIsDeleted'=>'no');

		$result = $this->db->get_where($this->table,$check);

		if($result->num_rows() >= 1 )
			return 0;
		else
			return 1;
	}

	function addPcat($postData)
	{
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$data = array(
			'vCatName'  => $vCatName ,
			'eIsInnerPurchase' => $eIsInnerPurchase,
			'vColorCode' => $vColorCode,
			'dtCreated' => date('Y-m-d H:i:s')
			);
		$query = $this->db->insert($this->table, $data);
		if($this->db->affected_rows() > 0)
		{
			$iPostCatID = $this->db->insert_id();
			if(!empty($vPurchaseTitle) && !empty($dAmount))
			{
				foreach ($vPurchaseTitle as $key => $value) {
					if($value != ''){
						$postCatArr[] = array('iPostCatID'=>$iPostCatID,
							'vPurchaseTitle'=>$value,
							'dAmount'=>$dAmount[$key],
							'dtCreated'=>date('Y-m-d H:i:s')
							);	
					}
					
				}
				$this->db->insert_batch('tbl_category_inner_purchase', $postCatArr);
			}
			return $iPostCatID;
		}
		else
		{
			return '';
		}	
	}

	function editPcat($postData)
	{
		
		$currentDateTime = date('Y-m-d H:i:s');
		extract($postData);
		$updateData = array('vCatName' => $vCatName,
			'eIsInnerPurchase'=>$eIsInnerPurchase,
			'vColorCode'=>$vColorCode);
		$query = $this->db->update($this->table,$updateData, array('iPostCatID' => $id));
		$this->db->delete('tbl_category_inner_purchase',array('iPostCatID'=>$id));
		if($updateData['eIsInnerPurchase']=="1")
		{
			if(!empty($vPurchaseTitle) && !empty($dAmount))
			{
				foreach ($vPurchaseTitle as $key => $value) {
					if($value != ''){
						$postCatArr[] = array('iPostCatID'=>$id,
							'vPurchaseTitle'=>$value,
							'dAmount'=>$dAmount[$key],
							'dtCreated'=>date('Y-m-d H:i:s')
							);	
					}
					
				}
				$this->db->insert_batch('tbl_category_inner_purchase', $postCatArr);
			}
		}
		return $query;
	}
}

