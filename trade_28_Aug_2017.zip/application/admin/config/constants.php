<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ', 'rb');
define('FOPEN_READ_WRITE', 'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 'ab');
define('FOPEN_READ_WRITE_CREATE', 'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
define('EXIT_SUCCESS', 0); // no errors
define('EXIT_ERROR', 1); // generic error
define('EXIT_CONFIG', 3); // configuration error
define('EXIT_UNKNOWN_FILE', 4); // file not found
define('EXIT_UNKNOWN_CLASS', 5); // unknown class
define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
define('EXIT_USER_INPUT', 7); // invalid user input
define('EXIT_DATABASE', 8); // database error
define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code




define('APP_NAME', 'tradesunite');
define('MAINTITLE', APP_NAME);
define('DISPLAY_APP_NAME', 'TradesUnite');
define('_PATH', substr(dirname(__FILE__), 0, -25));
define('_URL', substr($_SERVER['PHP_SELF'], 0, - (strlen($_SERVER['SCRIPT_FILENAME']) - strlen(_PATH))));
define('SITE_PATH', _PATH . "/");
define('SITE_URL', _URL . "/");
define('WEBSITE_URL', SITE_URL . '/');

//------------------------------- By ila-----------------------------------------
define('DOC_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/'.APP_NAME.'/admin/'); 
define('DOMAIN_URL', 'https://'.$_SERVER['SERVER_NAME'].'/tradesunite/');
define('BASEURL', 'https://'.$_SERVER['SERVER_NAME'].'/'.APP_NAME . '/admin/');
define('IMG_ROOT', $_SERVER['DOCUMENT_ROOT'] .'/'.APP_NAME.'/images/');
define('FAVICON_PATH',BASEURL.'images/');
define('CSS_URL',BASEURL.'css/');
define('JS_URL',BASEURL.'js/');
//--------------------------------------------------------------------------------

//-----------------------------User Image-----------------------------------------
//Created By : Ila Darji on 23-01-2017
//Created For : Path For User Image Upload

define('USER_IMAGE_PATH', IMG_ROOT . "user/");
define('USER_IMAGE_PATH_THUMB', IMG_ROOT . "user/thumb/");

define('EXPENSE_IMAGE_PATH', IMG_ROOT . "userExpense/");
define('EXPENSE_IMAGE_PATH_THUMB', IMG_ROOT . "userExpense/thumb/");

define('POST_IMAGE_PATH', IMG_ROOT . "userPosts/");
define('POST_IMAGE_PATH_THUMB', IMG_ROOT . "userPosts/thumb/");

/*define('POST_IMAGE_URL', DOMAIN_URL . "userPosts/");
define('POST_IMAGE_URL_THUMB', DOMAIN_URL . "userPosts/thumb/");*/

define('POST_IMAGE_URL', DOMAIN_URL . "images/userPosts/"); 
define('POST_IMAGE_URL_THUMB', DOMAIN_URL . "images/userPosts/thumb/");
define('POST_IMAGE_NO_URL_THUMB', DOMAIN_URL . "images/userPosts/No_image.png");

define('USER_IMAGE_URL', DOMAIN_URL . "images/user/");
define('USER_IMAGE_URL_THUMB', DOMAIN_URL . "images/user/thumb/");
define('USER_NO_IMAGE_URL', DOMAIN_URL . "images/user/No_image.png");

define('EXPENSE_IMAGE_URL', DOMAIN_URL . "images/userExpense/");
define('EXPENSE_IMAGE_URL_THUMB', DOMAIN_URL . "images/userExpense/thumb/");
define('EXPENSE_NO_IMAGE_URL', DOMAIN_URL . "images/userExpense/No_image.png");
//---------------------------------------------------------------------------------

//------------------------------Lables----------------------------------------------
define('ACCOUNT_NOT_ACTIVE', "Account is Inactive.");
define('LOGIN_ERROR', "Incorrect email or password.");

define('ADMIN_ADDED', "Admin added successfully.");
define('ADMIN_NOT_ADDED', "Admin not added! Please try again.");
define('ADMIN_EXISTS', "Admin already exist!.");

define('ADMIN_EDITED', "Admin edited successfully.");
define('ADMIN_NOT_EDITED', "Admin not edited ! please try again.");

define('PASSWORD_CHANGED', 'Password Change successfully.');
define('OLD_PASSWORD_NOT_OK', 'Old Password in Incorrect !!');
//----------------------------------------------------------------------------------

//-------------------Trade constants------------------------------------------------
define('TRADE_ADDED', "Trade category added successfully.");
define('TRADE_NOT_ADDED', "Trade category not added! Please try again.");
define('TRADE_CAT_EXISTS', "Trade category already exist!.");

define('TRADE_EDITED', "Trade category edited successfully.");
define('TRADE_NOT_EDITED', "Trade category not edited ! please try again.");
//----------------------------------------------------------------------------------

//-------------------Post category constants----------------------------------------
define('PCAT_ADDED', "Post category added successfully.");
define('PCAT_NOT_ADDED', "Post category not added! Please try again.");
define('PCAT_CAT_EXISTS', "Post category already exist!.");

define('PCAT_EDITED', "Post category edited successfully.");
define('PCAT_NOT_EDITED', "Post category not edited ! please try again.");
//----------------------------------------------------------------------------------

//-------------------Expense category constants----------------------------------------
define('ECAT_ADDED', "Expense category added successfully.");
define('ECAT_NOT_ADDED', "Expense category not added! Please try again.");
define('ECAT_CAT_EXISTS', "Expense category already exist!.");

define('ECAT_EDITED', "Expense category edited successfully.");
define('ECAT_NOT_EDITED', "Expense category not edited ! please try again.");
//----------------------------------------------------------------------------------

//----------------------- Page Constants--------------------------------------------
define('PAGE_ADDED',"Page Added successfully!");
define('PAGE_NOT_ADDED',"Page Not Added! Please Try again.");
define('PAGE_EXISTS',"Page already exist!");
define('PAGE_EDITED',"Page Edited successfully!");
define('PAGE_NOT_EDITED',"Page not edited! Please try again.");
//----------------------------------------------------------------------------------
