<?php
$headerData = $this->headerlib->data();
if(isset($getUserData) && $getUserData != '') {
  extract($getUserData);
}

$form_attr  =
array(
  'name'    =>  'admin-form',
  "id"    =>  "validateForm",
  'method'  =>  'post',
  'class'     =>  "form-horizontal",
  'role'  =>'form'
  );
$first_name =
array(
  'name'      =>  'firstname',
  'id'      =>  'firstname',
  'placeholder'      =>  'First name',
  'value'     => (isset($firstname) && $firstname!= '')?$firstname:'',
  'type'          => 'text',
  'required' => 'required',
  'class'         => 'form-control'
  );
$last_name =
array(
  'name'      =>  'lastname',
  'id'      =>  'lastname',
  'placeholder'      =>  'Last name',
  'value'     => (isset($lastname) && $lastname!= '')?$lastname:'',
  'type'          => 'text',
  'class'         => 'form-control'
  );
$email =
array(
  'name'      =>  'email',
  'id'      =>  'email',
  "required"    =>  "required",
  'placeholder'      =>  'Email',
  "data-errortext"=>  "This is email address!",
  'value'     => (isset($email) && $email != '')?$email:'',
  'type'          => 'email',
  'class'         => 'form-control'
  );
$password_field =
array(
  'name'      =>  'password',
  'id'      =>  'password',
  "required"    =>  "required",
  'minlength' => '5',
  'placeholder'      =>  'Password',
  "data-errortext"=>  "This is password!",
  'value'     => '',
  'type'          => 'password',
  'class'         => 'form-control maxwidth500'
  );

$activstatus =
array(
  'name'        => 'status',
  'value'       => 'Active',
  'checked'   => (isset($status) && $status == 'Active')?'TRUE':'FALSE'
  );

$inactivstatus =
array(
  'name'        => 'status',
  'value'       => 'Inactive',
  'checked'   => (isset($status) && $status == 'Inactive')?'TRUE':'FALSE'
  );
    // Setting Hidden action attributes for Add/Edit functionality.
$hiddeneditattr =
array(
  "action"  =>  "backoffice.adminedit"
  );
$hiddenaddattr = array(
  "action"  =>  "backoffice.adminadd"
  );
$admin_id     = array(
   'id'        => (isset($id) && $id != '')?$id:''
  );
$submit_attr  = array(
  'class'   => 'submit btn btn-primary marginright20',
  'value' => "$ACTION_LABEL Admin",
  'type' =>'submit'
  );
$cancel_attr  = array(
  'class'   => 'btn btn-inverse ',
  'value' => "Reset",
  'type' =>'reset'
  );
  ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= DISPLAY_APP_NAME ?> | Dashboard</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo 'Admin'; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href = "<?php echo BASEURL; ?>admin"><i class="fa fa-user"></i> Admin</a></li>
        <li class="active"><?php echo $ACTION_LABEL; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <!-- right column -->
      <div class="row">
            <div class="col-md-12">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"><?php echo $title; ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                  <div class="box-body">
                    <?php echo form_open("admin/add",$form_attr);
                    if(isset($id) && $id != '')
                    {
                      echo form_hidden($admin_id);
                      echo form_hidden($hiddeneditattr);
                    }else{
                      echo form_hidden($hiddenaddattr);
                    }?>
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">First Name<span style="color:red">*</span></label>

                      <div class="col-sm-6">
                        <?php echo form_input($first_name); ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-2 control-label">Last Name</label>

                      <div class="col-sm-6">
                        <?php echo form_input($last_name); ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-2 control-label">Email<span style="color:red">*</span></label>

                      <div class="col-sm-6">
                         <?php echo form_input($email); ?>
                      </div>
                    </div>
                    <?php if (!empty($getUserData)) { ?>
                      <div class="form-group">
                        <label class="col-lg-2 control-label"></label>
                        <div class="col-sm-6 center maxwidth500 ">
                          <button id="passchange" class="btn btn-info">Change Password</button>
                        </div>
                      </div>
                    <?php } ?>
                    <div class="form-group <?php echo (isset($id) && $id != '')?'passtohide':''   ?>">
                      <label for="inputPassword3" class="col-sm-2 control-label">Password<span class="required">*</span></label>

                      <div class="col-sm-6">
                          <?php echo form_input($password_field); ?>
                      </div>
                    </div>
                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <div class="row">
                      <div class="col-sm-3">
                      </div>
                      <div class="col-sm-6">
                          <button type="reset" class="btn btn-default">Cancel</button>
                          <button type="submit" class="btn btn-info">Save</button>
                      </div>
                      <div class="col-sm-3">
                      </div>
                    </div>
                  </div>
                  <?php echo form_close(); ?>
                  <!-- /.box-footer -->
              </div>
              <!-- /.box -->
            </div>
       </div>
        <!--/.col (right) -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<?php echo $headerData['javascript']; ?>
<script>
   jQuery(document).ready(function()
      {
          $("#validateForm").validate({
            rules: {
              firstname: {
                required: true
              },
              email: {
                required: true,
                email:true
              },
              password: {
                required: true,
                minlength: 5
              }
            },
            messages: {
              email: {
                required:"Please enter a email",
                email:"Please enter a valid email"
              },
              firstname: "Please enter first name",
              password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 5 characters long"
              }
            },
            highlight: function(element) {
              $(element).closest('.form-group').addClass('has-error');
            },
            unhighlight: function(element) {
                $(element).closest('.form-group').removeClass('has-error');
            },
            errorElement: 'span',
            errorClass: 'val-erro-a94442',
            errorPlacement: function(error, element) {
              error.insertAfter(element);
            },
            submitHandler: function(form) {
              form.submit();
            } 
          });
      });
</script>
</body>
</html>