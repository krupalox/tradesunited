<?php
$headerData = $this->headerlib->data();
?>
<!doctype html>
  <html lang="en-us">
  <head>
    <title>Login</title>
    <?php echo  $headerData['meta_tags']; ?>
    <!-- STYLESHEETS --><!--[if lt IE 9]><script src="js/flot/excanvas.min.js"></script><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
    <?php echo  $headerData['stylesheets']; ?>
  </head>
  <body>
    <div class="app app-header-fixed">
      <div class="container w-xxl w-auto-xs whiteBck">
        <a href style="text-align:center;" class="block m-t">
        <h2><?= DISPLAY_APP_NAME ?></h2>
        </a>
        <div class="m-b-lg">
          <div class="wrapper text-center">
            <strong>Change Password</strong>
          </div>
            <form role="form" method="POST" action="<?php echo DOMAIN_URL; ?>Login/reset_pass/<?php echo time(); ?>" id="resetPWDForm">
                <input type="hidden" value="<?=$id ?>" name="vForgotPassword">
                  <div class="form-group">
                    <div class="input-group-lg">
                      <input type="password" class="form-control text-control" id="vPassword" name="vPassword" placeholder ="New Password">
                  </div>
                  </div>

                  <div class="form-group">
                    <div class="input-group-lg">
                      <input type="password" class="form-control text-control" id="vRePassword" name="vRePassword" placeholder ="Confirm Password">
                  </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4">
                        <div class="form-group">
                              <div class="input-group-lg">
                                <input type="submit" name="vSignup" value="Submit" class="signupButton" style="padding: 10px;">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4"></div>
                  </div>
            </form>
        </div>
        <div class="text-center">
          <p>
            <small class="text-muted">&copy;<?php echo date('Y'); ?></small>
          </p>
        </div>
      </div>
    </div>
    <?php echo  $headerData['login_javascripts']; ?>
    <script>
      jQuery(document).ready(function()
      {
        jQuery("#resetPWDForm").validate({
          rules: {
            vPassword: {
              required: true
            },
            vRePassword: {
              required: true
            }
          },
          messages: {
            vPassword: {
              required:"Please enter password"
            },
            vRePassword: {
              required: "Please provide a password"
            }
          }
        });
      });
    </script>
  </body>
  </html>