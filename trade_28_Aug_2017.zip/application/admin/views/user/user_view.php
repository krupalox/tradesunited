<?php
$headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | User</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/css/jquery.fancybox.min.css">
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/alertify.min.css"/> -->
    <!-- Default theme -->
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/themes/default.min.css"/> -->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper"> 
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo BASEURL; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
          <?php $this->General_model->getMessages()?>
            <!-- /.box-header -->
             <div class="box-body">
              <table id="user_datatable" class="table table-bordered table-striped dataTable"  cellpadding="0" cellspacing="0" border="0">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Profile image</th>
                  <th>Address</th>
                  <th>Trade</th>
                  <!-- <th>Expense Count</th> -->
                  <th>Created on</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
                <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Profile image</th>
                  <th>Address</th>
                  <th>Trade</th>
                 <!--  <th>Expense Count</th> -->
                  <th>Created on</th>
                  <th>Status</th>
                </tr>
                </tfoot>
              </table>
            </div> 
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>   <!-- /.content --> 
</div> <!-- /.content-wrapper --> 
<?php echo $headerData['javascript']; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/js/jquery.fancybox.min.js"></script> 
<!-- <script src="//cdn.jsdelivr.net/alertifyjs/1.8.0/alertify.min.js"></script> -->


<script>
  $(document).ready(function()
  {
     var orderColumn = {no:'5',order:'desc'};
     var controllerName = "<?=$this->uri->segment(1);?>";

     var columnsObj =  [
     { data: "vFullName","sWidth":"10%" },
     { data: "vEmail","sWidth":"10%" },
     { data: "vProfileImage","sWidth":"10%" },
     { data:'vAddress',"sWidth":"15%" },
     { data: "vTradeName","sWidth":"10%" },
     // { data: "expenseCount","sWidth":"10%" }, uncomment for expense module
     { data: "dtCreated","sWidth":"15%" },
     { data: "eStatus","sWidth":"25%" , "bSortable":false }
     ];


  var columnDefsObj = [
    {
        render: function ( data, type, row ) {          
         if(data==null){
          return "<img class='borderradius5px img_cms_table' src="+BASEURL+"images/common/no-image-list.png width='50' height='50' /><br>";
        }else{
          return "<a data-toggle='tooltip' data-caption='"+row.vFullName+"' data-placement='top' title='click to view' class=fancy_box data-fancybox-group=gallery href="+row.vProfileImage+"><img class='borderradius5px img_cms_table' src="+row.vProfileImageThumb+" width='50' height='50' /></a><br>";
        }

      },
       targets: 2
    },
    // {
    //     render: function ( data, type, row ) {          
    //      if(data==0){
    //       return data;
    //     }else{
    //       return "<a href='<?= BASEURL ?>Userexpense/getUserExpenseDetail/"+ row.iUserID +"' title='Click to see expenses'><span class='badge'>" + data + "</span></a><br>";
    //     }

    //   },
    //   targets: 5
    // },
    {
      render: function ( data, type, row ) {
        var str = '<button title="Delete" class="btn-sm btn btn-danger marginright10 margintopbottom margin"  onclick=deleteOne('+row.iUserID+',event,user_datatable,"'+controllerName+'")><i class="fa fa-times"></i> Delete</button>';
        if(row.eStatus == 'Active')
        {
          str += '<a title="Click to Inactive"  onclick=changeStatus('+row.iUserID+',event,user_datatable,"'+controllerName+'") class="btn-sm btn btn-success marginright10"> Active</a>';
        }
        else
        {
          str += '<a title="Click to Active" onclick=changeStatus('+row.iUserID+',event,user_datatable,"'+controllerName+'") class="btn-sm btn btn-danger"> Inactive </a>';
        }
        return str;
      },
      targets: 6
      //targets: 7
    }
  ];

    initializeDatatableMain('user_datatable','user/datatable_source','user/datatable_source_export/user','user/deleteAll','user/changeStatusAll',columnsObj,columnDefsObj,orderColumn);
});


</script>
</body>
</html>