<?php
$headerData = $this->headerlib->data();
          if(isset($getUserData) && $getUserData != '')
            extract($getUserData);

          $form_attr  = array(
            'name'    =>  'admin-form',
            "id"    =>  "validateForm",
            'method'  =>  'post',
            'class'     =>  "form-horizontal",
            'role'  =>'form'
            );
          $oldPassword  = array(
            'type' => 'password',
            'name'      =>  'oldpassword',
            'id' => 'oldpassword',
            'title'     =>  'Your old password',
            "required"    =>  "required",
            "data-errortext"=> "This is your old password!",
            'class'         => 'form-control maxwidth500'
            );
          $newPassword  = array(
            'type' => 'password',
            'name'      =>  'password',
            'title'     =>  'Your new password',
            "required"    =>  "required",
            "data-errortext"=> "This is your new password!",
            "class"     => "form-control maxwidth500"
            );
          $submit_attr  = array(
            'class'   => 'submit btn btn-primary marginright20',
            'value' => "Submit",
            'type' =>'submit'
            );
          $cancel_attr  = array(
            'class'   => 'btn btn-inverse ',
            'value' => "Reset",
            'type' =>'reset'
            );
?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= DISPLAY_APP_NAME; ?> | Change password</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo 'Change password'; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href = "<?php echo BASEURL; ?>"><i class="fa fa-user"></i> Home</a></li>
        <li class="active"><?php echo 'Change Password'; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <!-- right column -->
      <div class="row">
            <div class="col-md-12">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"><?php echo 'Change Password'; ?></h3>
                </div>
                <?php $this->General_model->getMessages()?>
                <!-- /.box-header -->
                <!-- form start -->
                  <div class="box-body">

                  <?php echo form_open("changepassword",$form_attr); ?>
                    <div class="form-group">
                      <label class="col-lg-2 control-label">Old Password<span style="color:red">*</span></label>
                      <div class="col-lg-6">
                        <?php echo form_input($oldPassword); ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-lg-2 control-label">New Password<span style="color:red">*</span></label>
                      <div class="col-lg-6">
                        <?php echo form_input($newPassword); ?>
                      </div>
                    </div>

                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <div class="row">
                      <div class="col-sm-3">
                      </div>
                      <div class="col-sm-6">
                          <button type="reset" class="btn btn-default">Cancel</button>
                           <?php echo form_input($submit_attr); ?>
                      </div>
                      <div class="col-sm-3">
                      </div>
                    </div>
                  </div>
                  <?php echo form_close(); ?>
                  <!-- /.box-footer -->
              </div>
              <!-- /.box -->
            </div>
       </div>
        <!--/.col (right) -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<?php echo $headerData['javascript']; ?>
<script>
      jQuery(document).ready(function() {
        App.setPage("forms");
        App.init();
        $("#validateForm").validate({
          rules: {
            password: {
              required: true,
              minlength: 5
            },
            oldpassword: {
              required: true,
              minlength: 5,
            }
          },
          messages: {
            password: {
              required: "Please provide a new password",
              minlength: "Your password must be at least 5 characters long"
            },
            oldpassword: {
              required: "Please provide an old password",
              remote: jQuery.format('{0} is already in use, please choose a different name'),
              minlength: "Your password must be at least 5 characters long",
            },
          }
        });
      });
</script>
</body>
</html>