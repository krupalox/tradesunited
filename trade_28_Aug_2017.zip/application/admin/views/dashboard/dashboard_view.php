<?php
$headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= DISPLAY_APP_NAME; ?> | Dashboard</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Admin panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
	   
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $total_admin ?></h3>

              <p><?php echo ($total_admin > 1)?'Admins':'Admin'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-lock"></i>
            </div>
            <a href="<?php echo BASEURL; ?>admin" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		<div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $total_user ?></h3>

              <p><?php echo ($total_user > 1)?'Users':'User'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="<?php echo BASEURL; ?>User" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $total_TradeCategory ?></h3>

              <p><?php echo ($total_TradeCategory > 1)?'Trade Categories':'Trade Category'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-briefcase"></i>
            </div>
            <a href="<?php echo BASEURL; ?>Trade" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
 
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3><?php echo $total_postCategory ?></h3>

              <p><?php echo ($total_postCategory > 1)?'Post Categories':'Post Category'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-sitemap"></i>
            </div>
            <a href="<?php echo BASEURL; ?>PCategory" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php echo $total_expensecategory ?></h3>

              <p><?php echo ($total_expensecategory > 1)?'Expense Categories':'Expense Category'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-usd"></i>
            </div>
            <a href="<?php echo BASEURL; ?>Expensecategory" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		
		 <div class="col-lg-3 col-xs-6"> 
            <div class="small-box bg-purple">
            <div class="inner">
              <h3><?php echo $total_logbook ?></h3>

              <p><?php echo ($total_logbook > 1)?'User Logbook':'User Logbook'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-book"></i>
            </div>
            <a href="<?php echo BASEURL;?>Logbook" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div> 


          <div class="col-lg-3 col-xs-6"> 
            <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $total_Userpost ?></h3>

              <p><?php echo ($total_Userpost > 1)?'User posts':'User post'; ?></p>
            </div>
            <div class="icon">
              <i class="fa fa-commenting"></i>
            </div>
            <a href="<?php echo BASEURL; ?>Userpost" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div> 
		
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<?php echo $headerData['javascript']; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script>
</script>
</body>
</html>



