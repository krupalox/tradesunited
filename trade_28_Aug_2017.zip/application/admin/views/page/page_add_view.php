<?php
$headerData = $this->headerlib->data();
if(isset($getPageData) && $getPageData != '') {
  extract($getPageData);
  // mpr($getData);
}

$form_attr  =
array(
  'name'    =>  'page-form',
  "id"    =>  "validateForm",
  'method'  =>  'post',
  'class'     =>  "form-horizontal",
  'role'  =>'form'
  );
$page_name =
array(
  'name'      =>  'title',
  'id'      =>  'page_title',
  'placeholder'      =>  'Page title',
  'value'     => (isset($title) && $title!= '')?$title:'',
  'type'          => 'text',
  'required'  => 'yes',
  'class'         => 'form-control maxwidth500'
  );
// Setting Hidden action attributes for Add/Edit functionality.
$hiddeneditattr =
array(
  "action"  =>  "backoffice.edit"
  );
$hiddenaddattr = array(
  "action"  =>  "backoffice.add"
  );
$unique_id     = array(
  "id"  => (isset($id) && $id != '')?$id:''
  );
$submit_attr  = array(
  'class'   => 'submit btn btn-primary marginright20',
  'value' => "$ACTION_LABEL Page",
  'type' =>'submit'
  );
$cancel_attr  = array(
  'class'   => 'btn btn-inverse ',
  'value' => "Reset",
  'type' =>'reset'
  );
  ?>

 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | Page</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo 'Page'; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href = "<?php echo BASEURL; ?>Page"><i class="fa fa-user"></i> Page</a></li>
        <li class="active"><?php echo $ACTION_LABEL; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <!-- right column -->
      <div class="row">
            <div class="col-md-12">
              <!-- Horizontal Form -->
               <?php echo form_open("page/add",$form_attr);
                    if(isset($id) && $id != '')
                    {
                      echo form_hidden($unique_id);
                      echo form_hidden($hiddeneditattr);
                    }else{
                      echo form_hidden($hiddenaddattr);
                    }?>
                <div class="box box-info">
                  <div class="box-header with-border">
                    <h3 class="box-title"><?php echo $title; ?></h3>
                  </div>
                  <!-- /.box-header -->
                  <!-- form start -->
                    <div class="box-body">
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Page name<span style="color:red">*</span></label>
                        <div class="col-sm-6">
                          <?php echo form_input($page_name); ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Description<span style="color:red">*</span></label>
                        <div class="col-sm-6">
                          <textarea name="description" id="description">
                            <?php echo (isset($description) && $description != '')?$description:'' ?>
                          </textarea>
                        </div>
                      </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <div class="row">
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-6">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button class="btn btn-primary" id="submit" type="submit">Save</button>
                        </div>
                        <div class="col-sm-3">
                        </div>
                      </div>
                    </div>
                    <!-- /.box-footer -->
                </div>
               <?php echo form_close(); ?>
              <!-- /.box -->
            </div>
       </div>
        <!--/.col (right) -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<?php echo $headerData['javascript']; ?>
<script>
      CKEDITOR.replace('description');
      jQuery(document).ready(function()
      {
        tinymce.init({ selector:'#description',theme: "modern",height: 300,width:550 });        
        $("#validateForm").validate({
          rules: {
            title: {
              required: true
            }
          },
          messages: {
            title: "Please enter a page title"
          }
        });
      });
</script>
</body>
</html>