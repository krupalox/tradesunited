  <?php $segment = $this->uri->segment(1); ?>
  <?php $segment2 = $this->uri->segment(2); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar padding-top0">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo BASEURL.'images/user.png'; ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $this->session->userdata('ADMINFIRSTNAME')." ".$this->session->userdata('ADMINLASTNAME'); ?></p>
          <a href="#"> Admin</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="treeview <?php echo ($segment == 'dashboard') ? 'active' : ''; ?>">
          <a href="<?php echo BASEURL ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li class="treeview <?php echo ($segment == 'admin') ? 'active' : ''; ?>">
          <a href="#">
            <i class="fa fa-lock"></i> <span>Admin</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo ($segment2 != 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>admin">
                <i class="fa fa-circle-o"></i> View
              </a>
            </li>
            <li class="<?php echo ($segment2 == 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>admin/add">
                <i class="fa fa-circle-o"></i> Add
              </a>
            </li>
          </ul>
        </li>

         <li class="treeview <?php echo ($segment == 'user' && $segment2 == '') ? 'active' : ''; ?>">
            <a href="<?php echo BASEURL ?>user">
              <i class="fa fa-user"></i> <span>User</span>
            </a>
        </li>

        <li class="treeview <?php echo ($segment == 'PCategory') ? 'active' : ''; ?>">
          <a href="#">
            <i class="fa fa-sitemap"></i> <span>Post categories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo ($segment2 != 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>PCategory">
                <i class="fa fa-circle-o"></i> View
              </a>
            </li>
            <li class="<?php echo ($segment2 == 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>PCategory/add">
                <i class="fa fa-circle-o"></i> Add
              </a>
            </li>
          </ul>
        </li>
		
		 <li class="treeview <?php echo ($segment == 'Trade') ? 'active' : ''; ?>">
          <a href="#">
            <i class="fa fa-briefcase"></i> <span>Trade categories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo ($segment2 != 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>Trade">
                <i class="fa fa-circle-o"></i> View
              </a>
            </li>
            <li class="<?php echo ($segment2 == 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>Trade/add">
                <i class="fa fa-circle-o"></i> Add
              </a>
            </li>
          </ul>
        </li>

        <li class="treeview <?php echo ($segment == 'Expensecategory') ? 'active' : ''; ?>">
          <a href="#">
            <i class="fa fa-usd" aria-hidden="true"></i> <span>Expense categories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo ($segment2 != 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>Expensecategory">
                <i class="fa fa-circle-o"></i> View
              </a>
            </li>
            <li class="<?php echo ($segment2 == 'add') ? 'active' : ''; ?>">
              <a href="<?php echo BASEURL; ?>Expensecategory/add">
                <i class="fa fa-circle-o"></i> Add
              </a>
            </li>
          </ul>
        </li>
		
		
		
         <li class="treeview <?php echo ($segment == 'Logbook' && $segment2 == '') ? 'active' : ''; ?>">
            <a href="<?php echo BASEURL ?>Logbook">
              <i class="fa fa-book" aria-hidden="true"></i> <span>User Logbook</span>
            </a>
        </li> 

         <li class="treeview <?php echo ($segment == 'Userpost' && $segment2 == '') ? 'active' : ''; ?>">
            <a href="<?php echo BASEURL ?>Userpost">
              <i class="fa fa-commenting" aria-hidden="true"></i> <span>User posts</span>
            </a>
        </li> 



        <li class="treeview <?php echo ($segment == 'Page' && $segment2 == '') ? 'active' : ''; ?>">
            <a href="<?php echo BASEURL ?>Page">
              <i class="fa fa-file-text-o"></i> <span>Page</span>
            </a>
        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>