<?php
$headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | Reported Post</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/css/jquery.fancybox.min.css">
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/alertify.min.css"/> -->
    <!-- Default theme -->
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/themes/default.min.css"/> -->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Reported Post </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo BASEURL; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Reportedpost</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
          <?php $this->General_model->getMessages()?>
            <!-- /.box-header -->
             <div class="box-body">
              <table id="user_datatable" class="table table-bordered table-striped dataTable"  cellpadding="0" cellspacing="0" border="0">
                <thead>
                  <tr>
					<th>Post Title</th>
 					<th>Post Description</th>
 					<th>Post Image</th>
					<th>Reported Count</th>
 					<th>Created on</th>
                </tr>
                </thead>
                <tbody> </tbody>
                <tfoot>
                 <tr>
                    <th>Post Title</th>
 					<th>Post Description</th>
 					<th>Post Image</th>
					<th>Reported Count</th>
 					<th>Created on</th>
                </tr>
                </tfoot>
              </table>
            </div> 
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>   <!-- /.content --> 
</div> <!-- /.content-wrapper --> 
<?php echo $headerData['javascript']; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/js/jquery.fancybox.min.js"></script> 
<!-- <script src="//cdn.jsdelivr.net/alertifyjs/1.8.0/alertify.min.js"></script> -->


<script>
  $(document).ready(function()
  {
     var orderColumn = {no:'4',order:'desc'};
     var controllerName = "<?=$this->uri->segment(1);?>"; 
     var columnsObj =  [
						{ data: "vTitle","sWidth":"25%" },
						{ data: "vDetail","sWidth":"40%" },
						{ data: "vPostImage","sWidth":"10%" },
						{ data: "reported_count","sWidth":"10%" },
 						{ data: "dtCreated","sWidth":"15%" } 						
     				   ];
 
    var columnDefsObj = [
							{
							render: function ( data, type, row ) { 
										return "<a href='<?php echo BASEURL ?>user/ReportedpostDetail/"+ row.iUserPostID + "'title='Click to see User List'  class='btn btn-primary margin marginright10'><span class='label123'>"+data+"</span></a>";
								},
							targets: 3
							},
							{
							render: function ( data, type, row ) {          
									 return "<a data-toggle='tooltip' data-caption='"+row.vTitle+"' data-placement='top' title='click to view' class=fancy_box data-fancybox-group=gallery href="+row.vPostImage+"><img class='borderradius5px img_cms_table' src="+row.vPostImageThumb+" width='50' height='50' /></a><br>";
							  },
							targets: 2
							}
							
						];

    initializeDatatableMain('user_datatable','Reportedpost/datatable_source','','','',columnsObj,columnDefsObj,orderColumn);
});


</script>
</body>
</html>