<?php
$headerData = $this->headerlib->data();
if(isset($getUserData) && $getUserData != '') {
  extract($getUserData);
}

$form_attr  =
array(
  'name'    =>  'admin-form',
  "id"    =>  "validateForm",
  'method'  =>  'post',
  'class'     =>  "form-horizontal",
  'role'  =>'form'
  );

$post_name =
array(
  'name'      =>  'vCatName',
  'id'      =>  'vCatName',
  'placeholder'      =>  'Category post',
  'value'     => (isset($vCatName) && $vCatName!= '')?$vCatName:'',
  'type'          => 'text',
  'required' => 'required',
  'class'         => 'form-control'
  );

$color_code =
array(
  'name'      =>  'vColorCode',
  'id'      =>  'vColorCode',
  'placeholder'      =>  'Select color',
  'value'     => (isset($vColorCode) && $vColorCode!= '#000000')?$vColorCode:'#000000',
  'type'          => 'text',
  'required' => 'required',
  'class'         => 'form-control jscolor'
  );

$hiddeneditattr =
array(
  "action"  =>  "backoffice.adminedit"
  );
$hiddenaddattr = array(
  "action"  =>  "backoffice.adminadd"
  );
$postCat_id     = array(
   'id'        => (isset($iPostCatID) && $iPostCatID != '')?$iPostCatID:''
  );
$submit_attr  = array(
  'class'   => 'submit btn btn-primary marginright20',
  'value' => "$ACTION_LABEL Category",
  'type' =>'submit'
  );
$cancel_attr  = array(
  'class'   => 'btn btn-inverse ',
  'value' => "Reset",
  'type' =>'reset'
  );
  ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= APP_NAME; ?> | Post categories</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link href="<?= DOMAIN_URL ?>admin/css/other/bootstrap-colorpicker.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo 'Post categories'; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href = "<?php echo BASEURL; ?>PCategory"><i class="fa fa-briefcase"></i> Post categories</a></li>
        <li class="active"><?php echo $ACTION_LABEL; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <!-- right column -->
      <div class="row">
            <div class="col-md-12">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"><?php echo $title; ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                  <div class="box-body">
                    <?php echo form_open("PCategory/add",$form_attr);
                    if(isset($iPostCatID) && $iPostCatID != '')
                    {
                      echo form_hidden($postCat_id);
                      echo form_hidden($hiddeneditattr);
                    }else{
                      echo form_hidden($hiddenaddattr);
                    }
                    ?>
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Post category<span style="color:red">*</span></label>
                      <div class="col-sm-6">
                        <?php echo form_input($post_name); ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Color code<span style="color:red">*</span></label>
                      <div class="col-sm-6">
                        <?php echo form_input($color_code); ?>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Inner purchase</label>
                      <div class="col-sm-6">
                        <select class="form-control" id="eIsInnerPurchase" name="eIsInnerPurchase">
                          <option value="0" <?php if(@$eIsInnerPurchase == '0'){ echo "selected"; } ?> >No</option>
                          <option value="1" <?php if(@$eIsInnerPurchase == '1'){ echo "selected"; } ?> >Yes</option>
                        </select>
                      </div>
                    </div>

                    <div id="inn_purcDiv" style="display:<?= (@$eIsInnerPurchase=='1')?'display':'none';  ?>">
                      <div class="dis-b" id= "appendhere">



                        <?php
                        if(!empty(@$postCatResult))
                        {
                          foreach (@$postCatResult as $key => $value) { ?>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0 marginTop30 customeTime" id="timeSlotDiv">
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Inner purchase Detail</label>
                                <div class="col-sm-4">
                                  <input type="text" name="vPurchaseTitle[]" class="form-control vPurchaseTitle" id="vTitle<?= $key ?>" placeholder="Inner-purchase title" value="<?= $value['vPurchaseTitle']; ?>">
                                </div>
                                <div class="col-sm-2">
                                  <input type="text" name="dAmount[]" class="form-control dAmount0" id="dAmount<?= $key ?>" placeholder="Amount($)" value="<?= $value['dAmount']; ?>">  
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                  <button type="button" name="removeSlot" value="" class="btn btn-default closeButton"><i class="fa fa-times" aria-hidden="true"></i></button>
                                </div>
                            </div>
                          </div>

                        <?php  } } else { ?>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0 marginTop30 customeTime" id="timeSlotDiv">
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Inner purchase Detail</label>
                                <div class="col-sm-4">
                                  <input type="text" name="vPurchaseTitle[]" class="form-control vPurchaseTitle0" id="vTitle" placeholder="Inner-purchase title">
                                </div>
                                <div class="col-sm-2">
                                  <input type="text" name="dAmount[]" class="form-control dAmount0" id="dAmount" placeholder="Amount($)">  
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                  <button type="button" name="removeSlot" value="" class="btn btn-default closeButton"><i class="fa fa-times" aria-hidden="true"></i></button>
                                </div>
                            </div>
                          </div>

                        <?php } ?>

                      </div>
                      
                      <div class="form-group">
                          <label for="inputEmail3" class="col-sm-2 control-label"></label>
                          <div class="col-sm-6">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-6"> <input type="button" name="addSlot" id="addSlot" value="Add Slot" class="addSlotButton col-lg-12 col-md-12 col-sm-12 col-xs-12"></div>
                            <div class="col-lg-3"></div>
                          </div>
                      </div>
                    </div>



                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <div class="row">
                      <div class="col-sm-3">
                      </div>
                      <div class="col-sm-6">
                          <button type="reset" class="btn btn-default">Cancel</button>
                          <button type="submit" class="btn btn-info">Save</button>
                      </div>
                      <div class="col-sm-3">
                      </div>
                    </div>
                  </div>
                  <?php echo form_close(); ?>
                  <!-- /.box-footer -->
              </div>
              <!-- /.box -->
            </div>
       </div>
        <!--/.col (right) -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<?php echo $headerData['javascript']; ?>
<script src="<?= DOMAIN_URL ?>admin/js/other/bootstrap-colorpicker.js"></script>
<script>
   jQuery(document).ready(function()
      {

          $( "#eIsInnerPurchase" ).change(function() {
              if($(this).val() == "1")
              {
                  $('#inn_purcDiv').css('display','block');
              }
              else
              {
                  $('#inn_purcDiv').css('display','none');
              }
          });

          $('#addSlot').click(function()
          {
              var size = $('.vPurchaseTitle').length;
              var keySize = parseInt(size) + 1;

              var html = "<div class='form-group'><label for='inputEmail3' class='col-sm-2 control-label'>Inner purchase Detail</label><div class='col-sm-4'><input type='text' name='vPurchaseTitle[]' class='form-control vPurchaseTitle' id='vTitle"+keySize+"' placeholder='Inner-purchase title'></div><div class='col-sm-2'><input type='text' name='dAmount[]' class='form-control dAmount' id='dAmount"+keySize+"' placeholder='Amount($)'></div><div class='col-lg-2 col-md-2 col-sm-2 col-xs-2'><button type='button' name='removeSlot' value='' class='btn btn-default closeButton'><i class='fa fa-times' aria-hidden='true'></i></button></div></div>";
              
              $('#appendhere').append(html);
          });

          $(document).on('click','.closeButton',function(){
              var size = $('.vPurchaseTitle').length;
              if(size > 1)
              {
                  $(this).parent().parent().remove();      
              }
          });

          $(function () {
              $('#vColorCode').colorpicker({
                format: 'hex'
              });
          });

          $("#validateForm").validate({
            rules: {
              vCatName: {
                required: true
              },
              vColorCode: {
                required: true
              },
              "vPurchaseTitle[]": {
                  required: true
              },
              "dAmount[]": {
                  required: true
              }
            },
            messages: {
              vCatName: {
                required:"Please enter a Trade"
              },
              vColorCode: {
                required: "Please provide color code"
              },
              "vPurchaseTitle[]": {
                required: "Please provide purchase Title."
              },
              "dAmount[]": {
                required: "Please provide Amount."
              }
            },
            highlight: function(element) {
              $(element).closest('.form-group').addClass('has-error');
            },
            unhighlight: function(element) {
                $(element).closest('.form-group').removeClass('has-error');
            },
            errorElement: 'span',
            errorClass: 'val-erro-a94442',
            errorPlacement: function(error, element) {
              error.insertAfter(element);
            },
            submitHandler: function(form) {
              form.submit();
            } 
          });
      });
</script>
</body>
</html>