<?php
$headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | Trade</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/css/jquery.fancybox.min.css">
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/alertify.min.css"/> -->
    <!-- Default theme -->
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/themes/default.min.css"/> -->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Trade category management
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo BASEURL; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Trade</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
          <?php $this->General_model->getMessages()?>
            <!-- /.box-header -->
             <div class="box-body">
              <table id="trade_datatable" class="table table-bordered table-striped dataTable"  cellpadding="0" cellspacing="0" border="0">
                <thead>
                <tr>
                  <th>Category</th>
                  <th>Created on</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
                <tfoot>
                <tr>
                  <th>Category</th>
                  <th>Created on</th>
                  <th>Status</th>
                </tr>
                </tfoot>
              </table>
            </div> 
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>   <!-- /.content --> 
</div> <!-- /.content-wrapper --> 
<?php echo $headerData['javascript']; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/js/jquery.fancybox.min.js"></script> 
<!-- <script src="//cdn.jsdelivr.net/alertifyjs/1.8.0/alertify.min.js"></script> -->


<script>
  $(document).ready(function()
  {
     var orderColumn = {no:'2',order:'desc'};
     var controllerName = "<?=$this->uri->segment(1);?>";

     var columnsObj =  [
     { data: "vTradeName","sWidth":"10%" },
     { data: "dtCreated","sWidth":"20%" },
     // { data: "vProfileImage","sWidth":"10%" ,"searchable": false , "bSortable":false },
     { data: "iTradeID","sWidth":"30%" , "bSortable":false }
     ];


  var columnDefsObj = [
    {
      render: function ( data, type, row ) {
        var str = '<button title="Delete" class="btn-sm btn btn-danger marginright10 margintopbottom margin"  onclick=deleteOne('+row.iTradeID+',event,trade_datatable,"'+controllerName+'")><i class="fa fa-times"></i> Delete</button><a title="Edit" href="<?php echo BASEURL ?>Trade/add/'+btoa(data)+'/y"  class="btn-sm btn btn-primary marginright10 margin"><i class="fa fa-pencil-square-o"></i> Edit </a>';
        if(row.eStatus == 'Active')
        {
          str += '<a title="Click to Inactive"  onclick=changeStatus('+row.iTradeID+',event,trade_datatable,"'+controllerName+'") class="btn-sm btn btn-success marginright10"> Active</a>';
        }
        else
        {
          str += '<a title="Click to Active" onclick=changeStatus('+row.iTradeID+',event,trade_datatable,"'+controllerName+'") class="btn-sm btn btn-danger"> Inactive </a>';
        }
        return str;
      },
      targets: 2
    }
  ];

    initializeDatatableMain('trade_datatable','Trade/datatable_source','Trade/datatable_source_export/Trade_category','Trade/deleteAll','Trade/changeStatusAll',columnsObj,columnDefsObj,orderColumn);
});


</script>
</body>
</html>