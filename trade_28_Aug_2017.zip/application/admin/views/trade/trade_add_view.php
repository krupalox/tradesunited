<?php
$headerData = $this->headerlib->data();
if(isset($getUserData) && $getUserData != '') {
  extract($getUserData);
}

$form_attr  =
array(
  'name'    =>  'admin-form',
  "id"    =>  "validateForm",
  'method'  =>  'post',
  'class'     =>  "form-horizontal",
  'role'  =>'form'
  );
$trade_name =
array(
  'name'      =>  'vTradeName',
  'id'      =>  'vTradeName',
  'placeholder'      =>  'Trade',
  'value'     => (isset($vTradeName) && $vTradeName!= '')?$vTradeName:'',
  'type'          => 'text',
  'required' => 'required',
  'class'         => 'form-control'
  );

$hiddeneditattr =
array(
  "action"  =>  "backoffice.adminedit"
  );
$hiddenaddattr = array(
  "action"  =>  "backoffice.adminadd"
  );
$trade_id     = array(
   'id'        => (isset($iTradeID) && $iTradeID != '')?$iTradeID:''
  );
$submit_attr  = array(
  'class'   => 'submit btn btn-primary marginright20',
  'value' => "$ACTION_LABEL Category",
  'type' =>'submit'
  );
$cancel_attr  = array(
  'class'   => 'btn btn-inverse ',
  'value' => "Reset",
  'type' =>'reset'
  );
  ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= APP_NAME; ?> | Trade categories</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo 'Trade categories'; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href = "<?php echo BASEURL; ?>admin"><i class="fa fa-briefcase"></i> Trade</a></li>
        <li class="active"><?php echo $ACTION_LABEL; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <!-- right column -->
      <div class="row">
            <div class="col-md-12">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"><?php echo $title; ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                  <div class="box-body">
                    <?php echo form_open("Trade/add",$form_attr);
                    if(isset($iTradeID) && $iTradeID != '')
                    {
                      echo form_hidden($trade_id);
                      echo form_hidden($hiddeneditattr);
                    }else{
                      echo form_hidden($hiddenaddattr);
                    }?>
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label">Trade category<span style="color:red">*</span></label>
                      <div class="col-sm-6">
                        <?php echo form_input($trade_name); ?>
                      </div>
                    </div>
                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <div class="row">
                      <div class="col-sm-3">
                      </div>
                      <div class="col-sm-6">
                          <button type="reset" class="btn btn-default">Cancel</button>
                          <button type="submit" class="btn btn-info">Save</button>
                      </div>
                      <div class="col-sm-3">
                      </div>
                    </div>
                  </div>
                  <?php echo form_close(); ?>
                  <!-- /.box-footer -->
              </div>
              <!-- /.box -->
            </div>
       </div>
        <!--/.col (right) -->
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- BY ILA :: End Content Part -->
<?php  //$this->load->view('include/footer_view'); ?>
</div>
<!-- ./wrapper -->
<?php echo $headerData['javascript']; ?>
<script>
   jQuery(document).ready(function()
      {
          $("#validateForm").validate({
            rules: {
              vTradeName: {
                required: true
              }
            },
            messages: {
              vTradeName: {
                required:"Please enter a Trade"
              }
            },
            highlight: function(element) {
              $(element).closest('.form-group').addClass('has-error');
            },
            unhighlight: function(element) {
                $(element).closest('.form-group').removeClass('has-error');
            },
            errorElement: 'span',
            errorClass: 'val-erro-a94442',
            errorPlacement: function(error, element) {
              error.insertAfter(element);
            },
            submitHandler: function(form) {
              form.submit();
            } 
          });
      });
</script>
</body>
</html>