<?php
if($this->session->userdata('SUCCESS'))
{
		$errors = $this->session->userdata('SUCCESS');
		$this->session->unset_userdata('SUCCESS');
		foreach($errors as $key => $val) {
		    echo "<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><B><i class='icon fa fa-check'></i> Success !</B> ".$val."</div>";			
		}
}
?>    
            