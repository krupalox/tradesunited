<?php
if($this->session->userdata('INFO'))
{
	$errors = $this->session->userdata('INFO');
	$this->session->unset_userdata('INFO');
	foreach($errors as $key => $val){
		echo "<div class='alert alert-info alert-dismissible'>$val</div>";			
	}
}
?>