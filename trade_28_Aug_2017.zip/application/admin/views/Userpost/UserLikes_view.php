<?php
  $headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | Post likes</title>
  <?php echo $headerData['favicon']; ?>
  <?php echo $headerData['meta_tags']; ?>
  <?php echo $headerData['stylesheets']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/css/jquery.fancybox.min.css">
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/alertify.min.css"/> -->
    <!-- Default theme -->
  <!-- <link rel="stylesheet" href="//cdn.jsdelivr.net/alertifyjs/1.8.0/css/themes/default.min.css"/> -->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('include/header_view'); ?>
<!-- wrapper -->
<div class="wrapper">
<?php $this->load->view('include/sidebar_view'); ?>

<!-- BY ILA :: Contant Part  -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        User post likes
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo BASEURL; ?>Userpost"><i class="fa fa-commenting" aria-hidden="true"></i> Posts</a></li>
        <li class="active">Post Likes</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="box">
          <?php $this->General_model->getMessages()?>
            <!-- /.box-header -->
             <div class="box-body">

              <div class="row">
               <div class="col-md-12">
                  <div class="box box-solid box-primary">
                    <div class="box-header">
                      <h3 class="box-title"><i class="fa fa-user"></i>  <?php echo @$PostDetail['vfullname']; ?></h3>
                    </div><!-- /.box-header -->
                    <div class="box-body">
                     <div class="row">
                       <div class='col-lg-2'>Post image :</div>
                       <div class='col-lg-5'><img src="<?php echo @$PostDetail['vPostImageThumb']; ?>" alt='...'></div>
                     </div>
                     <div class="row">
                       <div class='col-lg-2'>Post title :</div>
                       <div class='col-lg-5'><?php echo @$PostDetail['vTitle']; ?></div>
                     </div>
                     <div class="row">
                       <div class='col-lg-2'>Post category :</div>
                       <div class='col-lg-5'><?php echo @$PostDetail['vCatName']; ?></div>
                     </div>
                     <div class="row">
                       <div class='col-lg-2'>Posted Date :</div>
                       <div class='col-lg-5'><?php echo @$PostDetail['dtCreated']; ?></div>
                     </div>
                    </div><!-- /.box-body -->
                  </div><!-- /.box -->
                </div>
              </div>

              <table id="userpost_datatable" class="table table-bordered table-striped dataTable"  cellpadding="0" cellspacing="0" border="0">
                <thead>
                <tr>
                  <th>Fullname</th>
                  <th>Created on</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
                <tfoot>
                <tr>
                  <th>Fullname</th>
                  <th>Created on</th>
                </tr>
                </tfoot>
              </table>
            </div> 
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>   <!-- /.content --> 
</div> <!-- /.content-wrapper --> 
<?php echo $headerData['javascript']; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.6/js/jquery.fancybox.min.js"></script> 
<!-- <script src="//cdn.jsdelivr.net/alertifyjs/1.8.0/alertify.min.js"></script> -->


<script>
  $(document).ready(function()
  {
     var orderColumn = {no:'6',order:'desc'};
     var controllerName = "<?=$this->uri->segment(1);?>";

     var columnsObj =  [
       { data: "vfullname","sWidth":"10%" },
       { data: "Created_at","sWidth":"10%" }
     ];

  var columnDefsObj = [
  ];

    initializeDatatableMain('userpost_datatable','Userpost/getPostLikesDetail/<?= $iUserPostID ?>','','','',columnsObj,columnDefsObj,orderColumn);
});


</script>
</body>
</html>