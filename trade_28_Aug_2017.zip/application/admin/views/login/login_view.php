<?php
$headerData = $this->headerlib->data();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo DISPLAY_APP_NAME; ?> | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <?php echo $headerData['favicon']; ?>
  <?php echo  $headerData['meta_tags']; ?>
  <?php echo  $headerData['basic_css']; ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 <style type="text/css">
 .heightWidth100 {
    height: 80px;
    width: 80px;
 }
 .marginbottom20 {
    margin-bottom: 20px;
 }
 .val-erro-a94442 {
  color: #dd4b39;
 }
 </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="#"><img src="<?php echo BASEURL.'images/logo1.png'; ?>" class="heightWidth100"></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to access admin panel</p>
   <form name="loginForm" id="loginForm" method="post" class="form-validation">
      <?php $this->General_model->getMessages(); ?>
      <div class="form-group has-feedback">
        <div class="">
          <input type="email" class="form-control" placeholder="Email" name="email">
          <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
      </div>
      <div class="form-group has-feedback">
        <div class="">
          <input type="password" class="form-control" placeholder="Password" name="password">
          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
      </div>
      <div class="row marginbottom20">
        <div class="col-xs-12">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
      <div class="text-center">
          <p>
            <small class="text-muted">&copy;<?php echo date('Y'); ?></small>
          </p>
        </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php echo $headerData['basic_javascripts']; ?>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

  jQuery(document).ready(function()
      {
        jQuery("#loginForm").validate({
          rules: {
            email: {
              required: true,
              email:true
            },
            password: {
              required: true
            }
          },
          messages: {
            email: {
              required:"Please enter a email",
              email:"Please enter a valid email"
            },
            password: {
              required: "Please provide a password"
            }
          },
          highlight: function(element) {
            $(element).closest('.form-group').addClass('has-error');
          },
          unhighlight: function(element) {
              $(element).closest('.form-group').removeClass('has-error');
          },
          errorElement: 'span',
          errorClass: 'val-erro-a94442',
          errorPlacement: function(error, element) {
            error.insertAfter(element);
          },
          submitHandler: function(form) {
            form.submit();
          }
        });
    });
</script>
</body>
</html>
