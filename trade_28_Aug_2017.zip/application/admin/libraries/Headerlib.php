<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Headerlib {

    public $doctype;
    public $title;
    public $body_id;
    public $icon_path;
    public $css_path;
    public $safari_css;
    public $opera_css;
    public $iphone_css;
    public $stylesheets;
    public $javascripts;
    public $basic_css;
    public $basic_javascripts;
    public $javascript_path;
    public $external_js;
    public $external_css;
    public $keywords;
    public $http_meta_tags;
    public $content_meta_tags;
    public $config;
    public $fancybox_path;

    public function __construct() {
        $this->doctype = 'XHTML1.1'; // Set the Doctype definition
        $this->title = MAINTITLE; // Set the default page title
        $this->body_id = "mainbody"; // Set the default body id (leave blank for no id)
        $this->icon_path = FAVICON_PATH; // Set default icon path for iPhone relative BASEURL.
        $this->css_path = CSS_URL; // Set default path to browser specific css files relative to BASEURL.
        $this->safari_css = TRUE; // Safari specific stylesheet
        $this->opera_css = FALSE; // Opera specific stylesheet
        $this->iphone_css = TRUE; // iPhone specific stylesheet

        $this->stylesheets = array(
            'theme' => 'bootstrap/bootstrap.min.css',
            'fancybox_css'=>'theme/theme.min.css',
            'bootstrapMinDT'=>'skins/_all-skins.min.css',
            'appcss' => 'plugin/blue.css',
            'style' => 'plugin/morris.css',
            'fontcss' => 'jvectormap/jquery-jvectormap-1.2.2.css',
            'font' => 'datepicker/datepicker3.css',
            'icons' => 'daterangepicker/daterangepicker.css',
            'animate' => 'bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css',
            'datatables'=>'datatables/dataTables.bootstrap.css',
            //"fancy"=>'fancy/jquery.fancybox.css',
            // 'fancybox'=>'fancybox/jquery.fancybox.css',
            // 'fancyboxbutton'=>'fancybox/jquery.fancybox-buttons.css',
            // 'fancyboxThumbs'=>'fancybox/jquery.fancybox-thumbs.css',
            'alertify' => 'alertify/alertify1.min.css',
            'alertify1' => 'alertify/alertfy2.css',
            //'fontawesome'=>'fontawesome/font-awesome.min.css',
            //'iconicons'=>'iconicons/ionicons.min.css',
            // 'alertifycore' => 'alertify/alertify.core.css',
            // 'alertifydefault' => 'alertify/alertify.default.css',
            'main'=> 'main.css'
        );
        
        $this->javascripts = array(
            "jquery"=>"bootstrap/jquery-3.1.1.min.js",
            "bootstrap" => "bootstrap/bootstrap.min.js",
            "datatables" => "datatables/jquery.dataTables.min.js",
            "dataTablesBoot" =>"datatables/dataTables.bootstrap.min.js",
            'jqueryDT3' => 'other/dataTables.buttons.min.js',
            "validate" =>"validate/validate.js",
            "fancy" =>"fancy/jquery.fancybox.pack.js",
            // "fancybox" => "fancybox/jquery.fancybox.pack.js",
            // "fancyboxbButton" => "fancybox/jquery.fancybox-buttons.js",
            // "fancyboxbMedia" => "fancybox/jquery.fancybox-media.js",
            // "fancyboxbThumbs" => "fancybox/jquery.fancybox-thumbs.js",
            "alertfy" => "alertfy/alertify1.js",
            //'jqueryDT4' => 'other/buttons.bootstrap.min.js',
            'main'=> 'other/main.js',
            // 'jqueryDT5' =>'js/jszip.min.js',
            // 'jqueryDT6' => 'js/pdfmake.min.js',
            // 'jqueryDT7' => 'js/vfs_fonts.js',
            // 'jqueryDT8' =>'js/buttons.html5.min.js',
            // 'jqueryDT9' => 'js/buttons.print.min.js',

            // "morris" =>  "morris/morris.min.js",
            // "sparkline" => "morris/jquery.sparkline.min.js",
            // "jvectormap" => "jvectormap/jquery-jvectormap-1.2.2.min.js",
            // "jvectormapworld" => "jvectormap/jquery-jvectormap-world-mill-en.js",
            // "knob" => "knob/jquery.knob.js",
            // "daterangepicker" => "daterangepicker/daterangepicker.js",
            // "datepicker" => "datepicker/bootstrap-datepicker.js",
            // "wysihtml5" => "bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js",
            // "slimscroll" => "slimscroll/jquery.slimscroll.min.js",
            // "fastclick" => "fastclick/fastclick.js",
            "app" => "theme/app.min.js",
            //"dashboard" => "theme/dashboard.js",
            //"demo" => "theme/demo.js",
            //"main" => "main.js"
        );

        $this->basic_css = array(
            'bootstrap' => 'bootstrap/bootstrap.min.css',
            'theme' => 'theme/theme.min.css',
            'blue' => 'plugin/blue.css',
            'main'=> 'main.css'
            );

        $this->basic_javascripts = array(
            "jquery"=>"bootstrap/jquery-3.1.1.min.js",
            "bootstrap" => "bootstrap/bootstrap.min.js",
            "icheck" => "icheck/icheck.min.js",
            "validate" =>"validate/validate.js",
            "main" => "main.js"
        );
       
        $this->javascript_path = JS_URL; // Set path to javascripts

        $this->external_js = array();
       
        $this->external_css = array(
            'jquerymin' => 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'
            );
        $this->keywords = '';
        $this->http_meta_tags = array();
        $this->content_meta_tags = array('description' => '',
                'apple-mobile-web-app-capable' => 'yes',
                'apple-mobile-web-app-status-bar-style' => 'black',
                'viewport' => 'width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no'
        );
    }


    public function add_meta_tag($name, $content) {
        $this->meta_tags[$name] = $content;
    }

    public function add_stylesheet($name, $file) {
        $this->stylesheets[$name] = $file;
    }

    public function add_javascript($name, $file) {
        $this->javascripts[$name] = $file;
    }


    //----- Added by ILA --------------
    public function data() {
        $data['doctype'] = $this->_doctype();
        $data['meta_tags'] = $this->_meta_tags();
        $data['basic_css'] = $this->_basic_css();
        $data['basic_javascripts'] = $this->_basic_javascripts();
        $data['stylesheets'] = $this->_stylesheets();
        $data['javascript'] = $this->_javascript();
        $data['title'] = $this->title;
        $data['body_id'] = $this->body_id;
        $data['favicon'] = $this->_favicon();
        return $data;
        //$data['browser'] = $this->_browser();
        //$data['os'] = $this->user_agent->platform();
        //$data['iphone_headers'] = $this->_iPhone_headers();
    }
    //----- End data function ---------

    private function _meta_tags() {
        $meta_tags = "<meta charset='utf-8'/>\n";
        foreach ($this->http_meta_tags as $http => $content) {
            $meta_tags .= '<meta http-equiv="' . $http . '" content="' . $content . '"/>' . "\n";
        }
        foreach ($this->content_meta_tags as $name => $content) {
            $meta_tags .= '<meta name="' . $name . '" content="' . $content . '"/>' . "\n";
        }
        return $meta_tags;
    }

    private function _stylesheets() {
        $stylesheets = "";
        foreach ($this->stylesheets as $name => $file) {
            if ($name == 'default') {
                $stylesheets .= '<link rel="stylesheet" id="skin-switcher" href="' . $this->css_path . $file . '" type="text/css" media="all" />' . "\n";
            } else {
                $stylesheets .= '<link rel="stylesheet" href="' . $this->css_path . $file . '" type="text/css" media="all" />' . "\n";
            }
        }
        if (count($this->external_css) > 0) {
            foreach ($this->external_css as $name => $url) {
                $stylesheets .= '<link rel="stylesheet" href="' . $url . '" type="text/css" media="all" />' . "\n";
            }
        }
        return $stylesheets;
    }

    private function _javascript() {
        $javascript_content = "\n";
        $javascript_content .= '<script type="text/javascript">var BASEURL = "' . BASEURL . '"; </script>' . "\n";
        foreach ($this->javascripts as $library => $file) {
            $javascript_content .= '<script src="' . $this->javascript_path . $file . '" type="text/javascript" charset="utf-8"></script>' . "\n";
        }
        if (count($this->external_js) > 0) {
            foreach ($this->external_js as $name => $url) {
                $javascript_content .= '<script type="text/javascript" id="' . $name . '" src="' . $url . '"></script>' . "\n";
            }
        }
        return $javascript_content;
    }

     private function _basic_css() {
        $basic_css = "";
        foreach ($this->basic_css as $name => $file) {
            if ($name == 'default') {
                $basic_css .= '<link rel="stylesheet" id="skin-switcher" href="' . $this->css_path . $file . '" type="text/css" media="all" />' . "\n";
            } else {
                $basic_css .= '<link rel="stylesheet" href="' . $this->css_path . $file . '" type="text/css" media="all" />' . "\n";
            }
        }
        if (count($this->external_css) > 0) {
            foreach ($this->external_css as $name => $url) {
                $basic_css .= '<link rel="stylesheet" href="' . $url . '" type="text/css" media="all" />' . "\n";
            }
        }
        return $basic_css;
    }

    private function _basic_javascripts() {
        $basic_javascripts = "\n";
        $basic_javascripts .= '<script type="text/javascript">var BASEURL = "' . BASEURL . '"; </script>' . "\n";
        foreach ($this->basic_javascripts as $library => $file) {
            $basic_javascripts .= '<script src="' . $this->javascript_path . $file . '" type="text/javascript" charset="utf-8"></script>' . "\n";
        }
        if (count($this->external_js) > 0) {
            foreach ($this->external_js as $name => $url) {
                $basic_javascripts .= '<script type="text/javascript" id="' . $name . '" src="' . $url . '"></script>' . "\n";
            }
        }
        return $basic_javascripts;
    }

    private function _doctype() {
        switch ($this->doctype) {
            case 'Strict':
            return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"' . "\n" . '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' . "\n";
            break;
            case 'Transitional':
            return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"' . "\n" . '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' . "\n";
            break;
            case 'Frameset':
            return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN"' . "\n" . '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' . "\n";
            case 'XHTML':
            return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"' . "\n" . '"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' . "\n";
            case 'XHTML1.0':
            return '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' . "\n";
            case 'XHTML1.1':
            return '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">' . "\n";
        }
    }
 
    private function _favicon() {
        $favicon = '<link rel="shortcut icon" type="image/x-icon"  href="' . $this->icon_path . 'favicon.ico" />';
        return $favicon;
    }
}
?>
