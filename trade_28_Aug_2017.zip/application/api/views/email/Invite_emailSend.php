<?php 

$html_new = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>

    <style type="text/css">
        html,
        body {
            Margin: 0 !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }        
        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }
        .ExternalClass {
            width: 100%;
        }
        
        div[style*="margin: 16px 0"] {
            margin:0 !important;
        }
        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }
        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            Margin: 0 auto !important;
        }
        table table table {
            table-layout: auto; 
        }
        img {
            -ms-interpolation-mode:bicubic;
        }
        .yshortcuts a {
            border-bottom: none !important;
        }
        .mobile-link--footer a,
        a[x-apple-data-detectors] {
            color:inherit !important;
            text-decoration: underline !important;
        }
    </style>
    <style>
        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
        .button-td:hover,
        .button-a:hover {
            background: #555555 !important;
            border-color: #555555 !important;
        }

    </style>

</head>
<body width="100%" height="100%" bgcolor="#000" style="Margin: 0;">
    <table cellpadding="0" cellspacing="0" border="0" height="100%" width="100%" bgcolor="#fff" style="border-collapse:collapse; background-color : gray;">
        <tr>
            <td valign="top">
                <center style="width: 100%;">
                    <div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
                        (Optional) This text will appear in the inbox preview, but not the email body.
                    </div>
                    <div style="max-width: 600px;">
                        <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="max-width: 600px;">
                            <tr>
                                <td style="padding: 20px 0; text-align: center">
                                    <img src="'.DOMAIN_URL.'/images/common/logo.jpg" width="100" height="100" alt="alt_text" border="0"></td>
                            </tr>
                        </table>
                        <table cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#ffffff" width="100%" style="max-width: 600px;">
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <td style="padding: 40px; font-family: sans-serif; font-size: 15px; mso-height-rule: exactly; line-height: 20px; color: #555555;">
                                                <center>
                                                    <h2>Roastking - Invitation</h2><br>
                                                    '.strtoupper(@$name).' inviting you to check out Roastking Application for smartphone.
                                                    <br>
                                                    <br>
                                                    <table cellspacing="0" cellpadding="0" border="0" align="center" style="Margin: auto;">
                                                    </table>
                                                    <br>
                                                    <hr>
                                                    </center>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#ffffff" align="center" height="100%" valign="top" width="100%">

                                        <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" style="max-width:560px;">
                                            <tr>
                                                <td align="center" valign="top" style="font-size:0; padding: 10px;">

                                                    <div style="display:inline-block; max-width:95%;  vertical-align:top; width:100%;" class="stack-column">
                                                        <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="padding: 0 20px;">
                                                                    <table cellspacing="0" cellpadding="0" border="0" width="100%" style="font-size: 14px;text-align: left;">
                                                                        <tr>
                                                                            <td style="text-align: center;">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="font-family: sans-serif; font-size: 14px; mso-height-rule: exactly; line-height: 20px; text-align: center; color: #555555; padding-top: 10px;" class="stack-column-center">
                                                                                you can connect to Roastking with mobile apps. Download our latest Roastking App from app-store from below link.
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="text-align: center;">
                                                                                <a href="#">
                                                                                    <img src="'.DOMAIN_URL.'images/google-play.png" width="200" alt="" style="border: 0;width: 100%;max-width: 150px;padding: 10px;" class="center-on-narrow"></a>
                                                                                <a href="#">
                                                                                    <img src="'.DOMAIN_URL.'images/itunes.png" width="200" alt="" style="border: 0;width: 100%;max-width: 150px;padding: 10px;" class="center-on-narrow"></a>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>

                                                </td>
                                            </tr>
                                        </table>
                                        </td>
                    </tr></table>
                    <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="max-width: 680px;">
                    <tr>
                        <td style="padding: 40px 10px;width: 100%;font-size: 12px; font-family: sans-serif; mso-height-rule: exactly; line-height:18px; text-align: center; color: #888888;">
                    </td>
                </tr>
            </table>
        </div>
    </center>
</td>
</tr>
</table>
</body>
</html>';


$this->email->set_newline("\r\n");
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
$this->email->initialize($config);
$this->email->from($from,'Roastking - Roastking Invitation.');
$this->email->to($email);
$this->email->subject($subject);
$this->email->message($html_new);

if($this->email->send())
{
    return;
}
else
{
    echo $this->email->print_debugger();
    exit;
}

?>