<?php
//$headerData = $this->headerlib->data();
?>
<!doctype html>
  <html lang="en-us">
  <head>
    <title>Reset Paasword</title>
    <?php //echo  $headerData['meta_tags']; ?>
    <!-- STYLESHEETS --><!--[if lt IE 9]><script src="js/flot/excanvas.min.js"></script><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->

    <?php //echo  $headerData['stylesheets']; ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/css/bootstrapValidator.min.css">
    <style type="text/css">

    	.paddingBottom50 {
    		padding-bottom: 50px;
    	}

    	.paddingtop50 {
    		padding-top: 50px;
    	}

    	.paddingtop20{
    		padding-top: 20px;
    	}

    </style>
  </head>
  <body style="background-color:#f0f3f4">
    <div class="app app-header-fixed paddingtop50">
      <div class="container w-xxl w-auto-xs whiteBck">

        <div class="paddingBottom50">
          <div> 
            <img style="text-align:center; display:block; margin-left:auto; margin-right:auto;" class="block m-t" width="50px" height="50px" src="<?php echo DOMAIN_URL; ?>admin/images/logo1.png">
          </div>
        	<div class="wrapper text-center">
            	<strong><?=$title?></strong>
          </div>
        </div>



        <div class="m-b-lg">

        	<div class="row">

        		<div class="col-lg-3 col-md-4 col-sm-4 col-xs-4"></div>
        		<div class="col-lg-6 col-md-4 col-sm-4 col-xs-4">
	        		<?php if($this->session->flashdata('success')){  ?>
		      			<div class="alert alert-success fade in">
						    <a href="#" class="close" data-dismiss="alert">&times;</a>
						    <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
						</div>
			      	<?php }else if($this->session->flashdata('error')){ ?>
			      		 <div class="alert alert-danger fade in">
						    <a href="#" class="close" data-dismiss="alert">&times;</a>
						    <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
						</div>
			      	<?php } ?>
			    </div>
			    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-4"></div>

        	</div>
          
          <div class="row">
          	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-4"></div>
          	<div class="col-lg-6 col-md-4 col-sm-4 col-xs-4">
				
				<?php 
				if ($isverify == 1) {
				?>
	          	<form role="form" method="POST" action="<?php echo SITEURL; ?>Forgot_password/reset_pass/<?php echo time(); ?>" id="resetPWDForm">
	                <input type="hidden" value="<?=$id ?>" name="id">
	                <input type="hidden" value="<?=$token ?>" name="token">
	                  <div class="form-group">
	                    <div class="input-group-lg">
	                      <input type="password" class="form-control text-control" id="vPassword" name="vPassword" placeholder ="New Password">
	                  </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="input-group-lg">
	                      <input type="password" class="form-control text-control" id="vRePassword" name="vRePassword" placeholder ="Confirm Password">
	                  </div>
	                  </div>

	                  <div class="row paddingtop20">
	                    <div class="col-lg-3"></div>
	                    <div class="col-lg-6">
	                        <div class="form-group">
	                              <div class="input-group-lg">
	                                <input type="submit" name="vSignup" value="Submit" class="form-control signupButton btn-primary" style="padding: 10px;">
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-lg-3"></div>
	                  </div>
	            </form>
				<?php } 
				elseif ($isverify == 0) { ?>
				
					<div class="row">
	                    <div class="col-lg-1"></div>
	                    <div class="col-lg-10">
	                        <div class="form-group">
							  <div class="input-group-lg" style="text-align:center"> 
								<span style="color:red">Opps!! The requested URL has been expired!</span> <br>
								<span>Please try forgot password from the Application.</span>	
							  </div>
 	                        </div>
	                    </div>
	                    <div class="col-lg-1"></div>
	                  </div>
				
				<?php }  
				elseif ($isverify == 2) {?>
					<div class="row">
	                    <div class="col-lg-1"></div>
	                    <div class="col-lg-10">
	                        <div class="form-group">
							  <div class="input-group-lg" style="text-align:center"> 
 								<span style="color:#00CC00">Please login from the Application.</span>
  							  </div>
 	                        </div>
	                    </div>
	                    <div class="col-lg-1"></div>
	                  </div>
				
				<?php } ?>
				
          	</div>
          	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-4"></div>
          </div>
        </div>
        <div class="text-center">
          <p>
            <small class="text-muted">&copy;<?php echo date('Y'); ?></small>
          </p>
        </div>
      </div>
    </div>
    <?php //echo  $headerData['login_javascripts']; ?>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js"></script>
    <script>
      jQuery(document).ready(function()
      {
        jQuery("#resetPWDForm").validate({
          rules: {
            vPassword: {
              required: true,
			  minlength: 8
            },
            vRePassword: {
              required: true,
              equalTo: "#vPassword",
			  minlength: 8			  
            }
          },
          messages: {
            vPassword: {
              required:"Please enter password"
            },
            vRePassword: {
              required: "Please provide a password"
            }
          },

       	highlight: function(element) {
        	$(element).closest('.form-group').addClass('has-error');
	    },
	    unhighlight: function(element) {
	        $(element).closest('.form-group').removeClass('has-error');
	    },
	    errorElement: 'span',
	    errorClass: 'help-block',
	    errorPlacement: function(error, element) {
    		 error.insertAfter(element);
    		return false;
	    },
        submitHandler: function(form) {
	         form.submit();
        }


        });
      });
    </script>
  </body>
  </html>