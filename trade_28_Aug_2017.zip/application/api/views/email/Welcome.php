<?php  
$html_new = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>

    <style type="text/css">
        html,
        body {
            Margin: 0 !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }        
        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }
        .ExternalClass {
            width: 100%;
        }
        
        div[style*="margin: 16px 0"] {
            margin:0 !important;
        }
        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }
        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            Margin: 0 auto !important;
        }
        table table table {
            table-layout: auto; 
        }
        img {
            -ms-interpolation-mode:bicubic;
        }
        .yshortcuts a {
            border-bottom: none !important;
        }
        .mobile-link--footer a,
        a[x-apple-data-detectors] {
            color:inherit !important;
            text-decoration: underline !important;
        }
    </style>
    <style>
        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
        .button-td:hover,
        .button-a:hover {
            background: #555555 !important;
            border-color: #555555 !important;
        }

    </style>

</head>
<body width="100%" height="100%" bgcolor="#000" style="Margin: 0;">
    <table cellpadding="0" cellspacing="0" border="0" height="100%" width="100%" bgcolor="#000" style="border-collapse:collapse; background-color : gray;">
        <tr>
            <td valign="top">
                <center style="width: 100%;">
                    <div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
                        (Optional) This text will appear in the inbox preview, but not the email body.
                    </div>
                    <div style="max-width: 600px;">
                        <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="max-width: 600px;">
                            <tr>
                                <td style="padding: 20px 0; text-align: center">
                                    <img src="'.DOMAIN_URL.'admin/images/logo1.png" width="100" height="100" alt="alt_text" border="0"></td>
                            </tr>
                        </table>
                        <table cellspacing="0" cellpadding="0" border="0" align="center" bgcolor="#ffffff" width="100%" style="max-width: 600px;">
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <td style="padding: 40px; font-family: sans-serif; font-size: 15px; mso-height-rule: exactly; line-height: 20px; color: #555555;">
                                                <center>
                                                    <h2>TradesUnite - Forgot Password</h2>
                                                     You have requested for forgot Password for your account. Please click on below button to reset your Password.
                                                    <br>
                                                    <br>
                                                    <table cellspacing="0" cellpadding="0" border="0" align="center" style="Margin: auto;">
                                                        <tr>
                                                            <td style="border-radius: 3px; background: #222222; text-align: center;" class="button-td">
                                                                <a href="'.$link.'" style="background: #222222; border: 15px solid #222222; padding: 0 10px;color: #ffffff; font-family: sans-serif; font-size: 13px; line-height: 1.1; text-align: center; text-decoration: none; display: block; border-radius: 3px; font-weight: bold;" class="button-a">Reset your password</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <br>
                                                    </center>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#ffffff" align="center" height="100%" valign="top" width="100%">
                                    </td>
                    </tr></table>
                    <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="max-width: 680px;">
                    <tr>
                        <td style="padding: 40px 10px;width: 100%;font-size: 12px; font-family: sans-serif; mso-height-rule: exactly; line-height:18px; text-align: center; color: #888888;">
                    </td>
                </tr>
            </table>
        </div>
    </center>
</td>
</tr>
</table>
</body>
</html>';
    //mprd(DOMAIN_URL.'admin/images/logo1.png');
$subject = 'TradesUnite - Forgot password';
$this->email->set_newline("\r\n");
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
$this->email->initialize($config);
$this->email->from($from,'TradesUnite - Forgot password');
$this->email->to($email);
$this->email->subject('TradesUnite - Forgot password');
$this->email->message($html_new);
$this->email->send();
return;
?>








