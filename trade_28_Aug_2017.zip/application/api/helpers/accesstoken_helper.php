<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('genratemac'))
{
	function genratemac($user_id)
	{
	
		$api_key_variable = config_item('rest_key_name');
		$key_name = 'HTTP_'.strtoupper(str_replace('-', '_', $api_key_variable));
		$key=$_SERVER[$key_name];

		$mac=hash_hmac('md5',$key,$user_id);

		$ci = & get_instance();
		//make it blank
		$data_blank = array('vHmac' => '');
		$ci->db->where('iUserID', $user_id);
		$ci->db->update('tbl_user', $data_blank);
		// update new key
		$data = array('vHmac' => $mac);
		$ci->db->where('iUserID', $user_id);
		$ci->db->update('tbl_user', $data);
		if ($ci->db->affected_rows() > 0)
		{
			return $mac;
		}
		else
		{
			return "";
		}
	}



	function checkmac()
	{
		
		//echo "<pre>"; print_r($_SERVER); exit;
		//echo $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'iuserid'))]; exit;

		if (isset($_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'iuserid'))]) && $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'iuserid'))] != "" && isset($_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'accesstoken'))]) && $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'accesstoken'))] != "")
		{
			$ci = & get_instance();
			$q = $ci->db->get_where('tbl_user',array('iUserID' => $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'iuserid'))],'vHmac' => $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'accesstoken'))]));
			if($q->num_rows() > 0)
			{
				$q=$q->row_array();
				$api_key_variable = config_item('rest_key_name');

				$key_name = 'HTTP_'.strtoupper(str_replace('-', '_', $api_key_variable));
				$key=$_SERVER[$key_name];
				$mac=hash_hmac('md5',$key,$q['iUserID']);
				
				if ($mac==$_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'accesstoken'))])
				{
					return true;
				}
				else
				{
					return "";
				}
			}
			else
			{
				return "";
			}
		}
		else
		{
			return "";
		}
	}

	function getuserid()
	{
		return $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', 'iuserid'))];
	}

	function delete_key() 
	{
		$api_key_variable = config_item('rest_key_name');
        $key = $_SERVER['HTTP_'.strtoupper(str_replace('-', '_', $api_key_variable))];
        $ci = & get_instance();
        if ($ci->db->get_where('keys', array('key' => $key))->num_rows() > 0) 
        {

            if (!$ci->db->delete('keys', array('key' => $key))) 
            {
                throw new RESTException('Improper data', 400);
            }
        }
    }
}