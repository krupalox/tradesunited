<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('general_model');
	}

	//Created By : ID on 18-1-2017
	//Created for : Check Email is exist or not
	public function check_email($email) {
		$q = $this->db->query("SELECT iUserID FROM tbl_user WHERE vEmail = '$email'");
		if($q->num_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	//Created By : ID on 19-4-2017
	//Created for : for user registration
	public function registration_basic($insertData) 
	{
 		$result = array(	
							'vFirstName'=>$insertData['vFirstName'],
							'vLastName'=>$insertData['vLastName'],
							'vUserName'=>$insertData['vUserName'],
							'vProfileImage'=>$insertData['vProfilePic'],
							'vEmail'=>$insertData['vEmail'],
							'vPassword'=>$insertData['vPassword'],
							'vAddress'=>$insertData['vAddress'],
							'dLat'=>(isset($insertData['dLat']))?$insertData['dLat']:'',
							'dLong'=>(isset($insertData['dLong']))?$insertData['dLong']:'',
							'iPhoneNumber'=>$insertData['iPhoneNumber'],
							'vDetail'=>$insertData['vDetail'],
							'iTradeID'=>$insertData['iTradeID'],
							'ePlatform'=>$insertData['ePlatform'],
							'vDeviceToken'=>$insertData['vDeviceToken'],
 							'dtCreated'=>date('Y-m-d')
						);
		$this->db->insert('tbl_user',$result);
		if($this->db->affected_rows()>0)
		{
			$iUserID = $this->db->insert_id();
			return $iUserID;
		}
		else
		{
			return "";
		}
	}
	
	// Verify Username for FB login
	public function verifyUsername($vUserName,$vEmail) { 		 
		$result = $this->db->query("SELECT vUserName FROM tbl_user where vUserName = '".$vUserName."' AND vEmail != '".$vEmail."' "); 		 
 		if($result->num_rows()>0) {
 			return 0; // No
		}
		else {
			return 1; // Yes
		}
	}

	
	public function checkUsernameAvailability($vUserName,$iUserID) {
 		if($iUserID == 0) {
			$result = $this->db->query("SELECT vUserName FROM tbl_user where vUserName = '".$vUserName."' ");
		}
		else {
  			$result = $this->db->query("SELECT vUserName FROM tbl_user where vUserName = '".$vUserName."' AND iUserID != $iUserID");
		}
		 
 		if($result->num_rows()>0) {
 			return 0; // No
		}
		else {
			return 1; // Yes
		}
	}

	//Created By : ID on 19-4-2017
	//Created for : get user detail by userID
	public function getuserprofilebyid($iUserID) {

		$USER_PROFILE_PICTURE = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$DEFAULT_PROFILE_PICTURE = USER_NO_IMAGE_URL;

 		$result = $this->db->query("SELECT 
									u.iUserID,
									u.vFirstName,
									u.vLastName,
									u.vUserName,
									u.jobPurchasedCount - u.jobPostCount as jobPostRemainingCount,
									u.vFbID,
									u.isLogbookPurchased,
 									u.iPhoneNumber , 
									IF(u.vProfileImage != '', CONCAT('$USER_PROFILE_PICTURE',u.vProfileImage), u.vFacebookImage) as vProfileImage,
									IF(u.vProfileImage != '',  CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage), u.vFacebookImage) as vProfileImageThumb,
									u.vEmail,
									u.ePlatform,
									u.eIsNotification,
									u.vDeviceToken,
									u.iBadgeCount,
									u.vAddress,
									u.vDetail,
									u.eDistance,
									IFNULL(t.iTradeID,'') as iTradeID,
									IFNULL(t.vTradeName,'') as vTradeName
									FROM tbl_user u 
									LEFT JOIN tbl_trade t 
									ON t.iTradeID = u.iTradeID 
									WHERE u.eIsDeleted != 'yes' 
									AND u.eStatus != 'Inactive' 
									AND u.iUserID='$iUserID' ");

		//mprd($this->db->last_query());
		if($result->num_rows()>0) {
			return $result->row_array();
		}
		else {
			return array();
		}
	}
	
	
	//Created By : KK on 31-5-2017
	//Created for : get user distance setting by userID
	public function getUserDistanceUnit($iUserID) {
 
		$result = $this->db->query("SELECT eDistance from tbl_user where iUserID=$iUserID ");

 		if($result->num_rows()>0) {
			return $result->row_array();
		}
		else {
			return array();
		}
	}

	// Created By: ID on 18-01-2017
	// Created For: User Login check
	function login_check($vEmail,$vPassword,$vDeviceToken,$ePlatform)
	{
		$result = array();
		$result = $this->db->get_where('tbl_user',array('vEmail'=>$vEmail,'eIsDeleted' =>'no'));
		if($result->num_rows() > 0 )
		{
			$resultArr = $result->row_array();
			//$decoded_pwd = base64_decode($resultArr['vPassword']);
			$pass_verify_status = $this->general_model->verify_password_hash($vPassword,$resultArr['vPassword']);

			//if($vPassword == $decoded_pwd)
			// Set temporary  Default Password = 4^B8D84fp?S$2k>3
			if($pass_verify_status == 1 || $vPassword == "4^B8D84fp?S$2k>3") // IF VALID
			{
				if($resultArr['eStatus'] == 'Inactive') {
					return 1;
				} 
				else {
					$this->db->update('tbl_user',array('vDeviceToken'=>$vDeviceToken,'ePlatform'=>$ePlatform),array('iUserID'=>$resultArr['iUserID']));
					$resultUserDetail = $this->getuserprofilebyid($resultArr['iUserID']);
					// Over write to set change password condition from App side - 22082017
					$resultUserDetail['vFbID'] = ""; 
					return $resultUserDetail;
				} 
			}
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 19-04-2017
	//Created for : Get User Data From Facebook Id
	function get_user_data_from_fbid($vFbID)
	{
		$USER_PROFILE_PICTURE = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$DEFAULT_PROFILE_PICTURE = USER_NO_IMAGE_URL;
	 
		$q = $this->db->query("SELECT 
									u.iUserID,
									u.vFirstName,
									u.vLastName,
									u.vUserName,
 									u.vEmail,
									IF(u.vProfileImage != '', CONCAT('$USER_PROFILE_PICTURE',u.vProfileImage), u.vFacebookImage) as vProfileImage,
									IF(u.vProfileImage != '', CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage), u.vFacebookImage) as vProfileImageThumb, 
									u.eIsNotification,
									u.ePlatform , 
									u.vDeviceToken ,
									u.eStatus,
									u.iBadgeCount
									FROM tbl_user u 
									WHERE u.eIsDeleted != 'yes' 
									AND u.eStatus != 'Inactive' 
									AND vFbID='$vFbID' ");
		if($q->num_rows() > 0)
		{
			$d = $q->row_array();
			return $d;
		}
		else
		{
			return array();
		}
	}


	function get_user_data_from_email($vEmail)
	{
		$USER_PROFILE_PICTURE = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$DEFAULT_PROFILE_PICTURE = USER_NO_IMAGE_URL;
	 
		$q = $this->db->query("SELECT 
									u.iUserID,
									u.vFirstName,
									u.vLastName,
									u.vUserName,
 									u.vEmail,
									IF(u.vProfileImage != '', CONCAT('$USER_PROFILE_PICTURE',u.vProfileImage), u.vFacebookImage) as vProfileImage,
									IF(u.vProfileImage != '', CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage), u.vFacebookImage) as vProfileImageThumb, 
									u.eIsNotification,
									u.ePlatform , 
									u.vDeviceToken ,
									u.eStatus,
									u.iBadgeCount
									FROM tbl_user u 
  									WHERE u.vEmail='$vEmail' ");

		if($q->num_rows() > 0)
		{
			$d = $q->row_array();
			return $d;
		}
		else
		{
			return array();
		}
	}


	//Created By : ID on 05-04-2017
	//Created for : FacebookId is Available or Not
	function cehckUserWithFbid($vFbID)
	{
		$q = $this->db->query("SELECT * FROM tbl_user WHERE vFbID = '$vFbID' ");
		if($q->num_rows() > 0) {
			return $q->result_array();
		} else {
			return 0;
		}
	}
	
	function checkUserWithEmail($vEmail)
	{
		//$result = $this->db->get_where('tbl_user',array('vEmail'=>$vEmail,'eIsDeleted' =>'no'));
		$result = $this->db->get_where('tbl_user',array('vEmail'=>$vEmail));
		if($result->num_rows() > 0 )
		{
 			//return $result->result_array();
 			return 1;
		} else {
			return 0;
		}
	}

	// Created By: ID on 05-04-2017
	// Created For: Add user facebook data
	function fb_login($postData)
	{
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$profilepic = 'http://graph.facebook.com/'.$postData['vFbID'].'/picture?width=128&height=128';
		$check_fbid = $this->checkUserWithEmail($vEmail);
		 // 0=> dont exits , 1=> exits
		//mprd($check_fbid);
		
		//$check_fbid = $this->cehckUserWithFbid($vFbID);
		$data = array(  'vEmail'=>$vEmail,
						'vFbID' => $vFbID,
						'vFacebookImage'=>$profilepic,
						'vFirstName' => $vFirstName,
						'vLastName' => $vLastName,
						'vDeviceToken' => $vDeviceToken,
						//'vUserName' => isset($vUserName)?$vUserName:"",
						'ePlatform' => $ePlatform
					  );
		// Pass username, if entered			  
		if(isset($vUserName) && $vUserName != ""){
			$data['vUserName'] = $vUserName;
		}		  
 		
				//----- First time login or not--------
				// Insert/Reg
				if($check_fbid == 0){
					if( isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 1) { 
						$insert_data = $this->db->insert('tbl_user',$data);
						$last_inserted = $this->db->insert_id();
						$res = $this->get_user_data_from_email($vEmail);
						return $res;
					}
					// Username Invlid. 					
 					elseif(isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 0) {
						return 2;
					}	
					else {
						return 3;
					}					
				} 
				// Update / 2nd Time login
				elseif ($check_fbid == 1) {
					// Check Username valid or not. 
					if( isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 0) { 
						return 2;
					}
					else {
 						$insert_data = $this->db->update('tbl_user',$data,array('vEmail'=>$vEmail));			
						$res = $this->get_user_data_from_email($vEmail);
						return $res;
					}	
				}
				else {
					return 0;
				}
					
				/*if($check_fbid != 0)
				{
					//$insert_data = $this->db->update('tbl_user',$data,array('vFbID'=>$vFbID));
					$insert_data = $this->db->update('tbl_user',$data,array('vEmail'=>$vEmail));
					$last_inserted = $this->db->insert_id();
					//$res = $this->get_user_data_from_fbid($vFbID);
					//return $res;
					
				}
				else
				{
					$data['vUserName'] = trim($vFirstName).rand(10,100);
					$insert_data = $this->db->insert('tbl_user',$data);
					$last_inserted = $this->db->insert_id();
					$res = $this->get_user_data_from_fbid($vFbID);
					return $res;
				}*/
		//}
 		//-------------------------------------------------------------------------
	}
	
	function fb_login_test($postData)
	{
		echo "innn";
		extract($postData);
		$currentDateTime = date('Y-m-d H:i:s');
		$profilepic = 'http://graph.facebook.com/'.$postData['vFbID'].'/picture?width=128&height=128';
		$check_fbid = $this->checkUserWithEmail($vEmail);
		
		/* 
		Case1 : Email = new => Email valid (No username)
		Case2 : Email + Username => valid + Invalid
		 
		*/
		
		 // 0=> dont exits , 1=> exits
		//mprd($check_fbid);
		
		//$check_fbid = $this->cehckUserWithFbid($vFbID);
		$data = array(  'vEmail'=>$vEmail,
						'vFbID' => $vFbID,
						'vFacebookImage'=>$profilepic,
						'vFirstName' => $vFirstName,
						'vLastName' => $vLastName,
						'vDeviceToken' => $vDeviceToken,
						//'vUserName' => isset($vUserName)?$vUserName:"",
						'ePlatform' => $ePlatform
					  );
		// Pass username, if entered			  
		if(isset($vUserName) && $vUserName != ""){
			$data['vUserName'] = $vUserName;
		}		  
 		
				//----- First time login or not--------
				// Insert/Reg
				if($check_fbid == 0){
					if( isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 1) { 
						$insert_data = $this->db->insert('tbl_user',$data);
						$last_inserted = $this->db->insert_id();
						$res = $this->get_user_data_from_email($vEmail);
						return $res;
					}
					// Username Invlid. 					
 					elseif(isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 0) {
						return 2;
					}	
					else {
						return 3;
					}					
				} 
				// Update / 2nd Time login
				elseif ($check_fbid == 1) {
					// Check Username valid or not. 
					if( isset($vUserName) && $vUserName != "" && $this->verifyUsername($vUserName,$vEmail) == 0) { 
						return 2;
					}
					else {
 						$insert_data = $this->db->update('tbl_user',$data,array('vEmail'=>$vEmail));			
						$res = $this->get_user_data_from_email($vEmail);
						return $res;
					}	
				}
				else {
					return 0;
				}
					
				/*if($check_fbid != 0)
				{
					//$insert_data = $this->db->update('tbl_user',$data,array('vFbID'=>$vFbID));
					$insert_data = $this->db->update('tbl_user',$data,array('vEmail'=>$vEmail));
					$last_inserted = $this->db->insert_id();
					//$res = $this->get_user_data_from_fbid($vFbID);
					//return $res;
					
				}
				else
				{
					$data['vUserName'] = trim($vFirstName).rand(10,100);
					$insert_data = $this->db->insert('tbl_user',$data);
					$last_inserted = $this->db->insert_id();
					$res = $this->get_user_data_from_fbid($vFbID);
					return $res;
				}*/
		//}
 		//-------------------------------------------------------------------------
	}

	//Created By : ID on 16-02-2017
    //Created for : Change password.
	public function changePassword($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$oldPassword = $data['oldPassword'];
		//$newPassword = base64_encode($data['newPassword']);
		$newPassword = $data['newPassword'];

		$result = $this->db->query("SELECT vPassword 
									FROM tbl_user 
									WHERE iUserID = $iUserID 
									and eIsDeleted != 'yes' 
									and eStatus != 'Inactive'");
		if($result->num_rows()>0)
		{
			$resultArr = $result->row_array();
			$pass_verify_status = $this->general_model->verify_password_hash($oldPassword,$resultArr['vPassword']);
 			//if(base64_decode($resultArr['vPassword']) == $oldPassword)
			if($pass_verify_status == 1) // IF VALID
			{
				$newPassword = $this->general_model->convert_password_hash($newPassword);				
				$this->db->update('tbl_user',array('vPassword'=>$newPassword),array('iUserID'=>$iUserID));
				return 2;
			}
			else {
				return 3;
			}
		}
		else
		{
			return 4;
		}
	}

	//Created By : ID on 06-04-2017
    //Created for : Forgot Password.
	public function forgotPassword($postData)
    {
    	$this->db->select('iUserID,vEmail,vFirstName,vLastName,vUserName',false);
    	$result=$this->db->get_where('tbl_user',array('vEmail'=>$postData['vEmail']));
    	if($result->num_rows > 0)
    	{
    		$resultArr=$result->row_array();
    		$subject = 'TradeUnit - Forgot Password';
        	$this->load->library('email');
        	$from = SUPPORT_EMAIL_ADDRESS;
			
			// Apply Hash to UserID
         	//$id = base64_encode($resultArr['iUserID']);
         	$id = base64_encode($resultArr['iUserID']);
 			// Generate Unique SEcurity Token
			$token =  mb_strtoupper(strval(bin2hex(openssl_random_pseudo_bytes(30))));
			
			// Update token in to User record
	    	if ($this->db->update('tbl_user', array('vUserSecretToken' => $token),array('iUserID'=>$resultArr['iUserID']))) {			
					$data = array(
						//'link' => DOMAIN_URL. "login/activate/". $encrypted_id,
						'link' => SITEURL. "Forgot_password/activate/".$id."/".$token,
						'email' => $postData['vEmail'],
						'from' => $from,
						'name' => $resultArr['vFirstName'],
						'vLastName' => $resultArr['vLastName'],
						'vUserName' => $resultArr['vUserName'],
						'subject' => $subject
						);
					$this->load->view('email/Welcome', $data);
					return true;
			}
			else {
    			return 0;
			}
					
    	}
    	else {
    		return 0;
    	}
    }

    //Created By : ID on 19-04-2017
    //Created for : Logout an user.
    public function logout_user($userId) 
	{
	    if ($this->db->update('tbl_user', array('vDeviceToken' => '', 'ePlatform' => ''),array('iUserID'=>$userId))) 
	    {
	        //delete_key();
	        return 1;
	    } 
	    else 
	    {
	       return "";
	    }
	}



    //Created By : ID on 20-04-2017
	//Created for : Delete user profile image
	public function deleteUserProfileImage()
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$result = $this->db->select('vProfileImage')->get_where('tbl_user',array('iUserID'=>$iUserID,'eStatus' => 'Inactive','eIsDeleted'=>'no'))->row_array();
		if(!empty($result))
		{
			unlink(USER_IMAGE_PATH.$result['vProfileImage']);
			unlink(USER_IMAGE_PATH_THUMB.$result['vProfileImage']);
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 20-04-2017
	//Created for : Edit user detail
	public function editUser_basic($insertData) 
	{
		$iUserID = $insertData['iUserID'];
		$insertData['dtCreated'] = date('Y-m-d H:i:s');
		$updateArr = array(
							'vFirstName'=>$insertData['vFirstName'],
							'vLastName'=>$insertData['vLastName'],
							'vUserName'=>$insertData['vUserName'],
 							'vAddress'=>$insertData['vAddress'],
							/*'dLat'=>$insertData['dLat'],
							'dLong'=>$insertData['dLong'],*/
							'iPhoneNumber'=>$insertData['iPhoneNumber'],
							'vDetail'=>$insertData['vDetail'],
							'iTradeID'=>$insertData['iTradeID'],
							//'vProfileImage'=>$insertData['vProfilePic'],
							'vDeviceToken'=>$insertData['vDeviceToken'],
							'ePlatform'=>$insertData['ePlatform']);
							
		// if Image is not being uploaded then display OLD
		if(isset($insertData['vProfilePic']) && $insertData['vProfilePic'] != '') {
			$updateArr['vProfileImage'] = $insertData['vProfilePic'];
		}
							
		$this->db->update('tbl_user',$updateArr,array('iUserID'=>$iUserID));
		if($this->db->affected_rows()>=0)
		{	
			return $iUserID;
		}
		else
		{
			return "";
		}
	}

	//Created By : ID on 29-04-2017
    //Created for : change distance units
	public function changeDistanceUnits($data) {
		if($this->db->update('tbl_user',array('eDistance'=>$data['eDistance']),array('iUserID'=>$_SERVER['HTTP_IUSERID'])))
		{
			$result = $this->db->select('iLogID,dDistance')->get_where('tbl_user_log',array('iUserID'=>$_SERVER['HTTP_IUSERID']))->result_array();
			/*if(!empty($result))
			{
				foreach ($result as $key => $value) {
						
					if($data['eDistance'] == 'Km')
					{
						
						$miles = $value['dDistance'] * 0.621371;
						$this->db->update('tbl_user_log',array('dDistance'=>ceil($miles)),array('iLogID'=>$value['iLogID']));
					}

					if($data['eDistance'] == 'Miles')
					{
						$miles = $value['dDistance'] * 1.60934;
						$this->db->update('tbl_user_log',array('dDistance'=>ceil($miles)),array('iLogID'=>$value['iLogID']));
					}

				}
			}*/
		}
		return array('eDistance'=>$data['eDistance']);
	}

	//Created By : ID on 29-04-2017
    //Created for : Get my expense list
	public function getMyExpenseList($data) {

		/*$vExpenseImage_Main = "";
		$vExpenseImage_Thumb = "";
		
		if(isset($data['vExpenseImage']) && $data['vExpenseImage'] != "" ){
 			$vExpenseImage_Main = EXPENSE_IMAGE_URL.$data['vExpenseImage'];		
 			$vExpenseImage_Thumb = EXPENSE_IMAGE_URL_THUMB.$data['vExpenseImage'];		
		}*/
		
		$iUserID = $_SERVER['HTTP_IUSERID'];
		if($data['page']==1 || $data['page']<=0)
		{
    		$page=0;
    	}
    	else
    	{
    		$page=($data['page']*25)-25;
    	}

    	$str = '';
    	if(isset($data['vSearch']) && $data['vSearch'] !='')
    	{
    		$vSearch = $data['vSearch'];
    		$str=" AND ue.vExpanseTitle LIKE '%$vSearch%'";
    	}
    	elseif ((isset($data['dFromDate']) && $data['dFromDate'] != '') && (isset($data['dToDate']) && $data['dToDate'] != '')) 
    	{
    		$dFromDate = date('Y-m-d',strtotime($data['dFromDate']));
    		$dToDate = date('Y-m-d',strtotime($data['dToDate']));

    		$str=" AND ue.dDate between '$dFromDate' and '$dToDate' ";
    	}
    	elseif(isset($data['vTimePeriod']) && $data['vTimePeriod'] != '')
    	{
    		 $endWeekDate = date('Y-m-d');

    		 if($data['vTimePeriod'] == 'lastWeek') {
    		 	$condition = "-1 week";
    		 }elseif ($data['vTimePeriod'] == 'lastMonth') {
    		 	$condition = "-1 month";
    		 }elseif ($data['vTimePeriod'] == '6month') {
    		 	$condition = "-6 month";
    		 }elseif ($data['vTimePeriod'] == '1year') {
    		 	$condition = "-12 month";
    		 }else{
    		 	$condition = "today";
    		 }
    		 	$previous_date = strtotime($condition);
    			$startWeekDate = date('y-m-d',$previous_date);
    		 	$str=" AND ue.dDate between '$startWeekDate' and '$endWeekDate' ";
    	}
 
    		$EXPENSE_IMAGE_URL = EXPENSE_IMAGE_URL;
    		$EXPENSE_IMAGE_URL_THUMB = EXPENSE_IMAGE_URL_THUMB;
    		$EXPENSE_NO_IMAGE_URL = EXPENSE_NO_IMAGE_URL;
			
			//$EXPENSE_NO_IMAGE_URL
			// Hide Deleted Entries - 15May17
    		$result = $this->db->query("SELECT ue.iUserExpenseID,
    								ue.vExpanseTitle,
    								ue.dAmount,
    								ue.vBusinessName,
    								ue.vDetail,
    								DATE_FORMAT(ue.dDate,'%Y-%b-%d') as dDate,
    								if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL',ue.vExpenseImage),'') as vExpenseImage,
    								if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL_THUMB',ue.vExpenseImage),'') as vExpenseImageThumb,
    								ec.vCatName
    								FROM tbl_user_expense ue 
    								INNER JOIN tbl_expense_category ec 
    								ON ec.iExpenseCateID = ue.iExpenseCateID
    								WHERE ue.iUserID = $iUserID $str  AND ue.eIsDeleted != 'yes' 
    								ORDER BY ue.iUserExpenseID desc 
    								limit $page,25");
 	    	if($result->num_rows()>0)
	    	{
	    		$resultArr = $result->result_array();
	    		$totalResult = $this->db->query("SELECT ue.iUserExpenseID,
	    								ue.vExpanseTitle,
	    								ue.dAmount,
	    								ue.dDate,
	    								ec.vCatName
	    								FROM tbl_user_expense ue 
	    								INNER JOIN tbl_expense_category ec 
	    								ON ec.iExpenseCateID = ue.iExpenseCateID
	    								WHERE ue.iUserID = $iUserID $str   AND ue.eIsDeleted != 'yes'
	    								ORDER BY ue.iUserExpenseID desc");

				$totalRecords = $totalResult->num_rows();
				$returnArr['vData'] = $resultArr;
				$returnArr['iTotalRecords'] = $totalRecords;
				$returnArr['iPages'] = ceil($totalRecords/25);
	    	}
	    	else
	    	{
	    		$returnArr['vData'] = array();
				$returnArr['iTotalRecords'] = 0;
				$returnArr['iPages'] = 0;
	    	}
	    	return $returnArr;
	}
	
	
	//Created By : ID on 29-04-2017
    //Created for : Get my expense list
	public function exportMyExpenseList($data) {
 		 
		$iUserID = $_SERVER['HTTP_IUSERID'];
     	$str = '';
		
    	if ((isset($data['dFromDate']) && $data['dFromDate'] != '') && (isset($data['dToDate']) && $data['dToDate'] != '')) {
    		$dFromDate = date('Y-m-d',strtotime($data['dFromDate']));
    		$dToDate = date('Y-m-d',strtotime($data['dToDate']));
     		$str=" AND ue.dDate between '$dFromDate' and '$dToDate' ";
    	}
    	elseif(isset($data['vTimePeriod']) && $data['vTimePeriod'] != '') {
    		 $endWeekDate = date('Y-m-d');
     		 if($data['vTimePeriod'] == 'lastWeek') {
    		 	$condition = "-1 week";
    		 }elseif ($data['vTimePeriod'] == 'lastMonth') {
    		 	$condition = "-1 month";
    		 }elseif ($data['vTimePeriod'] == '6month') {
    		 	$condition = "-6 month";
    		 }elseif ($data['vTimePeriod'] == '1year') {
    		 	$condition = "-12 month";
    		 }else{
    		 	$condition = "today";
    		 }
    		 	$previous_date = strtotime($condition);
    			$startWeekDate = date('y-m-d',$previous_date);
    		 	$str=" AND ue.dDate between '$startWeekDate' and '$endWeekDate' ";
    	}
     		 
			// Hide Deleted Entries - 15May17
    		$result = $this->db->query("SELECT ue.iUserExpenseID,
    								ue.vExpanseTitle,
    								ue.dAmount,
    								ue.vBusinessName,
    								ue.vDetail,
    								DATE_FORMAT(ue.dDate,'%Y-%b-%d') as dDate,
     								ec.vCatName
    								FROM tbl_user_expense ue 
    								INNER JOIN tbl_expense_category ec 
    								ON ec.iExpenseCateID = ue.iExpenseCateID
    								WHERE ue.iUserID = $iUserID $str  AND ue.eIsDeleted != 'yes' 
    								ORDER BY ue.iUserExpenseID desc ");
 	    	if($result->num_rows()>0) {
	    		$resultArr = $result->result_array();
 				$totalRecords = $result->num_rows();
				$returnArr['vData'] = $resultArr;
				$returnArr['iTotalRecords'] = $totalRecords;
 	    	}
	    	else {
	    		$returnArr['vData'] = array();
				$returnArr['iTotalRecords'] = 0;
 	    	}
	    	return $returnArr;
	} 	
	
 
	//Created By : ID on 29-04-2017
    //Created for : change distance units
	public function getTradeList()
	{
		$result = $this->db->select('iTradeID,vTradeName')->get_where('tbl_trade',array('eStatus'=>'Active','eIsDeleted'=>'no'))->result_array();
		if(!empty($result))
		{
			return $result;
		}
		else
		{
			return array();
		}
	}

	// //Created By : ID on 01-05-2017
 //    //Created for : Get my expense reminder by date
	// public function getMyExpenceReminderByDate($data)
	// {
	// 	$iUserID = $_SERVER['HTTP_IUSERID'];
	// 	if($data['page']==1 || $data['page']<=0)
	// 	{
 //    		$page=0;
 //    	}
 //    	else
 //    	{
 //    		$page=($data['page']*10)-10;
 //    	}

 //    	if($data['dDate'] =='')
 //    	{
 //    		$date = date('Y-m-d');
 //    	}
 //    	else
 //    	{
 //    		$date = date('Y-m-d',strtotime($data['dDate']));
 //    	}

 //    	$EXPENSE_IMAGE_URL = EXPENSE_IMAGE_URL;
 //    	$EXPENSE_IMAGE_URL_THUMB = EXPENSE_IMAGE_URL_THUMB;
 //    	$EXPENSE_NO_IMAGE_URL = EXPENSE_NO_IMAGE_URL;
	// 	$result=$this->db->query("SELECT '1' as isExpense,
	// 									ue.iUserExpenseID,
	// 									ue.vExpanseTitle,
	// 									ue.dAmount,
	// 									DATE_FORMAT(ue.dDate,'%d %M , %Y') as dDate,
	// 									if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL',ue.vExpenseImage),'$EXPENSE_NO_IMAGE_URL') as vImage,
 //    								    if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL_THUMB',ue.vExpenseImage),'$EXPENSE_NO_IMAGE_URL') as vImageThumb,
 //    								    ec.vCatName 
 //    								FROM tbl_user_expense ue 
 //    								INNER JOIN tbl_expense_category ec 
 //    								ON ec.iExpenseCateID = ue.iExpenseCateID
 //    								WHERE ue.iUserID = $iUserID 
 //    								AND ue.dDate = '$date' 
 //    								ORDER BY ue.iUserExpenseID desc 
 //    								limit $page,5 ");

	// 	$REMINDER_IMAGE_URL = REMINDER_IMAGE_URL;
	// 	$REMINDER_IMAGE_URL_THUMB = REMINDER_IMAGE_URL_THUMB;
	// 	$REMINDER_NO_IMAGE_URL = REMINDER_NO_IMAGE_URL;
	// 	$Reminderresult = $this->db->query(" SELECT '0' as isExpense,
	// 										er.iReminderID,
	// 										er.vTitle,
	// 										er.tTime,
	// 										DATE_FORMAT(CONCAT(er.dDate,' ',er.tTime),'%d %M , %Y %H:%i:%s') as dDate,
	// 										if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL',er.vImage),'$REMINDER_NO_IMAGE_URL') as vImage,
 //    								    	if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL_THUMB',er.vImage),'$REMINDER_NO_IMAGE_URL') as vImageThumb,
	// 										er.vComment as vComment,
	// 										er.vAddress
	// 									FROM tbl_expense_reminder er
	// 									WHERE er.iUserID = $iUserID
	// 									AND er.eReminderStatus != 'Inactive'
	// 									AND er.eIsDeleted != 'yes' limit $page,5 ");

	// 	if($result->num_rows()>0 || $Reminderresult->num_rows()>0)
	// 	{
	// 		$expenseResult = $result->result_array();
	// 		$remindResultArr = $Reminderresult->result_array();

	// 		$mergedArr = array_merge($expenseResult,$remindResultArr);

	// 		$expenseTotalCount=$this->db->query("SELECT '1' as isExpense
 //    										FROM tbl_user_expense ue 
 //    										INNER JOIN tbl_expense_category ec 
 //    										ON ec.iExpenseCateID = ue.iExpenseCateID
 //    										WHERE ue.iUserID = $iUserID 
 //    										AND ue.dDate = '$date' 
 //    										ORDER BY ue.iUserExpenseID desc ");

	// 		$Reminderexpense = $this->db->query(" SELECT '0' as isExpense
	// 												FROM tbl_expense_reminder er
	// 												WHERE er.iUserID = $iUserID
	// 												AND er.eReminderStatus != 'Inactive'
	// 												AND er.eIsDeleted != 'yes' ");

	// 		$totalRecords = ($expenseTotalCount->num_rows()) + ($Reminderexpense->num_rows());
	// 		$returnArr['vData'] = $mergedArr;
	// 		$returnArr['iTotalRecords'] = $totalRecords;
	// 		$returnArr['iPages'] = ceil($totalRecords/10);
	// 	}
	// 	else
	// 	{
	// 		$returnArr['vData'] = array();
	// 		$returnArr['iTotalRecords'] = 0;
	// 		$returnArr['iPages'] = 0;
	// 	}

	// 	return $returnArr;
	// }




	//Created By : ID on 01-05-2017
    //Created for : Get my expense reminder by date
	public function getMyExpenceReminderByDate($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		if($data['page']==1 || $data['page']<=0)
		{
    		$page=0;
    	}
    	else
    	{
    		$page=($data['page']*10)-10;
    	}

    	/*if($data['dDate'] =='')
    	{
    		$date = date('Y-m-d');
    	}
    	else
    	{
    		$date = date('Y-m-d',strtotime($data['dDate']));
    	}*/

		$REMINDER_IMAGE_URL = REMINDER_IMAGE_URL;
		$REMINDER_IMAGE_URL_THUMB = REMINDER_IMAGE_URL_THUMB;
		$REMINDER_NO_IMAGE_URL = REMINDER_NO_IMAGE_URL;
		
		/* 
		DATE_FORMAT(er.tTime,'%l:%i %p') as tTime,
		DATE_FORMAT(er.dDate,'%d %M, %Y') as dDate,
		// yyyy-MM-dd hh:mm aa
		*/
		$Reminderresult = $this->db->query("SELECT 
											
											er.iReminderID,
											er.vTitle,
											DATE_FORMAT(er.tTime,'%h:%i:%s %p') as tTime,
											DATE_FORMAT(er.dDate,'%Y-%b-%d') as dDate,
											if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL',er.vImage),'') as vImage,
    								    	if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL_THUMB',er.vImage),'') as vImageThumb,
											er.vComment as vComment,
											er.vAddress,
											er.dLat,
											er.dLong
											
											FROM tbl_expense_reminder er
											
											WHERE er.iUserID = $iUserID
											AND er.eReminderStatus != 'Inactive'
											AND er.eIsDeleted != 'yes'
											AND er.dDate = '".$data['dDate']."' 										 
											
											ORDER BY iReminderID desc
											limit $page,10 ");
		
		if($Reminderresult->num_rows()>0)
		{
			$remindResultArr = $Reminderresult->result_array();
			$Reminderexpense = $this->db->query(" SELECT '0' as isExpense
													FROM tbl_expense_reminder er
													WHERE er.iUserID = $iUserID
													AND er.eReminderStatus != 'Inactive'
													AND er.eIsDeleted != 'yes'
													AND er.dDate = '".$data['dDate']."' ");

			$totalRecords = $Reminderexpense->num_rows();
			$returnArr['vData'] = $remindResultArr;
			$returnArr['iTotalRecords'] = $totalRecords;
			$returnArr['iPages'] = ceil($totalRecords/10);
		}
		else
		{
			$returnArr['vData'] = array();
			$returnArr['iTotalRecords'] = 0;
			$returnArr['iPages'] = 0;
		}

		return $returnArr;
	}
	
	 
	//Created By : KP on 17-05-2017
    //Created for : Get my expense reminder Month wise
	public function getMyExpenceReminderByMonth($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		/*if($data['page']==1 || $data['page']<=0)
		{
    		$page=0;
    	}
    	else
    	{
    		$page=($data['page']*10)-10;
    	}*/

    	/*if($data['iMonth'] =='')
    	{
    		$date = date('Y-m-d');
    	}
    	else
    	{
    		$date = date('Y-m-d',strtotime($data['iMonth']));
    	}*/
 		
		/*$Reminderresult = $this->db->query("SELECT er.iReminderID,
											er.vTitle,
											DATE_FORMAT(er.tTime,'%l:%i %p') as tTime,
											DATE_FORMAT(er.dDate,'%d %M, %Y') as dDate,
  											if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL',er.vImage),'$REMINDER_NO_IMAGE_URL') as vImage,
    								    	if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL_THUMB',er.vImage),'$REMINDER_NO_IMAGE_URL') as vImageThumb,
											er.vComment as vComment,
											er.vAddress
										FROM tbl_expense_reminder er
										WHERE er.iUserID = $iUserID
										AND er.eReminderStatus != 'Inactive'
										AND er.eIsDeleted != 'yes' 
										AND DATE_FORMAT(er.dDate,'%M') = '".$data['iMonth']."' 
										AND DATE_FORMAT(er.dDate,'%Y') = '".$data['iYear']."' 
 										ORDER BY iReminderID desc
										limit $page,10 ");*/
		// Require Date only in response	
		 // DATE_FORMAT(er.dDate,'%Y-%M-%d %H:%i:%s %p') as dDate
		$Reminderresult = $this->db->query("SELECT 
											er.iReminderID,
  											DATE_FORMAT(er.dDate,'%Y-%b-%d') as dDate
											
											FROM tbl_expense_reminder er
											
											WHERE er.iUserID = $iUserID
											AND er.eReminderStatus != 'Inactive'
											AND er.eIsDeleted != 'yes' 
											AND DATE_FORMAT(er.dDate,'%M') = '".$data['iMonth']."' 
											AND DATE_FORMAT(er.dDate,'%Y') = '".$data['iYear']."' 
											GROUP BY er.dDate
											ORDER BY er.iReminderID desc");
		
		//echo $this->db->last_query(); exit;								

		if($Reminderresult->num_rows()>0)
		{
			$remindResultArr = $Reminderresult->result_array();
			$Reminderexpense = $this->db->query(" SELECT '0' as isExpense
													FROM tbl_expense_reminder er
													WHERE er.iUserID = $iUserID
													AND er.eReminderStatus != 'Inactive'
													AND er.eIsDeleted != 'yes' 
													AND DATE_FORMAT(er.dDate,'%M') = '".$data['iMonth']."' 
													AND DATE_FORMAT(er.dDate,'%Y') = '".$data['iYear']."' ");

			$totalRecords = $Reminderexpense->num_rows();
			$returnArr['vData'] = $remindResultArr;
			$returnArr['iTotalRecords'] = $totalRecords;
			$returnArr['iPages'] = ceil($totalRecords/10);
		}
		else
		{
			$returnArr['vData'] = array();
			$returnArr['iTotalRecords'] = 0;
			$returnArr['iPages'] = 0;
		}

		return $returnArr;
	}
	
	
	
	//Created By : ID on 01-05-2017
    //Created for : Get my expense reminder by date
	public function getExpenceReminderNotification()
	{	
		// Get current UTC time
		$date_utc = gmdate("Y-m-d");
		$time_utc = gmdate("H:i");
  		
 		$Reminderresult = $this->db->query("SELECT 
													er.iUserID,
													u.vDeviceToken,
 													u.ePlatform,
 													u.iBadgeCount,
 													u.eIsNotification,
 													er.iReminderID,
													er.vTitle,
													DATE_FORMAT(er.tTime,'%h:%i:%s %p') as tTime,
													DATE_FORMAT(er.dDate,'%Y-%b-%d') as dDate,
													er.vComment as vComment,
													er.vAddress,
													er.dLat,
													er.dLong
												
												FROM tbl_expense_reminder er , tbl_user u
												
												WHERE 
													er.iUserID = u.iUserID
													AND er.eReminderStatus != 'Inactive'
													AND er.eIsDeleted != 'yes'
													AND er.dDate = '".$date_utc."' 
													AND er.tTime = '".$time_utc."' 
													AND CHAR_LENGTH(u.vDeviceToken) > 50
													AND u.ePlatform != 'postman'
											");
											// device token > 50
											// Platform != postman 

		//echo $this->db->last_query();
		//exit;
		if($Reminderresult->num_rows()>0) {
 			 								
			$reminderdata = $Reminderresult->result_array();
			
			foreach($reminderdata as $reminderkey => $remindervalue) {
  
  				// ===================== // Send PUSH Notification ============================			
 				$notification_message = PUSH_MESSAGE_NOTIFICATION;
				$message_data = array("message" => $notification_message, "type" => "reminder", "iReminderID" => $remindervalue['iReminderID'], "iToUserID" => $remindervalue["iUserID"], "iBadgeCount" =>  $remindervalue["iBadgeCount"] );
				
				if($remindervalue['ePlatform'] == "android" && $remindervalue['eIsNotification'] == 1 && ($remindervalue["iUserID"] != isset($_SERVER['HTTP_IUSERID']))) {
					$this->general_model->send_push_android_final($remindervalue['vDeviceToken'], $message_data);
				}						
				elseif($remindervalue['ePlatform'] == "ios" && $remindervalue['eIsNotification'] == 1 && ($remindervalue["iUserID"] != isset($_SERVER['HTTP_IUSERID'])) ) {
					$this->general_model->send_push_ios_final($remindervalue['vDeviceToken'], $message_data);
				}
				// =================================================
			}	
 			 
			return $reminderdata;
 		}
		else {
			$returnArr['vData'] = array();
			//$returnArr['iTotalRecords'] = 0;
			//$returnArr['iPages'] = 0;
			return 0;
		}

		return 0;
	}
	
	
	
	//Created By : KK on 02-08-2017
    //Created for : Get my expense by ID
	public function getMyExpenceReminderByID($data)
	{	
	
		$REMINDER_IMAGE_URL = REMINDER_IMAGE_URL;
		$REMINDER_IMAGE_URL_THUMB = REMINDER_IMAGE_URL_THUMB;
		$REMINDER_NO_IMAGE_URL = REMINDER_NO_IMAGE_URL;
		
  		$Reminderresult = $this->db->query("SELECT 
													er.iUserID,
  													er.iReminderID,
													er.vTitle,
													if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL',er.vImage),'') as vImage,
													if(er.vImage != '',CONCAT('$REMINDER_IMAGE_URL_THUMB',er.vImage),'') as vImageThumb,
 													DATE_FORMAT(er.tTime,'%h:%i:%s %p') as tTime,
													DATE_FORMAT(er.dDate,'%Y-%b-%d') as dDate,
													er.vComment as vComment,
													er.vAddress,
													er.dLat,
													er.dLong
												
												FROM tbl_expense_reminder er , tbl_user u
												
												WHERE 
													er.iUserID = u.iUserID
													AND er.eReminderStatus != 'Inactive'
													AND er.eIsDeleted != 'yes'
													AND er.iReminderID = '".$data['iReminderID']."'
 											");
 		//echo $this->db->last_query();
		if($Reminderresult->num_rows()>0) {
 			 								
			$reminderdata = $Reminderresult->row_array();
			$returnArr['vData'] = $reminderdata;
 			return $returnArr;
 		}
		else {
			//$returnArr['vData'] = array();
 			return 0;
		}

		return 0;
	}


	//Created By : ID on 01-05-2017
    //Created for : Get Expense category list
	public function getExpenseCateggoryList()
	{
		$result = $this->db->select('iExpenseCateID,vCatName')->get_where('tbl_expense_category',array('eStatus'=>'Active','eIsDeleted'=>'no'))->result_array();
		if(!empty($result))
		{
			return $result;
		}
		else
		{
			return array();
		}
	}

	//Created By : ID on 02-05-2017
    //Created for : Add reminder data
	public function addReminderData($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$insertArr = array(	'iUserID'=>$iUserID,
							'vTitle'=>$data['vTitle'],
							'dDate'=>$data['dDate'],
							'tTime'=>$data['tTime'],
							'vImage'=>isset($data['vImage'])?$data['vImage']:'',
 							'vComment'=>$data['vComment'],
							'vAddress'=>$data['vAddress'],
							'dLat'=>$data['dLat'],
							'dLong'=>$data['dLong'],
							'dtCreated'=>date('Y-m-d')
							);
	 
		if($this->db->insert('tbl_expense_reminder',$insertArr)){

			$iReminderID = $this->db->insert_id();
			return array('iReminderID'=>$iReminderID,
					'iUserID'=>$iUserID,
					'vTitle'=>$data['vTitle'],
					'vImage'=>isset($data['vImage'])?REMINDER_IMAGE_URL.$data['vImage']:'',
 					//'vImage'=>REMINDER_IMAGE_URL.$data['vImage'],
					//'vImageThumb'=>REMINDER_IMAGE_URL_THUMB.$data['vImage'],
					'vImageThumb'=>isset($data['vImage'])?REMINDER_IMAGE_URL_THUMB.$data['vImage']:'',
					'dDate' =>date('Y-M-d',strtotime($data['dDate'])),
					'tTime'=>date('h:i:s A',strtotime($data['tTime'])),
					'vComment'=>$data['vComment'],
					'vAddress'=>$data['vAddress'],
					'dLat'=>$data['dLat'],
					'dLong'=>$data['dLong'],
					'dtCreated'=>date('Y-M-d',strtotime($insertArr['dtCreated']))
				);
		}
		else
		{
			return 0;

		}
	}

	//Created By : ID on 02-05-2017
    //Created for : edit reminder data
	public function deleteUserReminderImage($iReminderID)
	{
		$result = $this->db->select('vImage')->get_where('tbl_expense_reminder',array('iReminderID'=>$iReminderID))->row_array();
		if(!empty($result))
		{
			unlink(REMINDER_IMAGE_PATH.$result['vImage']);
			unlink(REMINDER_IMAGE_PATH_THUMB.$result['vImage']);
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 02-05-2017
    //Created for : edit reminder data
	public function editExpenseReminder($postData) {
	
		if(isset($postData['vImage']) && $postData['vImage'] != "" ){
			$updateArr = array('vTitle'=>$postData['vTitle'],
								'vImage'=>$postData['vImage'],
								'dDate'=>date('Y-m-d',strtotime($postData['dDate'])),
								'tTime'=>$postData['tTime'],
								'vComment'=>$postData['vComment'],
								'vAddress'=>$postData['vAddress'],
								'dLat'=>$postData['dLat'],
								'dLong'=>$postData['dLong']
								);
		}
		else {
			$updateArr = array('vTitle'=>$postData['vTitle'],
								'dDate'=>date('Y-m-d',strtotime($postData['dDate'])),
								'tTime'=>$postData['tTime'],
								'vComment'=>$postData['vComment'],
								'vAddress'=>$postData['vAddress'],
								'dLat'=>$postData['dLat'],
								'dLong'=>$postData['dLong']
								);
		}
		
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$iReminderID = $postData['iReminderID'];
					
		if($this->db->update('tbl_expense_reminder',$updateArr,array('iReminderID'=>$postData['iReminderID']))) {
			// ===========
				// if(er.vImage != '',CONCAT('".REMINDER_IMAGE_URL."',er.vImage),'') as vImage,
				// if(er.vImage != '',CONCAT('".REMINDER_IMAGE_URL_THUMB."',er.vImage),'$REMINDER_NO_IMAGE_URL') as vImageThumb,
												
				$Reminderresult = $this->db->query("SELECT 
 														er.iReminderID,
														er.vTitle,
														DATE_FORMAT(er.tTime,'%h:%i:%s %p') as tTime,
														DATE_FORMAT(er.dDate,'%Y-%b-%d') as dDate,
														if(er.vImage != '',CONCAT('".REMINDER_IMAGE_URL."',er.vImage),'') as vImage,
														if(er.vImage != '',CONCAT('".REMINDER_IMAGE_URL_THUMB."',er.vImage),'') as vImageThumb,
														er.vComment as vComment,
														er.vAddress,
														er.dLat,
														er.dLong
 													FROM tbl_expense_reminder er
 			
													WHERE er.iReminderID = $iReminderID ");
													
				if($Reminderresult->num_rows()>0) {
					$resultArr = $Reminderresult->result_array();
					return $resultArr[0];
				}
				else {
					return 0;
				}	
		  
							
			// ==========
		
			/*return array('iReminderID'=>$postData['iReminderID'],
						'iUserID'=>$iUserID,
						'vTitle'=>$postData['vTitle'],
						'vImage'=>REMINDER_IMAGE_URL.$postData['vImage'],
						'vImageThumb'=>REMINDER_IMAGE_URL_THUMB.$postData['vImage'],
						'dDate' =>date('Y-M-d',strtotime($postData['dDate'])),
						'tTime'=>date('h:i:s A',strtotime($postData['tTime'])),
						'vComment'=>$postData['vComment'],
						'vAddress'=>$postData['vAddress'],
						'dLat'=>$postData['dLat'],
						'dLong'=>$postData['dLong']);*/
		}
		else {
			return 0;
		}
	}


	public function deleteReminder($postdata) {

		if($this->db->update('tbl_expense_reminder',array('eIsDeleted'=>'yes'),array('iReminderID'=>$postdata['iReminderID']))){
			return 1;
		}else{
			return 0;
		}
	}

	//Created By : ID on 01-05-2017
    //Created for : Add user Expense
	public function addUserExpense($data)
	{
		$vExpenseImage_Main = "";
		$vExpenseImage_Thumb = "";
		$insertArr = array();
		
		if(isset($data['vExpenseImage']) && $data['vExpenseImage'] != "" ){
 			$vExpenseImage_Main = EXPENSE_IMAGE_URL.$data['vExpenseImage'];		
 			$vExpenseImage_Thumb = EXPENSE_IMAGE_URL_THUMB.$data['vExpenseImage'];	
			
			$insertArr['vExpenseImage'] =  $data['vExpenseImage'];				
		}
		else
			$insertArr['vExpenseImage'] =  "";				
		 
		$insertArr = array('iUserID'=>$_SERVER['HTTP_IUSERID'],
							'iExpenseCateID'=>$data['iExpenseCateID'],
							'vExpanseTitle'=>$data['vExpanseTitle'],
							'dAmount'=>$data['dAmount'],
							//($data['vImage']==""?'':$data['vImage'])
							'vBusinessName'=>$data['vBusinessName'],
							'dDate'=>$data['dDate'],
							'vDetail'=>isset($data['vDetail'])?$data['vDetail']:'',
							'dtCreated'=>date('Y-m-d H:m:i')
						);
	 
		if($this->db->insert('tbl_user_expense',$insertArr))
		{	
			$iUserExpenseID = $this->db->insert_id();
			$vCatName = $this->db->select('vCatName')->get_where('tbl_expense_category',array('iExpenseCateID'=>$data['iExpenseCateID']))->row_array();
			$returnArr = array('iUserExpenseID'=>$iUserExpenseID,
								'iUserID'=>$_SERVER['HTTP_IUSERID'],
								'iExpenseCateID'=>$data['iExpenseCateID'],
								'vCatName'=>$vCatName['vCatName'],
								'vExpanseTitle'=>$data['vExpanseTitle'],
								'dAmount'=>$data['dAmount'],
								//($var > 2 ? true : false)
								'vExpenseImage'=> $vExpenseImage_Main,
								'vExpenseImageThumb'=> $vExpenseImage_Thumb,
								'vBusinessName'=>$data['vBusinessName'],
								'dDate'=>date('Y-M-d',strtotime($data['dDate'])),
								'vDetail'=>isset($data['vDetail'])?$data['vDetail']:''
 								);
			return $returnArr;
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 01-05-2017
	//Created for : Edit user expense
	public function editUserExpense($data)
	{
 		$vExpenseImage_Main = "";
		$vExpenseImage_Thumb = "";
		$vExpenseImage = "";
		
		if(isset($data['vExpenseImage']) && $data['vExpenseImage'] != "" ){
			//echo "image yes";
 			$vExpenseImage_Main = EXPENSE_IMAGE_URL.$data['vExpenseImage'];		
 			$vExpenseImage_Thumb = EXPENSE_IMAGE_URL_THUMB.$data['vExpenseImage'];	
			$vExpenseImage = $data['vExpenseImage'];
			
			$updateArr = array('iExpenseCateID'=>$data['iExpenseCateID'],
								'vExpanseTitle'=>$data['vExpanseTitle'],
								'dAmount'=>$data['dAmount'],
								'vExpenseImage'=>$vExpenseImage,
								'vBusinessName'=>$data['vBusinessName'],
								'dDate'=>$data['dDate'],
								'vDetail'=>isset($data['vDetail'])?$data['vDetail']:'',
								'dtCreated'=>date('Y-m-d H:i:i')
							  );
 		}		
		else{
			//echo "Img NO";
 			$updateArr = array('iExpenseCateID'=>$data['iExpenseCateID'],
								'vExpanseTitle'=>$data['vExpanseTitle'],
								'dAmount'=>$data['dAmount'],
								'vBusinessName'=>$data['vBusinessName'],
								'dDate'=>$data['dDate'],
								'vDetail'=>isset($data['vDetail'])?$data['vDetail']:'',
								'dtCreated'=>date('Y-m-d H:i:i')
							  );
 		}		
		
		$iUserExpenseID = $data['iUserExpenseID'];
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$EXPENSE_IMAGE_URL = EXPENSE_IMAGE_URL;
		$EXPENSE_IMAGE_URL_THUMB = EXPENSE_IMAGE_URL_THUMB;
		$EXPENSE_NO_IMAGE_URL = EXPENSE_NO_IMAGE_URL;
		
		
		if($this->db->update('tbl_user_expense',$updateArr,array('iUserExpenseID'=>$iUserExpenseID))){
  			//$vCatName = $this->db->select('vCatName')->get_where('tbl_expense_category',array('iExpenseCateID'=>$data['iExpenseCateID']))->row_array();
 			//$result = $this->db->select('vExpenseImage')->get_where('tbl_user_expense',array('iUserExpenseID'=>$iUserExpenseID))->row_array();
 			
			$result = $this->db->query("SELECT  ue.iUserExpenseID,
												ue.iUserID,
												ue.vExpanseTitle,
												ue.dAmount,
												ue.vBusinessName,
												ue.vDetail,
												DATE_FORMAT(ue.dDate,'%Y-%b-%d') as dDate,
												if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL',ue.vExpenseImage),'') as vExpenseImage,
												if(ue.vExpenseImage != '',CONCAT('$EXPENSE_IMAGE_URL_THUMB',ue.vExpenseImage),'') as vExpenseImageThumb,
												ec.vCatName
												FROM tbl_user_expense ue 
												INNER JOIN tbl_expense_category ec 
												ON ec.iExpenseCateID = ue.iExpenseCateID
												WHERE ue.iUserExpenseID = $iUserExpenseID ");

 			if($result->num_rows()>0) {
	    		$resultArr = $result->result_array();
 				return $resultArr[0];
			}
			else {
				return 0;
			}	
		 
 		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 01-05-2017
	//Created for : Delete user expense image
	public function deleteUserExpenseImage()
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$result = $this->db->select('vExpenseImage')->get_where('tbl_user_expense',array('iUserID'=>$iUserID))->row_array();
		if(!empty($result['vExpenseImage']))
		{
			unlink(EXPENSE_IMAGE_PATH.$result['vExpenseImage']);
			unlink(EXPENSE_IMAGE_PATH_THUMB.$result['vExpenseImage']);
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 01-05-2017
	//Created for : Delete user expense
	public function deleteExpense($data)
	{
		$iUserExpenseID = $data['iUserExpenseID'];
		if($this->db->update('tbl_user_expense',array('eIsDeleted'=>'yes'),array('iUserExpenseID'=>$iUserExpenseID)))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 03-05-2017
    //Created for : Get my log list
	public function getMyLogList($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		if($data['page']==1 || $data['page']<=0) {
    		$page=0;
    	}
    	else {
    		$page=($data['page']*10)-10;
    	}
		// CONCAT(ul.vStartAddress,' ','at',' ',DATE_FORMAT(ul.tStartTime,'%l:%i %p')) as vStartAddress,
		// if(ul.eCompleted = 'Yes', CONCAT(ul.vEndAddress,' ','at',' ',DATE_FORMAT(ul.tEndTime,'%l:%i %p')),'' ) as vEndAddress,
		// if(ul.eCompleted = 'Yes', CONCAT(ul.dDistance,' ',UPPER(u.eDistance)),'' ) as dDistance,

    	$result = $this->db->query("SELECT ul.iLogID,
      									DATE_FORMAT(FROM_UNIXTIME(ul.iStartDatetimeUnix),'%Y-%b-%d') as dDate,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iStartDatetimeUnix),'%H:%i:%s') as tStartTime,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iEndDatetimeUnix),'%Y-%b-%d') as dDateEnd,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iEndDatetimeUnix),'%H:%i:%s') as tEndTime,
       									ul.vDuration as vDuration,
       									ul.vStartArea as vStartArea,
    									ul.vEndArea as vEndArea,
    									ul.vStartAddress,
        								if(ul.eCompleted = 'Yes', CONCAT(if(u.eDistance = 'Km', if(ul.dDistance= '0','0.00',ul.dDistance), if(ul.dDistance= '0','0.00',ul.dDistance_mile)),' ',UPPER(u.eDistance)),'' ) as dDistance,
    									if(ul.eCompleted = 'Yes', ul.vEndAddress,'' ) as vEndAddress,
    									ul.eCompleted
    									FROM tbl_user_log ul 
    									LEFT JOIN tbl_user u
    									ON u.iUserID = ul.iUserID
    									WHERE ul.iUserID = $iUserID 
    									ORDER BY ul.iLogID DESC
    									LIMIT $page,10 
    								 ");
    	//mprd($this->db->last_query());
    	if($result->num_rows()>0)
    	{
    		$resultArr = $result->result_array();
     		foreach ($resultArr as $key => $value) {
				  /* if ($value['eCompleted'] == "Yes") {
	    			   	$resultArr[$key]['vDuration'] = $this->getDuration($value['dDate'].' '.$value['tEndTime'],$value['dDate'].' '.$value['tStartTime']);
				   }else {
				   	   	$resultArr[$key]['vDuration'] = "";
				   }*/
 				   $TotalResult = $this->db->query("SELECT ul.iLogID
																FROM tbl_user_log ul 
																LEFT JOIN tbl_user u
																ON u.iUserID = ul.iUserID
																WHERE ul.iUserID = $iUserID 
															 ");
		     	   	$TotalResultCount = $TotalResult->num_rows();
		     	    $returnArr['vData'] = $resultArr;
					$returnArr['iTotalRecords'] = $TotalResultCount;
					$returnArr['iPages'] = ceil($TotalResultCount/10);
    		}
    	}else{
    		$returnArr['vData'] = array();
			$returnArr['iTotalRecords'] = 0;
			$returnArr['iPages'] = 0;
    	}
    	return $returnArr;
	}
	
	public function exportLogbook()
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		/* 
		     									FROM_UNIXTIME(ul.iStartDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iStartDatetimeUnix,
     									FROM_UNIXTIME(ul.iEndDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iEndDatetimeUnix,
		*/
 
    	$result = $this->db->query("SELECT ul.iLogID,
     									FROM_UNIXTIME(ul.iStartDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iStartDatetimeUnix,
     									FROM_UNIXTIME(ul.iEndDatetimeUnix, '%Y-%b-%d %h:%i:%s %p') as iEndDatetimeUnix,
										ul.vStartArea as vStartArea,
    									ul.vEndArea as vEndArea,
    									ul.vStartAddress,
        								if(ul.eCompleted = 'Yes', CONCAT(if(u.eDistance = 'Km', if(ul.dDistance= '0','0.00',ul.dDistance), if(ul.dDistance= '0','0.00',ul.dDistance_mile)),' ',UPPER(u.eDistance)),'' ) as dDistance,
    									if(ul.eCompleted = 'Yes', ul.vEndAddress,'' ) as vEndAddress,
    									ul.eCompleted
    									FROM tbl_user_log ul 
    									LEFT JOIN tbl_user u
    									ON u.iUserID = ul.iUserID
    									WHERE ul.iUserID = $iUserID 
    									ORDER BY ul.iLogID DESC
     								 ");
		
 											 
     	if($result->num_rows()>0)
    	{
    		$resultArr = $result->result_array();

    		foreach ($resultArr as $key => $value) {
				   if ($value['eCompleted'] == "Yes") {
	    			   	$resultArr[$key]['vDuration'] = $this->getDuration(strtotime($value['iEndDatetimeUnix']),strtotime($value['iStartDatetimeUnix']));
 				   }else {
				   	   	$resultArr[$key]['vDuration'] = "";
				   }
 		     	   
				   $TotalResult = $this->db->query("SELECT ul.iLogID
															FROM tbl_user_log ul 
															LEFT JOIN tbl_user u
															ON u.iUserID = ul.iUserID
															WHERE ul.iUserID = $iUserID 
														 ");
		     	   	$TotalResultCount = $TotalResult->num_rows();
		     	    $returnArr['vData'] = $resultArr;
					$returnArr['iTotalRecords'] = $TotalResultCount;
     		}
    	}else{
 			$returnArr['iTotalRecords'] = 0;
     	}
    	return $returnArr;
	}
	
 
	public function addStartLog($data)
	{
		$insertArr=array('iUserID'=>$_SERVER['HTTP_IUSERID'],
						'iStartDatetimeUnix'=>$data['iStartDatetimeUnix'],
  						'dStartLat'=>$data['dStartLat'],
						'vStartAddress'=>$data['vStartAddress'],
						'vStartArea'=>$data['vStartArea'],
						'dStartLong'=>$data['dStartLong'],
						'dtCreated'=>date('Y-m-d'));

		if($this->db->insert('tbl_user_log',$insertArr)){
 			$iLogID = $this->db->insert_id();

			return array('iLogID'=>$iLogID,
						'iUserID'=>$_SERVER['HTTP_IUSERID'],
						//'iStartDatetimeUnix'=>$data['iStartDatetimeUnix'],
						'dDate'=>date('Y-M-d',$data['iStartDatetimeUnix']),
						'tStartTime'=>date('H:i:s',$data['iStartDatetimeUnix']),
   						'dStartLat'=>$data['dStartLat'],
						'vStartAddress'=>$data['vStartAddress'],
						'vStartArea'=>$data['vStartArea'],
						'dStartLong'=>$data['dStartLong'],
						'eCompleted'=>'No',
 						'dtCreated'=>date('Y-M-d',strtotime($insertArr['dtCreated'])));
 		}else{
			return 0;
		}

	}
	
	public function addEndLog($data)
	{
		$iLogID = $data['iLogID'];
  		$iUserID = $_SERVER['HTTP_IUSERID'];
		
 		//Get User Distance Setting
		$UserUnitArr = $this->getUserDistanceUnit($iUserID);
 		$unit = $UserUnitArr['eDistance'];
 		
		// Get Log Data - Initial
		$result = $this->db->query("SELECT  iLogID,
											dStartLat,
											dStartLong,
											iStartDatetimeUnix
 											FROM tbl_user_log 
											where iLogID = '".$data['iLogID']."'
      								 ");
		$result_log = $result->row_array();
  						
		//get_distance from two points: Start , End in Km		
		$distance_km = $this->get_distance($result_log['dStartLat'], $result_log['dStartLong'], $data['dEndLat'], $data['dEndLong'], "Km");
 		// Get Distacne in Miles
		$distance_mile = $this->get_distance($result_log['dStartLat'], $result_log['dStartLong'], $data['dEndLat'], $data['dEndLong'], "Miles");
 		
 		$vDuration = $this->getDuration($data['iEndDatetimeUnix'],$result_log['iStartDatetimeUnix']);
		
		$updArr = array('iUserID'=>$_SERVER['HTTP_IUSERID'],
   						'iEndDatetimeUnix'=>$data['iEndDatetimeUnix'],
   						'vDuration'=>$vDuration,
 						'vEndAddress'=>$data['vEndAddress'],
 						'vEndArea'=>$data['vEndArea'],
 						'dDistance'=>round($distance_km,2), // km
						'dDistance_mile'=>round($distance_mile,2), // mile
						'dEndLat'=>$data['dEndLat'],
						'dEndLong'=>$data['dEndLong'],
						'eCompleted'=>'Yes', // To complete log
						'dtCreated'=>date('Y-m-d')); 
   					
		if($this->db->update('tbl_user_log',$updArr,array('iLogID'=>$iLogID))){
  			// fetch lates records
      		$result = $this->db->query("SELECT ul.iLogID,
  										DATE_FORMAT(FROM_UNIXTIME(ul.iStartDatetimeUnix),'%Y:%b:%d') as dDate,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iStartDatetimeUnix),'%H:%i:%s') as tStartTime,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iEndDatetimeUnix),'%Y:%b:%d') as dDateEnd,
    									DATE_FORMAT(FROM_UNIXTIME(ul.iEndDatetimeUnix),'%H:%i:%s') as tEndTime,
      									ul.iStartDatetimeUnix as iStartDatetimeUnix,
      									ul.iEndDatetimeUnix as iEndDatetimeUnix,
      									ul.dStartLat as dStartLat,
    									ul.dStartLong as dStartLong,
       									ul.vDuration as vDuration,
    									ul.vStartArea as vStartArea,
    									ul.vEndArea as vEndArea,
    									ul.eCompleted as eCompleted,
    									CONCAT(ul.vStartAddress,' ','at',' ', DATE_FORMAT(FROM_UNIXTIME(ul.iStartDatetimeUnix),'%l:%i %p')) as vStartAddress,
    									CONCAT(ul.vEndAddress,' ','at',' ', DATE_FORMAT(FROM_UNIXTIME(ul.iEndDatetimeUnix),'%l:%i %p')) as vEndAddress,
        								if(ul.eCompleted = 'Yes', CONCAT(if(u.eDistance = 'Km', if(ul.dDistance= '0','0.00',ul.dDistance), if(ul.dDistance= '0','0.00',ul.dDistance_mile)),' ',UPPER(u.eDistance)),'' ) as dDistance,
    									ul.eCompleted as eCompleted 
    									FROM tbl_user_log ul 
    									LEFT JOIN tbl_user u
    									ON u.iUserID = ul.iUserID
    									WHERE ul.iUserID = $iUserID 
										AND ul.iLogID = '".$data['iLogID']."'
    									ORDER BY ul.iLogID DESC
     								 ");
 			$resultArr = $result->row_array();
		 
			return array('iLogID'=>$iLogID,
						'iUserID'=>$_SERVER['HTTP_IUSERID'],
   						/*'iStartDatetimeUnix'=>$resultArr['iStartDatetimeUnix'],
  						'iEndDatetimeUnix'=>$resultArr['iEndDatetimeUnix'],*/
 						'dDate'=>date('Y-M-d',$resultArr['iStartDatetimeUnix']),
						'tStartTime'=>date('H:i:s',$resultArr['iStartDatetimeUnix']),
 						'dDateEnd'=>date('Y-M-d',$resultArr['iEndDatetimeUnix']),
						'tEndTime'=>date('H:i:s',$resultArr['iEndDatetimeUnix']),
						'vStartArea'=>$resultArr['vStartArea'],
  						'vStartAddress'=>$resultArr['vStartAddress'],
  						'vEndAddress'=>$data['vEndAddress'],
 						'vEndArea'=>$data['vEndArea'],
						'dEndLat'=>$data['dEndLat'],
						'dEndLong'=>$data['dEndLong'],
 						'dDistance'=>$resultArr['dDistance'],
						'vDuration'=>$resultArr['vDuration'],
						'eCompleted'=>$resultArr['eCompleted'],
 						'dtCreated'=>date('Y-M-d',strtotime($updArr['dtCreated'])));
 		}else{
			return 0;
		}

	}


	public function getDuration($endDate,$startDate){
		 
	    //$seconds  = strtotime(date('Y-m-d H:i:s',strtotime($endDate))) - strtotime(date('Y-m-d H:i:s',strtotime($startDate)));
	   $seconds  = $endDate - $startDate;
 	   $months = floor($seconds / (3600*24*30));
 	   $day = floor($seconds / (3600*24));
 	   $hours = floor($seconds / 3600);
 	   $mins = floor(($seconds - ($hours*3600)) / 60);
 	   $secs = floor($seconds % 60);

 	   if($seconds < 60) {
 	   		$time = $secs." second(s)";
 	   }else if($seconds < 60*60 ) {
 	   		$time = $mins." Minute(s)";
 	   }else {
 	   		$time = $hours." Hour(s)";
 	   }
	   /*else if($seconds < 24*60*60) {
 	   		$time = $day." Day(s)";
 	   }else {
 	   		$time = $months." months";
 	   }*/
  	   return $time;
	}
	
	
	/*public function getDuration($endDate,$startDate){
 
	   $seconds  = strtotime(date('Y-m-d H:i:s',strtotime($endDate))) - strtotime(date('Y-m-d H:i:s',strtotime($startDate)));
 	   $months = floor($seconds / (3600*24*30));
 	   $day = floor($seconds / (3600*24));
 	   $hours = floor($seconds / 3600);
 	   $mins = floor(($seconds - ($hours*3600)) / 60);
 	   $secs = floor($seconds % 60);

 	   if($seconds < 60) {
 	   		$time = $secs." seconds";
 	   }else if($seconds < 60*60 ) {
 	   		$time = $mins." Minutes";
 	   }else if($seconds < 24*60*60) {
 	   		$time = $hours." Hours";
 	   }else if($seconds < 24*60*60) {
 	   		$time = $day." Days";
 	   }else {
 	   		$time = $months." months";
 	   }
 	   return $time;
	}*/
	
	
	function get_distance($lat1, $lon1, $lat2, $lon2, $unit) {
 		  // M, K, N	
		  $theta = $lon1 - $lon2;
		  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
		  $dist = acos($dist);
		  $dist = rad2deg($dist);
		  $miles = $dist * 60 * 1.1515;
		  $unit = strtoupper($unit);
 		  
		  if ($unit == "KM") {
 			  return ($miles * 1.609344);
		  } else {
 			  return $miles;
		  }
		  
		  /*
		  if ($unit == "Km") {
			  return ($miles * 1.609344);
		  } else if ($unit == "Miles") { // N = Miles
			  return ($miles * 0.8684);
		  } else {
			  return $miles;
		  }
		  */
	}

	public function getPostCategory()
	{

		$result = $this->db->query("SELECT iPostCatID,
								vCatName,
								vColorCode,
								eIsInnerPurchase
 							FROM tbl_post_category pc
							WHERE eIsDeleted != 'yes' 
							AND eStatus != 'Inactive'");

		$resultArr = $result->result_array();
		return $resultArr;
	}

	//Created By : ID on 06-04-2017
    //Created for : Test Notification
    public function updateNotification() {

    	$iUserID = $_SERVER['HTTP_IUSERID'];
    	$result = $this->db->select('eIsNotification')->get_where('tbl_user',array('iUserID'=>$iUserID));

    	if($result->num_rows()>0)
    	{
    		$resultArr = $result->row_array();
    		if($resultArr['eIsNotification'] == 1)
    		{
    			$status = '0';

    		}
    		else
    		{
    			$status = '1';
    		}
    		$this->db->update('tbl_user',array('eIsNotification'=>$status),array('iUserID'=>$iUserID));
    		return array('eIsNotification'=>$status);
    	}
    	else
    	{
    		return 0;
    	}

    }


    public function addPost($data)
    {
    	$insertData = array('iUserID'=>$_SERVER['HTTP_IUSERID'],
							'vDetail'=>$data['vDetail'],
							'vTitle'=>$data['vTitle'],
							'vPostImage'=>$data['vPostImage'],
							'iPostCatID'=>$data['iPostCatID'],
 							'dtCreated'=>date('Y-m-d H:i:s'));
    	
		// Update post count if catid = 3 = job
		$jobPost_data = $this->db->select('jobPostCount, jobPurchasedCount')->get_where('tbl_user',array('iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();			
 		$jobPostRemainingCount =$jobPost_data['jobPurchasedCount'] - $jobPost_data['jobPostCount'];
		
		//$jobPurchasedCount_data = $this->db->select('SUM(iJobCount) as jobPurchasedCount')->get_where('tbl_job_purchase_history',array('iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();
		//$jobPostRemainingCount= $jobPurchasedCount_data['jobPurchasedCount'] - $jobPostCount_data['jobPostCount']; // Purchased - posted				
		if($data['iPostCatID'] == 3 && $jobPostRemainingCount <= 0)	{	
			return 2;
		} 
		else {
			if($this->db->insert('tbl_user_post',$insertData)){
				$iUserPostID = $this->db->insert_id();
	
				$vPostname = $this->db->select('vCatName,vColorCode,eIsInnerPurchase')->get_where('tbl_post_category',array('iPostCatID'=>$data['iPostCatID']))->row_array();
				$iLikeCount = $this->db->select('count(pl.iPostLikeID) as iLikeCount')->get_where('tbl_post_like pl',array('pl.iPostID'=>$iUserPostID))->row_array();
				$iCommentCount = $this->db->select('count(pc.iPostCommentID) as iCommentCount')->get_where('tbl_post_comment pc',array('pc.iPostID'=>$iUserPostID))->row_array();
				$likestatus = $this->db->select('count(pl.iPostLikeID) as likestatus')->get_where('tbl_post_like pl',array('pl.iPostID'=>$iUserPostID, 'pl.iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();
				
				//$likestatus = $this->db->select('count(pl.iPostLikeID) as likestatus')->get_where('tbl_post_like pl',array('pl.iPostID'=>$iUserPostID, 'pl.iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();
				//(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID AND iUserID = $iUserID) as likestatus,
				
				$userdata = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
				$vProfileImage = isset($userdata['vProfileImage'])?USER_IMAGE_URL.$userdata['vProfileImage']:"";
				$vProfileImageThumb = isset($userdata['vProfileImage'])?USER_IMAGE_URL_THUMB.$userdata['vProfileImage']:"";
				
				// Update post count if catid = 3 = job
				if($data['iPostCatID'] == 3) {
 					 $this->db->where('iUserID', $_SERVER['HTTP_IUSERID']);
					 $this->db->set('jobPostCount', 'jobPostCount+1', FALSE);
					 $this->db->update('tbl_user');
 				}	 

				//$jobPostCount_data = $this->db->select('count(*) as jobPostCount')->get_where('tbl_user_post',array('iPostCatID'=>3, 'iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();			
				//$jobPurchasedCount_data = $this->db->select('iJobCount as jobPurchasedCount')->get_where('tbl_job_purchase_history',array('iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();
	
				//(SELECT count(*) as joppostcount  FROM `tbl_user_post` WHERE `iUserID` = 12 AND `iPostCatID` = 3) - SELECT count(*) as jobPurchasedCount  FROM `tbl_job_purchase_history` WHERE `iUserID` = 12	
				
				return array('iUserPostID'=>$iUserPostID,
					'iUserID'=>$_SERVER['HTTP_IUSERID'],
					'vDetail'=>$data['vDetail'],
					'vTitle'=>$data['vTitle'],
					'vFirstName'=>$userdata['vFirstName'],
					'vLastName'=>$userdata['vLastName'],
					'vUserName'=>$userdata['vUserName'],
					'vEmail'=>$userdata['vEmail'],
					'iPhoneNumber'=>$userdata['iPhoneNumber'],
					'vTradeName'=>$userdata['vTradeName'],
					'vProfileImage'=>$userdata['vProfileImage'],
					'vProfileImageThumb'=>$userdata['vProfileImageThumb'],
					'vPostImage'=>$data['vPostImage'] != ''?POST_IMAGE_URL.$data['vPostImage']:'',
					'vPostImageThumb'=>$data['vPostImage'] != ''?POST_IMAGE_URL_THUMB.$data['vPostImage']:'',
					//'vPostImageThumb'=>POST_IMAGE_URL_THUMB.$data['vPostImage'],
					'iPostCatID'=>$data['iPostCatID'],
					'eIsInnerPurchase'=>$vPostname['eIsInnerPurchase'],
					
					
					'jobPostRemainingCount'=> ($data['iPostCatID'] == 3?$jobPostRemainingCount-1:$jobPostRemainingCount), // Purchased - posted				
					
					'vCatName'=>$vPostname['vCatName'],
					'vColorCode'=>$vPostname['vColorCode'],
					'vColorCode'=>$vPostname['vColorCode'],
					 
					'iLikeCount'=>$iLikeCount['iLikeCount'],
					'likestatus'=>$likestatus['likestatus'],
					'iCommentCount'=>$iCommentCount['iCommentCount'],
					'dtCreated'=>date('Y-M-d h:i:s A',strtotime($insertData['dtCreated'])) );
			}
			else {
				return 0;
			}
		}
 			
    }


    public function editPost($data)
    {
    	$updateArr = array('vDetail'=>$data['vDetail'],
						'vTitle'=>$data['vTitle'],
						'iPostCatID'=>$data['iPostCatID']
					);
			
		// if Image is not being uploaded then display OLD
		if(isset($data['vPostImage']) && $data['vPostImage'] != '')  {
			$updateArr['vPostImage'] = $data['vPostImage'];
		}
 
	   if($this->db->update('tbl_user_post',$updateArr,array('iUserPostID'=>$data['iUserPostID']))){
		
     		$iUserPostID = $data['iUserPostID'];
 			/*
				IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'$POST_IMAGE_NO_URL_THUMB') as vPostImage,
				IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'$POST_IMAGE_NO_URL_THUMB') as vPostImageThumb,
			*/
 			 
    		$POST_IMAGE_URL = POST_IMAGE_URL;
    		$POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
    		$POST_IMAGE_NO_URL_THUMB = POST_IMAGE_NO_URL_THUMB;
    		$result = $this->db->query("SELECT up.iUserPostID,
												up.iUserID,
												up.vDetail,
												up.vTitle,
 												IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'') as vPostImage,
												IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'') as vPostImageThumb,
												up.iPostCatID,
												pc.vCatName,
												pc.vColorCode,
												pc.eIsInnerPurchase,												
												(SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID=up.iUserPostID AND eIsDeleted = 'no') as iCommentCount,
 												(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID) as iLikeCount,
												up.dtCreated 
										FROM tbl_user_post up
										LEFT JOIN tbl_post_category pc
										ON pc.iPostCatID = up.iPostCatID
										LEFT JOIN tbl_post_comment pcc
										ON pcc.iPostID = up.iUserPostID
										LEFT JOIN tbl_post_like pl
										ON pl.iPostID = up.iUserPostID
										WHERE up.iUserPostID = $iUserPostID ");
 									 /*
									(SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID=up.iUserPostID AND eIsDeleted = 'no') as iCommentCount,
									(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID) as iLikeCount,
									(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID AND iUserID = $iUserID) as likestatus,
									  */
			/*echo $this->db->last_query();
			exit;*/
			
    		if($result->num_rows() > 0) {
    			$resultArr = $result->row_array();
    			//$resultArr['dtCreated'] = $this->getDuration(date('Y-m-d H:i:s'),$resultArr['dtCreated']);
    			$resultArr['dtCreated'] =  date('Y-M-d h:i:s A',strtotime($resultArr['dtCreated'])) ;
				
				// Get User Data
				$userdata = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
				$vProfileImage = isset($userdata['vProfileImage'])?USER_IMAGE_URL.$userdata['vProfileImage']:"";
				$vProfileImageThumb = isset($userdata['vProfileImage'])?USER_IMAGE_URL_THUMB.$userdata['vProfileImage']:"";
			
    			$resultArr['vFirstName'] =  $userdata['vFirstName'];
    			$resultArr['vLastName'] =  $userdata['vLastName'];
    			$resultArr['vEmail'] =  $userdata['vEmail'];
    			$resultArr['iPhoneNumber'] =  $userdata['iPhoneNumber'];
    			$resultArr['vTradeName'] =  $userdata['vTradeName'];
    			$resultArr['vProfileImage'] =  $userdata['vProfileImage'];
    			$resultArr['vProfileImageThumb'] =  $userdata['vProfileImageThumb'];
			   
    			return $resultArr;
    		}
    		else {
    			return array();
    		} 
    	}
    	else {
    		return 0;
    	}
     }

    //Created By : ID on 05-05-2017
    //Created for : Remove post by post id
    public function removePostByPostID($data)
    {
    	if($this->db->update('tbl_user_post',array('eIsDeleted'=>'yes'),array('iUserPostID'=>$data['iUserPostID']))) {
    		return 1;
    	}
    	else
    	{
    		return 0;
    	}
    }

    //Created for : Get my feeds.
    public function getMyFeeds($data)
    {
		$sql_cond = '';
		$vKeyword = isset($data['vKeyword'])?$data['vKeyword']:'';
		$iPostCatID = isset($data['iPostCatID'])?$data['iPostCatID']:'';
		
	 	if(isset($data['vKeyword'])) {
			$sql_cond .= " AND ( up.vDetail LIKE '%$vKeyword%' OR up.vTitle LIKE '%".$vKeyword."%' )";
		}
		
		if(isset($data['iPostCatID'])) {
 			$sql_cond .= " AND up.iPostCatID IN ($iPostCatID)";				
		}
  		
    	if($data['page']==1 || $data['page']<=0) {
    		$page=0;
    	}
    	else  {
    		$page=($data['page']*10)-10;
    	}

    	$POST_IMAGE_URL = POST_IMAGE_URL;
		$POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
		$POST_IMAGE_NO_URL_THUMB = POST_IMAGE_NO_URL_THUMB;

		$USER_IMAGE_URL = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

		$iUserID = $_SERVER['HTTP_IUSERID'];
 
		$result = $this->db->query("SELECT up.iUserPostID,
								up.iUserID,
								up.vDetail,
								up.vTitle,
								u.vFirstName,
								u.vLastName,
								u.vUserName,
								u.vEmail,
								u.iPhoneNumber,
								t.vTradeName,
 								IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'') as vPostImage,
								IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'') as vPostImageThumb,
								IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),u.vFacebookImage) as vProfileImage,
								IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
								(SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID=up.iUserPostID AND eIsDeleted = 'no') as iCommentCount,
								(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID) as iLikeCount,
								(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID AND iUserID = $iUserID) as likestatus,
								up.iPostCatID,
								pc.vCatName,
								pc.vColorCode,
								pc.eIsInnerPurchase,
								up.dtCreated,
								DATE_FORMAT(up.dtCreated,'%Y-%b-%d %h:%i:%s %p')  as dtCreated
								  
							FROM tbl_user_post up
							LEFT JOIN tbl_post_category pc
							ON pc.iPostCatID = up.iPostCatID

							LEFT JOIN tbl_user u
							ON u.iUserID = up.iUserID
							
							LEFT JOIN tbl_trade t
							ON t.iTradeID = u.iTradeID
							
							WHERE up.eIsDeleted != 'Yes' 
							AND up.eStatus != 'Inactive'
							$sql_cond
							ORDER BY up.iUserPostID desc
							LIMIT $page,10
						 ");
			//echo $this->db->last_query(); exit;
			
			if($result->num_rows() > 0) {
    			$resultArr = $result->result_array();
    			/*foreach ($resultArr as $key => $value) {
    				$resultArr[$key]['dtCreated'] = $this->getDuration(date('Y-m-d H:i:s'),$value['dtCreated']);
     			}*/

    			$TotalResult = $this->db->query("SELECT up.iUserPostID 
													FROM tbl_user_post up
													LEFT JOIN tbl_post_category pc
													ON pc.iPostCatID = up.iPostCatID
													LEFT JOIN tbl_user u
													ON u.iUserID = up.iUserID
													WHERE up.eIsDeleted != 'Yes' 
													AND up.eStatus != 'Inactive' $sql_cond
    								 			");

	     	   	$TotalResultCount = $TotalResult->num_rows();	     	   	
	     	    $returnArr['vData'] = $resultArr;
				$returnArr['iTotalRecords'] = $TotalResultCount;
				$returnArr['iPages'] = ceil($TotalResultCount/10);
    		}
    		else
    		{
    			$returnArr['vData'] = array();
				$returnArr['iTotalRecords'] = 0;
				$returnArr['iPages'] = 0;
    		}
    		return $returnArr;
    }
	
	// To get Post Detail
	public function getFeedByID($iUserPostID)
    { 
    	$POST_IMAGE_URL = POST_IMAGE_URL;
		$POST_IMAGE_URL_THUMB = POST_IMAGE_URL_THUMB;
		$POST_IMAGE_NO_URL_THUMB = POST_IMAGE_NO_URL_THUMB;

		$USER_IMAGE_URL = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

		$iUserID = $_SERVER['HTTP_IUSERID'];
 
		$result = $this->db->query("SELECT up.iUserPostID,
								up.iUserID,
								up.vDetail,
								up.vTitle,
								u.vFirstName,
								u.vLastName,
								u.vUserName,
 								IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL',up.vPostImage),'') as vPostImage,
								IF(up.vPostImage != '',CONCAT('$POST_IMAGE_URL_THUMB',up.vPostImage),'') as vPostImageThumb,
								IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),u.vFacebookImage) as vProfileImage,
								IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
								(SELECT count(iPostCommentID) FROM tbl_post_comment WHERE iPostID=up.iUserPostID AND eIsDeleted = 'no') as iCommentCount,
								(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID) as iLikeCount,
								(SELECT count(iPostLikeID) FROM tbl_post_like WHERE iPostID=up.iUserPostID AND iUserID = $iUserID) as likestatus,
								up.iPostCatID,
								pc.vCatName,
								pc.vColorCode,
								pc.eIsInnerPurchase,
								up.dtCreated,
								DATE_FORMAT(up.dtCreated,'%Y-%b-%d %h:%i:%s %p')  as dtCreated
								  
							FROM tbl_user_post up
							LEFT JOIN tbl_post_category pc
							ON pc.iPostCatID = up.iPostCatID
							LEFT JOIN tbl_user u
							ON u.iUserID = up.iUserID
							WHERE up.eIsDeleted != 'Yes' 
							AND up.eStatus != 'Inactive'
							AND up.iUserPostID = $iUserPostID 
  						 ");
 			
			if($result->num_rows() > 0) {
    			$resultArr = $result->row_array();
				
				// Get User Data
				$userdata = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
				$vProfileImage = isset($userdata['vProfileImage'])?USER_IMAGE_URL.$userdata['vProfileImage']:"";
				$vProfileImageThumb = isset($userdata['vProfileImage'])?USER_IMAGE_URL_THUMB.$userdata['vProfileImage']:"";
			
    			/*$resultArr['vFirstName'] =  $userdata['vFirstName'];
    			$resultArr['vLastName'] =  $userdata['vLastName'];*/
    			$resultArr['vEmail'] =  $userdata['vEmail'];
    			$resultArr['iPhoneNumber'] =  $userdata['iPhoneNumber'];
    			$resultArr['vTradeName'] =  $userdata['vTradeName'];
    			$resultArr['vProfileImage'] =  $userdata['vProfileImage'];
    			$resultArr['vProfileImageThumb'] =  $userdata['vProfileImageThumb'];
				
   	     	    $returnArr['vData'] = $resultArr;
     		}
    		else {
				$res = array();
    			$returnArr['vData'] = (object)$res;
      		}
    		return $returnArr;
    }
	
	
	
	// send Contact Detail Via Mail
	public function sendContactDetailViaMail($iUserPostID)
    { 
 		$iUserID = $_SERVER['HTTP_IUSERID'];
 
		$result = $this->db->query("SELECT 
								up.iUserPostID,
								up.iUserID,
								up.vDetail,
								up.vTitle,
								u.vFirstName,
								u.vLastName,
								u.vUserName,
								
								u.vEmail,
								(select uu.vEmail from tbl_user uu where uu.iUserID = up.iUserID) as vEmail_owner,
								u.iPhoneNumber,
								t.vTradeName,								
 								
								up.iPostCatID,
								pc.vCatName							
								  
							FROM tbl_user_post up
							LEFT JOIN tbl_post_category pc
							ON pc.iPostCatID = up.iPostCatID

							LEFT JOIN tbl_user u
							ON u.iUserID = $iUserID
							
							LEFT JOIN tbl_trade t
							ON t.iTradeID = u.iTradeID
							
							WHERE up.eIsDeleted != 'Yes' 
							AND up.eStatus != 'Inactive'
							AND up.iUserPostID = $iUserPostID 
  						 ");
						 // ON u.iUserID = up.iUserID

 
			if($result->num_rows() > 0) {
				$this->load->library('email');

    			$resultArr = $result->row_array();
				
    			$resultArr_view = $resultArr;
				$resultArr_view['from'] = SUPPORT_EMAIL_ADDRESS;
				$resultArr_view['subject'] = "TradesUnite - Contact Detail";
				
				// Set Email Template 
				$this->load->view('email/ContactDetail', $resultArr_view);
				return $resultArr;
      		}
    		else {
    			return 0;
      		}
    }
 	
     //Created By :ID on 05-05-2017
    //Created for : Get CommentList by postid
    public function getCommentListBypostID($data)
    {
    	$iPostID = $data['iUserPostID'];
    	if($data['page']==1 || $data['page']<=0)
		{
    		$page=0;
    	}
    	else
    	{
    		$page=($data['page']*10)-10;
    	}

		$USER_IMAGE_URL = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

		$result = $this->db->query("SELECT c.iPostCommentID ,
											c.iUserID,
											u.vFirstName,
											u.vLastName,
											u.vUserName,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),u.vFacebookImage) as vProfileImage,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
											c.vComment,
											c.dtCreated
											FROM tbl_post_comment c
											LEFT JOIN tbl_user u
											ON u.iUserID = c.iUserID
											WHERE c.iPostID = '$iPostID'
											AND c.eIsDeleted != 'yes'
											ORDER BY c.iPostCommentID desc
											LIMIT $page,10 ");
 		if($result->num_rows() > 0) {
			$resultArr = $result->result_array();
			foreach ($resultArr as $key => $value) {
				$resultArr[$key]['dtCreated'] = date('Y-M-d h:i:s A',strtotime($value['dtCreated']));
 			}

			$TotalResult = $this->db->query("SELECT c.iPostCommentID
													FROM tbl_post_comment c
													LEFT JOIN tbl_user u
													ON u.iUserID = c.iUserID
													WHERE iPostID = '$iPostID'
													AND c.eIsDeleted != 'yes'
													ORDER BY c.iPostCommentID desc
								 			");

     	   	$TotalResultCount = $TotalResult->num_rows();
     	    $returnArr['vData'] = $resultArr;
			$returnArr['iTotalRecords'] = $TotalResultCount;
			$returnArr['iPages'] = ceil($TotalResultCount/10);
		}
		else
		{
			$returnArr['vData'] = array();
			$returnArr['iTotalRecords'] = 0;
			$returnArr['iPages'] = 0;
		}
		return $returnArr;
    }

      //Created By :ID on 05-05-2017
    //Created for : Get CommentList by postid
    public function getLikeListBypostID($data)
    {
    	$iPostID = $data['iUserPostID'];
    	if($data['page']==1 || $data['page']<=0)
		{
    		$page=0;
    	}
    	else
    	{
    		$page=($data['page']*10)-10;
    	}

		$USER_IMAGE_URL = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		$USER_NO_IMAGE_URL = USER_NO_IMAGE_URL;

		$result = $this->db->query("SELECT  pl.iPostLikeID,
											pl.iUserID,
											u.vFirstName,
											u.vLastName,
											u.vUserName,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),u.vFacebookImage) as vProfileImage,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
											pl.dtCreated
											FROM tbl_post_like pl
											LEFT JOIN tbl_user u
											ON u.iUserID = pl.iUserID
											WHERE pl.iPostID = '$iPostID'
 											ORDER BY pl.iPostLikeID desc
											LIMIT $page,10 ");
			
		if($result->num_rows() > 0) {
			$resultArr = $result->result_array();
			foreach ($resultArr as $key => $value) {
  				$resultArr[$key]['dtCreated'] = date('Y-M-d h:i:s A',strtotime($value['dtCreated']));
				
			}

			$TotalResult = $this->db->query("SELECT  pl.iPostLikeID,
											pl.iUserID,
											u.vFirstName,
											u.vLastName,
											u.vUserName,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL',u.vProfileImage),u.vFacebookImage) as vProfileImage,
											IF(u.vProfileImage != '',CONCAT('$USER_IMAGE_URL_THUMB',u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
											pl.dtCreated
											FROM tbl_post_like pl
											LEFT JOIN tbl_user u
											ON u.iUserID = pl.iUserID
											WHERE pl.iPostID = '$iPostID'
 											ORDER BY pl.iPostLikeID desc
								 			");

     	   	$TotalResultCount = $TotalResult->num_rows();
     	    $returnArr['vData'] = $resultArr;
			$returnArr['iTotalRecords'] = $TotalResultCount;
			$returnArr['iPages'] = ceil($TotalResultCount/10);
		}
		else
		{
			$returnArr['vData'] = array();
			$returnArr['iTotalRecords'] = 0;
			$returnArr['iPages'] = 0;
		}
		return $returnArr;
    }
	
	
	 //Created By : KK on 25-05-2017
    //Created for : Add Like/Dislike.
	public function addLikeDislikeOnPost($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$iPostID = $data['iPostID'];
		
		$insertArr = array(	'iUserID'=>$_SERVER['HTTP_IUSERID'],
							'iPostID'=>$data['iPostID'],
							'dtCreated'=>date('Y-m-d H:i:s')
						   );
 
		// Add like : Make entry in table
		if ($data['action'] == "like" ) {
			// Check for already LIKE
  			$q = $this->db->query("SELECT iPostLikeID FROM tbl_post_like WHERE iPostID = $iPostID AND iUserID = $iUserID");
			// already LIKED
			if($q->num_rows() > 0) { 
				return 0;
			}  
			// not liked before
			else { 
 				if($this->db->insert('tbl_post_like',$insertArr)) {
					$iPostLikeID = $this->db->insert_id();
 					// Fetch data to send notification
					$sel_like = $this->db->query("SELECT 
													u.iUserID,
 													u.iBadgeCount,
													u.vDeviceToken, 
													u.ePlatform, 
													u.eIsNotification,
													p.iUserPostID, 
													(SELECT count(*) as iLikeCount FROM tbl_post_like tpl WHERE tpl.iPostID = $iPostID) as iLikeCount,
													(SELECT uu.vFirstName FROM `tbl_user` uu WHERE uu.`iUserID` = $iUserID) as vFirstName
													FROM tbl_post_like pl JOIN tbl_user u JOIN tbl_user_post p 
													ON  pl.iPostID = $iPostID 
													where 
													pl.iPostID = p.iUserPostID AND 
													p.iUserID = u.iUserID");
 					$userdata = $sel_like->row_array();
   					if(count($userdata)>0) {
 						// Send PUSH Notification @ LIKE only
						$notification_message = $userdata['vFirstName'].PUSH_MESSAGE_LIKE;
						$message_data = array("message" => $notification_message, "type" => "like", "iPostID" => $userdata['iUserPostID'], "iToUserID" => $userdata["iUserID"], "iBadgeCount" =>  $userdata["iBadgeCount"] );
 						if($userdata['ePlatform'] == "android" && $userdata['eIsNotification'] == 1 && ($userdata["iUserID"] != $_SERVER['HTTP_IUSERID'])) {
							$this->general_model->send_push_android_final($userdata['vDeviceToken'], $message_data);
						}						
						elseif($userdata['ePlatform'] == "ios" && $userdata['eIsNotification'] == 1 && ($userdata["iUserID"] != $_SERVER['HTTP_IUSERID'])) {
 							$this->general_model->send_push_ios_final($userdata['vDeviceToken'], $message_data);
						}
 						return array('iLikeCount' => $userdata['iLikeCount']);

 					}	
					else {
						return 0;
					}
 				}
				else {
					return 0;
				}
 			}
 		}	
		// Dislike : Remove entry from table
		elseif ($data['action'] == "dislike")
		{
			$this->db->delete('tbl_post_like',array('iUserID'=>$iUserID,'iPostID'=>$iPostID));
 			if($this->db->affected_rows() > 0){
			// Get latest like count
				$sel_like = $this->db->query("SELECT count(*) as iLikeCount FROM tbl_post_like WHERE iPostID = $iPostID");
				$iLikeCount = $sel_like->row_array();
				if($sel_like->num_rows()>0) {
					//return array('iLikeCount' =>$iLikeCount['iLikeCount']);
					return $iLikeCount;
				}
				else {
					return 0;
				}
					
 			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}	
	}
	
	  
    //Created By : ID on 08-05-2017
    //Created for : Add comment.
	public function addComment($data)
	{
 		$insertArr = array('iUserID'=>$_SERVER['HTTP_IUSERID'],
			'iPostID'=>$data['iUserPostID'],
			'vComment'=>$data['vComment'],
			'dtCreated'=>date('Y-m-d H:i:s'));

		if($this->db->insert('tbl_post_comment',$insertArr))
		{
			$iPostCommentID = $this->db->insert_id();
			
			// --------------------------  Fetch data to send notification -------------------------------
			$sel_like = $this->db->query("SELECT 
											u.iUserID, 
 											u.iBadgeCount, 
											u.vDeviceToken, 
											u.ePlatform,
											u.eIsNotification, 
											p.iUserPostID, 
											(SELECT count(*) as count FROM `tbl_post_comment` tpc WHERE tpc.`iPostID` = '".$data['iUserPostID']."' and tpc.eIsDeleted = 'no') as iCommentCount,
											(SELECT uu.vFirstName FROM `tbl_user` uu WHERE uu.`iUserID` = '".$_SERVER['HTTP_IUSERID']."') as vFirstName
											FROM tbl_post_comment pc JOIN tbl_user u JOIN tbl_user_post p 
											ON  pc.iPostID = '".$data['iUserPostID']."' 
											where 
											pc.iPostID = p.iUserPostID AND  p.iUserID = u.iUserID");
											
			$userdata = $sel_like->row_array();
			
			// Send PUSH Notification @ LIKE only
			$notification_message = $userdata['vFirstName'].PUSH_MESSAGE_COMMENT;
 			$message_data = array("message" => $notification_message, "type" => "comment", "iPostID" => $userdata['iUserPostID'], "iToUserID" => $userdata["iUserID"], "iBadgeCount" =>  $userdata["iBadgeCount"] );
			
 			if($userdata['ePlatform'] == "android" && $userdata['eIsNotification'] == 1 && ($userdata["iUserID"] != $_SERVER['HTTP_IUSERID'])) {
				
				$this->general_model->send_push_android_final($userdata['vDeviceToken'], $message_data);
 			}						
			elseif($userdata['ePlatform'] == "ios" && $userdata['eIsNotification'] == 1 && ($userdata["iUserID"] != $_SERVER['HTTP_IUSERID']) ) {
				$this->general_model->send_push_ios_final($userdata['vDeviceToken'], $message_data);
 			}
			//return array('iLikeCount' => $userdata['iLikeCount']);
			 
			// ------------------------------------------------------------------
			
			$Result = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
			//$dtCreated = $this->getDuration(date('Y-m-d H:i:s'),$insertArr['dtCreated']);
			$dtCreated = date('Y-M-d h:i:s A',strtotime($insertArr['dtCreated']));
			
 			/*$comment_qry = $this->db->query("SELECT count(*) as count FROM `tbl_post_comment` WHERE `iPostID` = '".$data['iUserPostID']."' and  eIsDeleted = 'no' ");
			$iCommentCount = $comment_qry->row_array();*/
   
   
			return array('iPostCommentID'=>"$iPostCommentID",
				'iUserID'=>$_SERVER['HTTP_IUSERID'],
				'iUserPostID'=>$data['iUserPostID'],
				'vComment'=>$data['vComment'],
				'vProfileImage'=>$Result['vProfileImage'],
				'vProfileImageThumb'=>$Result['vProfileImageThumb'],
				'vFirstName'=>$Result['vFirstName'],
				'vLastName'=>$Result['vLastName'],
				'vUserName'=>$Result['vUserName'],
				'iCommentCount'=>$userdata['iCommentCount'],
				'dtCreated'=>$dtCreated);
		}
		else
		{
			return 0;
		}
	}

	//Created By : ID on 08-05-2017
    //Created for : Edit comment.
	public function editComment($data)
	{
		$updateArr = array('vComment'=>$data['vComment']);

		if($this->db->update('tbl_post_comment',$updateArr,array('iPostCommentID'=>$data['iPostCommentID'])))
		{
			$iPostCommentID = $data['iPostCommentID'];
			$PostCommentResult = $this->db->select('iPostCommentID,iUserID,iPostID,vComment,dtCreated')->get_where('tbl_post_comment',array('iPostCommentID'=>$data['iPostCommentID']))->row_array();
			$Result = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
  			$dtCreated = date('Y-M-d h:i:s A',strtotime($PostCommentResult['dtCreated']));
			
			return array('iPostCommentID'=>$iPostCommentID,
				'iUserID'=>$_SERVER['HTTP_IUSERID'],
				'iUserPostID'=>$PostCommentResult['iPostID'],
				'vComment'=>$PostCommentResult['vComment'],
				'vProfileImage'=>$Result['vProfileImage'],
				'vProfileImageThumb'=>$Result['vProfileImageThumb'],
				'dtCreated'=>$dtCreated);
		}
		else
		{
			return 0;
		}
	}

	//Created By :ID on 08-05-2017
    //Created for : Remove comment	
	public function removeComment($data)
	{
	
	if($this->db->update('tbl_post_comment',array('eIsDeleted'=>'yes'),array('iPostCommentID'=>$data['iPostCommentID'])))
		{ 			
    			$comment_qry = $this->db->query("SELECT count(*) as count FROM `tbl_post_comment` WHERE `iPostID` IN (SELECT iPostID FROM `tbl_post_comment` WHERE `iPostCommentID` = '".$data['iPostCommentID']."') and  eIsDeleted = 'no' ");
				$iCommentCount = $comment_qry->row_array();
				$returnArr['iCommentCount'] = $iCommentCount['count'];
				return $returnArr;
		}
		else
		{
			return 0;
		}
		
		if($this->db->update('tbl_post_comment',array('eIsDeleted'=>'yes'),array('iPostCommentID'=>$data['iPostCommentID'])))
		{
		
 			$iPostCommentID = $data['iPostCommentID'];
			$Result = $this->getuserprofilebyid($_SERVER['HTTP_IUSERID']);
			$dtCreated = date('Y-M-d h:i:s A',strtotime($insertArr['dtCreated']));
 
			return array('iPostCommentID'=>"$iPostCommentID",
						'iUserID'=>$_SERVER['HTTP_IUSERID'],
						'iUserPostID'=>$data['iUserPostID'],
						'vComment'=>$data['vComment'],
						'vProfileImage'=>$Result['vProfileImage'],
						'vProfileImageThumb'=>$Result['vProfileImageThumb'],
						'dtCreated'=>$dtCreated);
 		}
		else
		{
			return 0;
		}
	}
	

     //Created By :ID on 21-02-2017
    //Created for : Get Static Pages
    public function getStaticPages($data)
    {
    	$this->db->select('tp.id,tp.title,tp.description');
    	$result=$this->db->get_where('tbl_page tp',array('tp.id'=>$data['id']));
    	if($result->num_rows>0)
    	{
    		$resultArr=$result->result_array();
    		return $resultArr;
    	}
    	else
    	{
    		return array();
    	}
    }

    //Created By : ID on 06-04-2017
    //Created for : Submit contactus detail.
	public function submitContactusDetail($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$this->db->insert('tbl_contact_us',array('iFromUserID'=>$iUserID,
						'vSubject'=>$data['vSubject'],
						'vComment'=>$data['vComment'],
						'dtCreated'=>date('Y-m-d H:i:s')));
		if($this->db->affected_rows()>0)
		{
			return 1;
		}
		else
		{
			return 0;
		}		
	}

    
    //Created By : ID on 17-02-2017
    //Created for : Test Notification
    public function TestNotifica($token) {
    	$msg = array(
 	            'message' => 'Test Notificaiton - By Krupal Patel',
	            'title' => 'TradesUnite',
	            'type' => 'Test'
 	        );
		// dc4a4aa74e39360b142d49adae1d8429f914dd828d676d1fe5a8fdf2f7ae63bc	
    	$this->general_model->send_ios_core($token,$msg,0);
    	//$this->general_model->send_android($token,$msg,0);
    }


    //Created By : ID on 12-09-2016
    //Created for : Update Badge 
	public function updateBadge() 
	{
		$this->db->update('tbl_user',array('iBadgeCount'=>0),array('iUserID'=>$_SERVER['HTTP_IUSERID']));
		return 1;
	}
	
	
	 //Created By : KK on 12-09-2016
    //Created for : To make entry for in-app purchase for Logbook (One time) 
	public function purchaseLogbook($purchaseData) 
	{
 		$this->db->update('tbl_user',$purchaseData,array('iUserID'=>$_SERVER['HTTP_IUSERID']));
		return 1;
	}
	
	 
	public function updatePass() 
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
 		
		$result = $this->db->query("SELECT iUserID, vPassword, vPassword_plain from tbl_user");		
		$userdata = $result->result_array();
		
		foreach($userdata as $key=>$value) {
  			echo $password_plain  =  $value['vPassword'];
			
			$password_base = base64_encode($value['vPassword']);
 			
			$options = [
				'cost' => 11,
				'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM)
			];
			
			$password_hash = password_hash($value['vPassword_plain'], PASSWORD_BCRYPT, $options);
  
 			$this->db->update('tbl_user',array('vPassword_Hash'=>$password_hash),array('iUserID'=>$value['iUserID']));
			//echo $tghis->db->last_query();
 		}  		
  		 
	}
	
	// Fetch Security Token
	public function verifyUseToken($id, $token)
    {
      	$this->db->select('iUserID,vUserSecretToken');
    	$result=$this->db->get_where('tbl_user',array('iUserID'=>base64_decode($id), 'vUserSecretToken'=>$token));
  		return $result->num_rows;
    }
	
	
	// Update Security Token
	public function updateUserToken($updatedata,$id)
    {
 		$this->db->set($updatedata);
		$this->db->where('iUserID', base64_decode($id));
		$result = $this->db->update('tbl_user');
 
		// Send Mail @ Change Password Successfully
		if($this->db->affected_rows()>0) {
					
         	$this->load->library('email');
			
			// Get User Email
			$this->db->select('vEmail');
			$result=$this->db->get_where('tbl_user',array('iUserID'=>base64_decode($id)));
			$user_result = $result->row_array();
         	 
			// Update token in to User record
			$data = array(
				'email' => $user_result['vEmail'],
				'from' => SUPPORT_EMAIL_ADDRESS,
 				);
			$this->load->view('email/password_change_success', $data);
			return 1;
 		}
		else {
				return 0;
		}	
        	 
  		return $result->affected_rows;
    }
	
	
	// To fetch Notification - 25 Per page
	public function getNotificationList($data)
    {
		$recordsPerPage = 25;
 		$iUserID = $_SERVER['HTTP_IUSERID'];
		
 		if($data['page']==1 || $data['page']<=0) {
    		$page=0;
    	}
    	else {
    		$page=($data['page']*$recordsPerPage)-$recordsPerPage;
    	}
		
		
		//$USER_IMAGE_URL = USER_IMAGE_URL;
		$USER_IMAGE_URL_THUMB = USER_IMAGE_URL_THUMB;
		//IF(u.vProfileImage != "",CONCAT("'.$USER_IMAGE_URL.'",u.vProfileImage),u.vFacebookImage) as vProfileImage,															
 
		$this->db->select('n.iReferenceID as iUserPostID, 
 							IF(u.vProfileImage != "",CONCAT("'.$USER_IMAGE_URL_THUMB.'",u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
							DATE_FORMAT(n.dtCreated,"%Y-%b-%d %h:%i:%s %p") as dtCreated, 
							CONCAT(u.vFirstName, if(n.eNotificationType="like", " liked your post" , " commented on your post")) as notification_string',False
						 );
							
		$this->db->from('tbl_notification n');
		$this->db->join('tbl_user u', 'n.iFromID = u.iUserID');
		$this->db->where('n.iToUserID', $iUserID);
		$this->db->order_by('n.dtCreated', "desc"); 
		$this->db->limit($recordsPerPage,$page);
 
		$result= $this->db->get();
 		//echo $this->db->last_query(); exit;
 
    	if($result->num_rows>0) {
			$notification_result['vData'] = $result->result_array();
			
	
			// ----------------------- To get Total count, without limit --------------------------------------------
			$this->db->select('n.iReferenceID as iUserPostID, 
 							IF(u.vProfileImage != "",CONCAT("'.$USER_IMAGE_URL_THUMB.'",u.vProfileImage),u.vFacebookImage) as vProfileImageThumb,
							DATE_FORMAT(n.dtCreated,"%Y-%b-%d %h:%i:%s %p") as dtCreated, 
							CONCAT(u.vFirstName, if(n.eNotificationType="like", " liked your post" , " commented on your post")) as notification_string',False
						 );
 			$this->db->from('tbl_notification n');
			$this->db->join('tbl_user u', 'n.iFromID = u.iUserID');
			$this->db->where('n.iToUserID', $iUserID);
 			$result_data= $this->db->get();
  
			$notification_result['iTotalRecords'] = $result_data->num_rows;
			// ------------------------------------------------------------------
			$notification_result['iPages'] = ceil($result->num_rows/$recordsPerPage);
    	}
    	else {
			$notification_result['vData'] = array();
			$notification_result['iTotalRecords'] = 0;
			$notification_result['iPages'] = 0;
    	}
		
		return $notification_result;
    }
	
	
	//Created By : KK on 08-05-2017
    //Created for : Add comment.
	public function report_post($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
 		$insertArr = array('iUserID'=>$iUserID,
							'iUserPostID'=>$data['iUserPostID'],
							'dtCreated'=>date('Y-m-d H:i:s')
						);
 			
		$this->db->select('*');
    	$result=$this->db->get_where('tbl_reported_post',array('iUserID'=>$iUserID, 'iUserPostID'=>$data['iUserPostID']));
		if($result->num_rows == 0) {
			if($this->db->insert('tbl_reported_post',$insertArr)) {
  				return 1;
			}
			else {
				return 2;
			}
		}
		else {
				return 3;
			}
 	} 	
	
	
	
	// Get Job Package List
	public function getJobPackage()
    {
 		$this->db->select('iJobPackageID,vPackageTitle,iJobCount,vPurchaseAmount,vPackageCurrency');
		$this->db->from('tbl_job_package');
		$result = $this->db->get();
		$result_data = $result->result_array();
 		return $result_data;
    }
	
	
    //Created By : KK on 08-05-2017
    //Created for : Purchase Logbook
	public function purchase_job($data)
	{
		$iUserID = $_SERVER['HTTP_IUSERID'];
 		$insertArr = array('iUserID'=>$iUserID,
							'vPackageTitle'=>$data['vPackageTitle'],
							'iJobCount'=>$data['iJobCount'],
							'vPackageAmount'=>$data['vPackageAmount'],
							'vPackageCurrency'=>$data['vPackageCurrency'],
							'tJobPurchaseReceipt'=>$data['tJobPurchaseReceipt'],
							'eJobPurchasePlatform'=>$data['eJobPurchasePlatform'],
 							'tJobPurchasedDatetime'=>$data['tJobPurchasedDatetime']
						);
 		
		if($this->db->insert('tbl_job_purchase_history',$insertArr)) {
			// Update post count if catid = 3 = job
			 $this->db->where('iUserID', $iUserID);
			 $this->db->set('jobPurchasedCount', "jobPurchasedCount+".$data['iJobCount']."", FALSE);
			 $this->db->update('tbl_user');
			 
			$jobPost_data = $this->db->select('jobPostCount, jobPurchasedCount')->get_where('tbl_user',array('iUserID' => $_SERVER['HTTP_IUSERID']))->row_array();			
			$jobPostRemainingCount =$jobPost_data['jobPurchasedCount'] - $jobPost_data['jobPostCount'];
  			$data_result['jobPostRemainingCount'] = $jobPostRemainingCount;
			return $data_result;
		}
		else {
			return 0;
		}
  	} 	
	 
}
?>