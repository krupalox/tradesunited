<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class General_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('encrypt');
	}
	function count_age($user_id)
	{
		$q = $this->db->query("SELECT date_of_birth FROM tbl_user WHERE id = $user_id ");
		if($q->num_rows() > 0) {
			$d = $q->row_array();
			$current_date = date('Y-m-d');
			$dob = $d['date_of_birth'];
			if($dob != '0000-00-00') {
				$date_diff = date_diff(date_create($dob),date_create($current_date))->y;
				$age = $date_diff;
				return $age;
			} else {
				return '';
			}
		} else {
			return '';
		}
	}
	function count_post_time($posted_date)
	{
		//echo $posted_date; exit;
		date_default_timezone_set('Asia/Kolkata');
		$time_one = new DateTime($posted_date);


		$KEY=$_SERVER['HTTP_X_API_KEY'];
        $ip=$_SERVER['REMOTE_ADDR'] ;

        $json = file_get_contents("http://ipinfo.io/".$ip."?token=".$KEY);
        $data = json_decode($json,TRUE);

        $loc=explode(',', $data['loc']);
        $dLat=$loc[0];
        $dLong=$loc[1];
        $uname=GEO_USERNAME;

        $json = file_get_contents("http://api.geonames.org/timezoneJSON?lat=".$dLat."&lng=".$dLong."&username=".$uname);
        $data = json_decode($json,TRUE);
        $date=date('Y-m-d H:i:s',strtotime($data['time']));
        //echo $date; exit;
		$time_two = new DateTime($date);
		$interval = $time_one->diff($time_two);
		
		// echo "<pre>";
		// print_r($interval);
		// exit;
		
		//$difference = $time_one->diff($time_two);
		//echo "<pre>"; print_r($difference); exit;
		//return $difference->format('%a days %h hours %i minutes');
		// return $d = "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days " . $interval->h." hour " . $interval->i." minuts " . $interval->s ." seconnd "; 
		//return $difference['weekday'] . "week ago";

		if($interval->y >= 1) 
		{
			return $interval->y." Year ago";
		}
		else if(($interval->m >= 1) && ($interval->y<=0))
		{
			return $interval->m." Month ago";
		}
		else if (($interval->d >= 7) && ($interval->d <= 13) &&($interval->m<=0) && ($interval->y<=0)) 
		{
			return "1 week ago";
		}
		else if (($interval->d >= 14) && ($interval->d <= 21) &&($interval->m<=0) && ($interval->y<=0)) 
		{
			return "3 week ago";
		}
		else if (($interval->d >= 22) && ($interval->d <= 30) &&($interval->m<=0) && ($interval->y<=0))
		{
			return "4 week ago";
		}
		else if (($interval->y <= 0) && ($interval->m<=0) && ($interval->d >=1) && ($interval->d <=6)) 
		{
			return $interval->d." Day ago";
		}
		else if (($interval->y <= 0) && ($interval->m<=0) && ($interval->d <=0) && ($interval->h >=1)) 
		{
			return $interval->h." Hour ago";
		}
		else if (($interval->y <= 0) && ($interval->m<=0) && ($interval->d <= 0) && ($interval->h <= 0) && ($interval->i >= 1)) 
		{
			return $interval->i." Minute ago";
		}
		else if (($interval->y <= 0) && ($interval->m<=0) && ($interval->d <= 0) && ($interval->h <= 0) && ($interval->i <= 0) && ($interval->s >= 1)) 
		{
			return $interval->s." Seconds ago";

		}else if(($interval->y <= 0) && ($interval->m<=0) && ($interval->d <= 0) && ($interval->h <= 0) && ($interval->i <= 0) && ($interval->s <= 0)){
			return "Just now";
		}
	}

	function send_push_android($id, $message) {
	
 		$url = 'https://fcm.googleapis.com/fcm/send';
 		$fields = array (
				'registration_ids' => array (
						$id
				),
				'data' => array (
						"message" => $message
				)
		);
		$fields = json_encode ( $fields );
	
		$headers = array (
				'Authorization: key=' . FCM_API_KEY,
				'Content-Type: application/json'
		);
	
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_POST, true );
		curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );
	
		$result = curl_exec ( $ch );
		curl_close ( $ch );
	}


	function send_ios_core($deviceToken,$extra,$totalBadge=0)
	{
			//$totalBadge = $this->user_model->totalBadgeForIos($iUserID);
			$totalBadge=$totalBadge+1;
			$pem = '../pushcert_dev.pem';
			//$pem = '../APNS_Production.pem';
			//$pem = '../APNS_Development.pem';
			//$deviceToken = $_REQUEST['deviceToken'];
			//$badge = (int) $_GET['badge'] or $badge = (int) $argv[2];]
			//  if($iSilent =='1')
			// {
			// $sound = 'default';
			// }
			// else{
			// $sound ='';
			// }
			//$badge = $totalBadge['isSeen'];
			//$sound = $_GET['sound'] or $sound = $argv[3];
			$sound = 'default';
			$body = array();
			$body['aps'] = array('alert' => $extra['message'],'message'=>$extra,'badge'=>$totalBadge,'sound'=>$sound);

			//$body['aps']['badge'] = 1;
			$ctx = stream_context_create();
			stream_context_set_option($ctx, 'ssl', 'local_cert', $pem);
			$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);
			//$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);

		if (!$fp) {
			$data['msgs'] = "Failed to connect $err $errstr \n";
			$data['success'] = '0';
			return FALSE;
		} 
		else 
		{
			$notLogArr = array(
				'iNotificationFrom' => $_SERVER['HTTP_IUSERID'],
				//'iNotificationTo' => $extra['receverUserID'],
				'eType' => $extra['type'],
 				'eIsDeleted' =>'no',
				'eStatus' =>'Active',
				'dtCreated' =>date('Y-m-d H:i:s'),
				'dtModified'=>date('Y-m-d H:i:s')
				);

			/*if($extra['type'] == 'Group')
			{
				$notLogArr['iReferenceID'] = $extra['iGroupID'];
			}
			else if($extra['type'] == 'Friend')
			{
				$notLogArr['iReferenceID'] = $extra['iFrienID'];
			}
			else
			{
				$notLogArr['iReferenceID'] = $extra['iEventID'];
			}*/

			//mprd($notLogArr);

			
			//$this->db->update('tbl_user',array('iBadgeCount'=>$totalBadge),array('iUserID'=>$extra['receiver_user_id']));
			//$this->db->insert('tbl_notification',$notLogArr);
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n", strlen($payload)) . $payload;
			$data['msgs'] = "Notification sent succesfully.";
			$data['success'] = '1';
			$return = fwrite($fp, $msg);
			
			fclose($fp);
			return 1;
		}
	}

	public function getCurrentUser(){
		$user=$this->db->select('id,full_name,profile_image,user_rank,facebook_image,badge')->get_where('tbl_user',array('id'=>$_SERVER['HTTP_IUSERID']))->result_array()[0];
		return $user;
	}

	public function getUserDetailByID($id){
		$user=$this->db->select('id,full_name,profile_image,notification,device_type,device_token,badge,user_rank,badge')->get_where('tbl_user',array('id'=>$id))->result_array()[0];
		return $user;
	}
	
	
	public function convert_password_hash($password) {
	
		$options = [
					'cost' => 11,
					'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM)
				];
  		return password_hash($password, PASSWORD_BCRYPT, $options);
	}
	
	public function verify_password_hash($password, $hash){
		if(password_verify($password, $hash)) {
			return 1; // VALID
		} else {
			return 0; // INVALID
		}	
	}
	
	/*function generate_UserSecretToken( $length ) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";	
 		$size = strlen( $chars );
		$str = "";
		for( $i = 0; $i < $length; $i++ ) {
			$str .= $chars[ rand( 0, $size - 1 ) ];
		}
 		return $str;
	}*/			


	/* To send PUSH notification */
 	function send_push_android_final($id, $message_data, $totalBadge=0) {
		
		$totalBadge = $message_data['iBadgeCount']+1;

		$url = 'https://fcm.googleapis.com/fcm/send';
 		$fields = array (
				'registration_ids' => array (
						$id
				),
				'data' => array (
						"message" => $message_data
				)
		);
		$fields = json_encode ( $fields );
	
		$headers = array (
				'Authorization: key=' . FCM_API_KEY,
				'Content-Type: application/json'
		);
	
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_POST, true );
		curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );
 		
		$result = curl_exec ( $ch );
		curl_close ( $ch );
		
		// Notificaiton list will have Only ebntries for Like + Comment
		if($message_data['type'] != "reminder") {
			$notLogArr = array(
						'iFromID' => $_SERVER['HTTP_IUSERID'],
						'iToUserID' => $message_data['iToUserID'],
						'iReferenceID' => $message_data['iPostID'],
						'eNotificationType' => $message_data['type'],
						'dtCreated' =>date('Y-m-d H:i:s'),
						'dtModified'=>date('Y-m-d H:i:s')
					);
			// Update badge count			
			$this->db->update('tbl_user',array('iBadgeCount'=>$totalBadge),array('iUserID'=>$notLogArr['iToUserID']));
			// Insert records in Notificiton table 
			$this->db->insert('tbl_notification',$notLogArr);
		}
		
		return 1;
 			
	}


	function send_push_ios_final($deviceToken,$message_data,$totalBadge=0)
	{ 			
 		
		// Badge count will not be update for "Reminder"
		if($message_data['type']=="reminder") {		
			$totalBadge = $message_data['iBadgeCount'];
		}
		else {
			$totalBadge = $message_data['iBadgeCount']+1;
		}
			
		$pem = '../pushcert_dev.pem';
		//$pem = '../APNS_Production.pem';
		//$pem = '../APNS_Development.pem';
		//$deviceToken = $_REQUEST['deviceToken'];
		//$badge = (int) $_GET['badge'] or $badge = (int) $argv[2];]
		//  if($iSilent =='1')
		// {
		// $sound = 'default';
		// }
		// else{
		// $sound ='';
		// }
		//$badge = $totalBadge['isSeen'];
		//$sound = $_GET['sound'] or $sound = $argv[3];
		$sound = 'default';
		$body = array();
 		
		$body['aps'] = array('alert' => $message_data['message'],'message'=>$message_data,'badge'=>$totalBadge,'sound'=>$sound);
 		
		//$body['aps']['badge'] = 1;
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert', $pem);
		$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT, $ctx);
 
		if (!$fp) {
			$data['msgs'] = "Failed to connect $err $errstr \n";
			$data['success'] = '0';
			return FALSE;
		} 
		else 
		{
			// Notificaiton list will have Only ebntries for Like + Comment
			if($message_data['type'] != "reminder") {
				$notLogArr = array(
									'iFromID' => $_SERVER['HTTP_IUSERID'],
									'iToUserID' => $message_data['iToUserID'],
									'iReferenceID' => $message_data['iPostID'],
									'eNotificationType' => $message_data['type'],
									'dtCreated' =>date('Y-m-d H:i:s'),
									'dtModified'=>date('Y-m-d H:i:s')
								);
				// Update badge count			
				$this->db->update('tbl_user',array('iBadgeCount'=>$totalBadge),array('iUserID'=>$notLogArr['iToUserID']));
				// Insert records in Notificiton table 
				$this->db->insert('tbl_notification',$notLogArr);
			}	
			
			$payload = json_encode($body);
			$msg = chr(0) . pack("n", 32) . pack('H*', str_replace(' ', '', $deviceToken)) . pack("n", strlen($payload)) . $payload;
			$data['msgs'] = "Notification sent succesfully.";
			$data['success'] = '1';
			$return = fwrite($fp, $msg);
			
			fclose($fp);
			return 1;
		}		
	}
}
?>