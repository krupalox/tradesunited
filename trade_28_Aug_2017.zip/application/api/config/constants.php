<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
define('APP_NAME', 'tradesunite');
define('FOPEN_READ', 'rb');
define('FOPEN_READ_WRITE', 'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 'ab');
define('FOPEN_READ_WRITE_CREATE', 'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

define('_PATH', substr(dirname(__FILE__),0,-25));
define('_URL', substr($_SERVER['PHP_SELF'], 0, - (strlen($_SERVER['SCRIPT_FILENAME']) - strlen(_PATH))));
define('SITE_PATH', _PATH."/");
define('SITE_URL', _URL."/");
define('WEBSITE_URL', SITE_URL.'/');
define('DOMAIN_URL', 'http://'.$_SERVER['SERVER_NAME'].'/tradesunite/');
define('DOMAIN_URL_IMG', 'http://'.$_SERVER['SERVER_NAME']);
//define('DOC_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/'.APP_NAME.'/admin/');
define('DOC_ROOT', $_SERVER['DOCUMENT_ROOT'] .'/'.APP_NAME.'/images/');
define('BASEURL',DOMAIN_URL.'/ws/');
define('gmapkey','');
define('MAINTITLE','Vipi');
define('SITEURL','http://'.$_SERVER['SERVER_NAME'].'/tradesunite/api/');



/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
define('EXIT_SUCCESS', 0); // no errors
define('EXIT_ERROR', 1); // generic error
define('EXIT_CONFIG', 3); // configuration error
define('EXIT_UNKNOWN_FILE', 4); // file not found
define('EXIT_UNKNOWN_CLASS', 5); // unknown class
define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
define('EXIT_USER_INPUT', 7); // invalid user input
define('EXIT_DATABASE', 8); // database error
define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code



//-----------------------------User Image-----------------------------------------
//Created By : Ila Darji on 23-01-2017
//Created For : Path For User Image Upload

define('USER_IMAGE_PATH', DOC_ROOT . "user/");
define('USER_IMAGE_PATH_THUMB', DOC_ROOT . "user/thumb/");

define('EXPENSE_IMAGE_PATH', DOC_ROOT . "userExpense/");
define('EXPENSE_IMAGE_PATH_THUMB', DOC_ROOT . "userExpense/thumb/"); 

define('LOGBOOK_CSV_PATH', DOC_ROOT . "userLogbook/"); 
define('LOGBOOK_CSV_URL', DOMAIN_URL . "images/userLogbook/"); 

define('EXPENSE_CSV_PATH', DOC_ROOT . "userExpenseReport/"); 
define('EXPENSE_CSV_URL', DOMAIN_URL . "images/userExpenseReport/"); 


define('POST_IMAGE_PATH', DOC_ROOT . "userPosts/");
define('POST_IMAGE_PATH_THUMB', DOC_ROOT . "userPosts/thumb/");  

define('REMINDER_IMAGE_PATH', DOC_ROOT . "userReminder/");
define('REMINDER_IMAGE_PATH_THUMB', DOC_ROOT . "userReminder/thumb/"); 

define('REMINDER_IMAGE_URL', DOMAIN_URL . "images/userReminder/");
define('REMINDER_IMAGE_URL_THUMB', DOMAIN_URL . "images/userReminder/thumb/");
define('REMINDER_NO_IMAGE_URL', DOMAIN_URL . "images/userReminder/No_image.png");

define('POST_IMAGE_URL', DOMAIN_URL . "images/userPosts/"); 
define('POST_IMAGE_URL_THUMB', DOMAIN_URL . "images/userPosts/thumb/");
define('POST_IMAGE_NO_URL_THUMB', DOMAIN_URL . "images/userPosts/No_image.png");

define('EXPENSE_IMAGE_URL', DOMAIN_URL . "images/userExpense/");
define('EXPENSE_IMAGE_URL_THUMB', DOMAIN_URL . "images/userExpense/thumb/");
define('EXPENSE_NO_IMAGE_URL', DOMAIN_URL . "images/userExpense/No_image.png");

define('USER_IMAGE_URL', DOMAIN_URL . "images/user/");
define('USER_IMAGE_URL_THUMB', DOMAIN_URL . "images/user/thumb/");
define('USER_NO_IMAGE_URL', DOMAIN_URL . "images/user/No_image.png");

//------------------------------- WS Message ---------------------------------------------
//URL > /User/addExpenseReminder
define('REMINDER_ADDED_SUCCESSFULLY', 'Reminder added successfully');
//URL > /User/editExpenseReminder
define('REMINDER_SAVED_SUCCESSFULLY', 'Reminder saved successfully');
//URL > /User/addUserExpense
define('EXPENSE_ADDED_SUCCESSFULLY', 'Expense added successfully');
//URL > /User/editExpenseDetail
define('EXPENSE_SAVED_SUCCESSFULLY', 'Expense saved successfully');

//URL > /User/addPost
define('POST_ADDED_SUCCESSFULLY', 'Post added successfully');
//URL > /User/editPost
define('POST_SAVED_SUCCESSFULLY', 'Post saved successfully');
//removePostByPostID
define('POST_DELETED_SUCCESSFULLY', 'Post deleted successfully');
//URL > /User/addComment
define('COMMENT_ADDED_SUCCESSFULLY', 'Comment added successfully');
//URL > /User/removeComment
define('COMMENT_DELETED_SUCCESSFULLY', 'Comment deleted successfully');

//URL > /User/submitContactusDetail
define('FEEDBACK_SUCCESSFULLY', 'Your feedback has been recorded successfully');


define('FCM_API_KEY', 'AIzaSyB3MOtMKFxqZK5Or3B2M_7iO-Z3tym5O3g');

/* Notification TEXT */
define('PUSH_MESSAGE_LIKE', ' has recently liked your post.');
define('PUSH_MESSAGE_COMMENT', ' has recently commented on your post.');
define('PUSH_MESSAGE_NOTIFICATION', 'You have got scheduled reminder');


// ----------------------------------------------------------------------------------------

/*Site Path and Urls*/
/*Admin Site Path and Urls*/
/*USERNAME FOR http://api.geonames.org/timezoneJSON*/
define('GEO_USERNAME', "iladarji");
define('SUPPORT_EMAIL_ADDRESS', 'support@tradeunite.com');
define('CONTACT_EMAIL_ADDRESS', 'info@tradesunite.com');
 