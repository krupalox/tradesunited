<?php
class Forgot_password extends CI_Controller
{ 	
	var $viewData = array();
	function __construct() 
	{
		 parent::__construct();     
		 $this->load->model('user_model');
		 $this->load->library('session');

	}
	
	function index($check='')
	{	
		 redirect("forgot_password/reset_pass_success"); 
	}
	
	function activate($id="" ,$token="")
    { 	
		// Verify User Token 
 		$isverify = $this->user_model->verifyUseToken($id, $token);
 		// If verify, proceed
		if($isverify == 1 ){
			  $data   =   array(
                'id'    =>  $id,
                'token'    =>  $token,
                'title' =>  'Reset Password',
				'isverify' => $isverify
            );
		}
		// Token Expire
		else {
			 $data   =   array(
				'isverify' => $isverify,
                'title' =>  'Reset Password'
            );
		}
		$this->load->view('email/Reset_password_view',$data);        
    }
		

    function reset_pass()
    {
         $id = $this->input->post('id');
  		 // If button pressed, Both typed password are same
         if($this->input->post('vSignup') != "" && ($this->input->post('vPassword') == $this->input->post('vRePassword') )) {
         	//$password = base64_encode($this->input->post('vPassword'));
			$password = $this->general_model->convert_password_hash($this->input->post('vPassword'));			
 			
			// Update New password with hash and remove old token
 			$updatedata = array(
 					'vPassword' => $password,
					'vUserSecretToken' => ""
			);
 			$update_status = $this->user_model->updateUserToken($updatedata, $id);			
     
     		$this->session->set_flashdata('success','Your Password Changed successfully.');
			//redirect(SITEURL.'Forgot_password/resert_pass_success/'.base64_encode($id));	
			redirect(SITEURL.'Forgot_password/reset_pass_success/');	
        }
        else {
        	$this->session->set_flashdata('error','Can not Change Your Password! Please try again.');
        	//redirect(SITEURL.'Forgot_password/reset_pass_success/'.base64_encode($id));
        	redirect(SITEURL.'Forgot_password/reset_pass_success/');
        }
    }
	
	
	function reset_pass_success($id="" ,$token="")
    { 	
  		// If verify, proceed
		$data   =   array(
			'id'    =>  $id,
 			'title' =>  'Reset Password',
			'isverify' => 2
		);
	 
		$this->load->view('email/Reset_password_view',$data);        
    }
}