<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
	
class Cron extends CI_Controller {
    function __construct() {
        parent::__construct();
		$this->load->model('user_model');
    }
    
    function getExpenceReminderNotification(){
        $data = $this->user_model->getExpenceReminderNotification();
        echo "<pre>";
		print_r($data);
		echo "<pre>";
    }
	
	function send_push_android() {
 		
		$id =  'c5TliZMuhkA:APA91bEiU5su-GqGbbM_XtS77BmGmeSs00T3RRGUMjAC9qjWnuNK64UgUTrJOh4-SsoModdGoqSexvXToR_87P2QzjGKbIH5OO3-BdYH0qh2hb1W9o_1oOsfRUDlBmgUUe4sUj9z1_9m';
		$message = "Test by KRUPAL";
		
 		$url = 'https://fcm.googleapis.com/fcm/send';
 		$fields = array (
				'registration_ids' => array (
						$id
				),
				'data' => array (
						"message" => $message
				)
		);
		$fields = json_encode ( $fields );
	
		$headers = array (
				'Authorization: key=' . FCM_API_KEY,
				'Content-Type: application/json'
		);
	
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_POST, true );
		curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );
	
		$result = curl_exec ( $ch );
		curl_close ( $ch );
	
	}
    
}
