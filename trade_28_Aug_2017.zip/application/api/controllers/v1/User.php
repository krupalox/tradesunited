<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// require APPPATH . '/libraries/REST_Controller.php';

require(APPPATH.'/libraries/REST_Controller.php');

class User extends REST_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $uri=$this->uri->segment(3);
        if($uri!="user_registration" && $uri != "getStaticPages" && $uri != "getTradeList" &&  $uri != "TestNotifica" )
        {
            if (!checkmac())
            {
                $row = array("MESSAGE"=>"You are not authorize to use this service","STATUS_CODE" =>203);
                $this->response($row, 401);
            }

        }
        $this->load->model('user_model');
    }

    //Created By : ID on 05-04-2017
    //Created for : User Registration API
    function user_registration_post()
    {
        $postData = $this->post();
        extract($postData);
        //$this->response($postData, 200);
        if (checkparams($postData,array('vUserName','vFirstName','vLastName','vEmail','vPassword','vAddress','iPhoneNumber','vDetail','iTradeID','ePlatform','vDeviceToken'),array('vProfilePic','dLat','dLong')))
        {
            if($vFirstName == '')
            {
                $this->send_fail('Please provide First name.');
            }
			
			if($vLastName == '')
            {
                $this->send_fail('Please provide Last name.');
            }
			
			if($vUserName == '')
            {
                $this->send_fail('Please provide Username.');
            }			
			
            
            if($vEmail == '') 
            {
                $this->send_fail('Please provide email.');
            }

            if($vPassword == '') 
            {
                $this->send_fail('Please provide password.');
            }
            else
            {
                //$postData['vPassword'] = base64_encode($vPassword);
				// Convert Password using hash
   				$postData['vPassword'] = $this->general_model->convert_password_hash($vPassword);
             }

            if($vAddress == '')
            {
                 $this->send_fail('Please provide device token.');
            }

            if($iPhoneNumber == '')
            {
                 $this->send_fail('Please provide Phone number.');
            }

            if($vDetail == '')
            {
                 $this->send_fail('Please provide Detail.');
            }

            if($iTradeID == '')
            {
                 $this->send_fail('Please provide Trade id.');
            }

            if($ePlatform == '')
            {
                 $this->send_fail('Please provide platform.');
            }

            if($vDeviceToken == '')
            {
                 $this->send_fail('Please provide platform.');
            }

            $check_email = $this->user_model->check_email($postData['vEmail']);

            if($check_email == 1) {
                     $this->send_fail('Email is already registered');
            }
            else 
            {
                //------------Add user Profile Image-------------------
                if(isset($_FILES['vProfilePic']) && !empty($_FILES))
                {
                    $configImage['upload_path'] = USER_IMAGE_PATH;
                    $configImage['allowed_types'] = '*';
                    $configImage['max_size']  = '5120';
                    $this->load->library('upload', $configImage);
                    $this->load->library('image_lib');
                    $files = $_FILES['vProfilePic'];
                    
                        $_FILES['vProfilePic']['name'] = str_replace('&', '_', $files['name']);
                        $_FILES['vProfilePic']['name'] = str_replace(' ', '_', $files['name']);
                        $_FILES['vProfilePic']['tmp_name']= $files['tmp_name'];
                        $_FILES['vProfilePic']['error']= $files['error'];
                        $_FILES['vProfilePic']['size']= $files['size'];
                        $ext = explode('.',$_FILES['vProfilePic']['name']);
                        $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vProfilePic']['name'], PATHINFO_EXTENSION);
                        $configImage['file_name'] = $image_name;
                        $this->upload->initialize($configImage);
                        
                        if (!$this->upload->do_upload('vProfilePic')) 
                        {                    
                            $this->send_fail($this->upload->display_errors());
                        } 
                        else 
                        {

                            $filename = $_FILES['vProfilePic']['tmp_name'];
                            $size = getimagesize($filename);
                            list($widthIsg, $heightIsg) = getimagesize($filename);
                            if($widthIsg>150 && $heightIsg>150)
                            {
                                $config3 ['image_library'] = 'gd2';
                                $config3 ['source_image'] = USER_IMAGE_PATH . $image_name;
                                $config3 ['new_image'] = USER_IMAGE_PATH_THUMB . $image_name;
                                $config3 ['create_thumb'] = FALSE;
                                $config3 ['maintain_ratio'] = TRUE;
                                $config3 ['width'] = 150;
                                $config3 ['height'] = 150;              
                                $this->image_lib->initialize($config3); 
                                if ( ! $this->image_lib->resize())
                                {
                                    $this->send_fail($this->image_lib->display_errors());
                                }
                            }
                            else
                            {
                                copy(USER_IMAGE_PATH . $image_name, USER_IMAGE_PATH_THUMB . $image_name);
                            }
                            $postData['vProfilePic'] = $image_name;
                        }
                }
                else
                {
                    $postData['vProfilePic'] = '';
                }
                //-----------------------------------------------------------
                // Check Username Availability
				$available = $this->user_model->checkUsernameAvailability($vUserName,0);
				if($available == 0 ) {
                    $this->send_fail('Username is not available');
				}
				 
                
				$iInsertID = $this->user_model->registration_basic($postData);
                if ($iInsertID != "")
                {   
                    $macstatus = genratemac($iInsertID);
                    $response = $this->user_model->getuserprofilebyid($iInsertID);
                    if(!empty($response))
                    {
                        $response['accesstoken'] = $macstatus;
                        $this->send_success($response);
                    }
                    else
                    {
                        $this->send_fail('No data found.');
                    }
                }
                else
                {
                    $this->send_fail('User could not be registered.');
                }
            }
        }
        else
        {
            $this->send_fail('Insufficient Data');
        }
    }



    //Created By : ID on 05-04-2017
    //Created for : User Registration API
    function user_edit_registration_post()
    {
        $postData = $this->post();
        extract($postData);
        //$this->response($postData, 200);
        if (checkparams($postData,array('iUserID','vFirstName','vLastName','vUserName','vAddress','iPhoneNumber','vDetail','iTradeID','vDeviceToken','ePlatform'),array('vProfilePic')))
        {
            if($iUserID == '')
            {
                $this->send_fail('Please provide User id.');
            }
            if($vFirstName == '')
            {
                $this->send_fail('Please provide first name.');
            }
			 if($vLastName == '')
            {
                $this->send_fail('Please provide last name.');
            }
			 if($vUserName == '')
            {
                $this->send_fail('Please provide Username.');
            }
            if($vAddress == '')
            {
                $this->send_fail('Please provide Address.');
            }
           /* if($dLat == '')
            {
                $this->send_fail('Please provide Lattitude.');
            }
            if($dLong == '')
            {
                $this->send_fail('Please provide Longitude.');
            }*/
            if($iPhoneNumber == '')
            {
                $this->send_fail('Please provide Phonenumber.');
            }
            if($vDetail == '')
            {
                $this->send_fail('Please provide Detail.');
            }
            if($iTradeID == '')
            {
                $this->send_fail('Please provide Trade.');
            }
            if($vDeviceToken == '')
            {
                 $this->send_fail('Please provide device token.');
            }
            if($ePlatform == '')
            {
                 $this->send_fail('Please provide platform.');
            }
            
            //------------Add user Profile Image-------------------
            if(isset($_FILES['vProfilePic']) && !empty($_FILES))
            {
                $this->user_model->deleteUserProfileImage();
                $configImage['upload_path'] = USER_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vProfilePic'];
                
                    $_FILES['vProfilePic']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vProfilePic']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vProfilePic']['tmp_name']= $files['tmp_name'];
                    $_FILES['vProfilePic']['error']= $files['error'];
                    $_FILES['vProfilePic']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vProfilePic']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vProfilePic']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vProfilePic')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {

                        $filename = $_FILES['vProfilePic']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = USER_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = USER_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(USER_IMAGE_PATH . $image_name, USER_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vProfilePic'] = $image_name;
                    }
            } 

            //-----------------------------------------------------------
			
			 // Check Username Availability
			$available = $this->user_model->checkUsernameAvailability($vUserName,$iUserID);
			if($available == 0 ) {
				$this->send_fail('Username is not available');
			}
			
			
            $iInsertID = $this->user_model->editUser_basic($postData);
            if ($iInsertID != "")
            {   
                $response = $this->user_model->getuserprofilebyid($iInsertID);
                if(!empty($response))
                {
                    $this->send_success($response);
                }
                else
                {
                    $this->send_fail('No data found.');
                }
            }
            else
            {
                $this->send_fail('User could not be updated.');
            }
            
        }
        else
        {
            $this->send_fail('Insufficient Data');
        }
    }

    //Created By : ID on 16-02-2017
    //Created for : Change user event status.  
    public function changeStatus_post() 
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iEventID','Status')))
        {
            if($Status == "")
            {
                $this->send_fail('Please provide status.');
            }

            $result = $this->user_model->changeStatus($postData);
            if($result != 0)
            {
                $this->send_success($result);
            }
            else
            {
                $this->send_fail('Event not found.');
            }
        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 29-04-2017
    //Created for : change distance units
    public function changeDistanceUnits_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('eDistance')))
        {
            if($eDistance == "")
            {
                $this->send_fail('Please provide distance units.');
            }
            else if($eDistance != "Km" && $eDistance != "Miles")
            {
                $this->send_fail('Invalid Distance Unit.');
            }

            $result = $this->user_model->changeDistanceUnits($postData);
            if($result != 0)
            {
                $this->send_success($result);
            }
            else
            {
                $this->send_fail('Distance unit changed successfully.');
            }
        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }
    }

    
    //Created By : ID on 28-04-2017
    //Created for : Get Trade List
    public function getTradeList_get() 
    {
        $result = $this->user_model->getTradeList();
        $this->send_success($result);
    }

    //Created By : ID on 01-05-2017
    //Created for : Get Expense category list
    public function getExpenseCateggoryList_get() 
    {
        $result = $this->user_model->getExpenseCateggoryList();
        $this->send_success($result);
    }

    //Created By : ID on 28-04-2017
    //Created for : Get my expense list
    public function getMyExpenseList_post()
    {
        //$vTimePeriod can be a) lastWeek , lastMonth , 6month , 1year,today
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page','vSearch'),array('dFromDate','dToDate','vTimePeriod')))
        {
            if($page == "")
            {
                $this->send_fail('Please provide page.');
            }
            
            $result = $this->user_model->getMyExpenseList($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);

        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }
    }
	
	//Created By : KK on 10-08-2017
    //Created for : To export expense list
    public function exportMyExpenseList_post()
    {
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$userdata = $this->user_model->getuserprofilebyid($iUserID);

        //$vTimePeriod can be a) lastWeek , lastMonth , 6month , 1year,today
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array(),array('dFromDate','dToDate','vTimePeriod'))) {
            $result = $this->user_model->exportMyExpenseList($postData);
			
				if($result['iTotalRecords'] > 0) {
					
					$datetime = date("YmdHis");
					$filename = "expense_report_".$datetime."_".$iUserID.".csv";
					
					$fp = fopen(EXPENSE_CSV_PATH.$filename, 'w');
												
					$csv_header[] = array('Expense ID','Expanse Title','Amount','Business Name','Detail','Date','Category Name');
					
					$expense_result_final = array_merge($csv_header, $result['vData']);
 					
					foreach ($expense_result_final as $key => $value) {
 						fputcsv($fp, $value);
					}
 					fclose($fp);
					//$result['logbook_path'] = LOGBOOK_CSV_URL.$filename;
					
					// ----------------- Send Mail ---------------------
 					$this->load->library('email');
		 
					$data = array(
									'mailto' => $userdata['vEmail'],
									//'mailto' => "krupal@openxcelltechnolabs.com",
									'from' => SUPPORT_EMAIL_ADDRESS,
									'my_replyto' => SUPPORT_EMAIL_ADDRESS,
									'name' => $userdata['vFirstName'],
									'my_file' => $filename,
									'my_path' => EXPENSE_CSV_PATH
								);
 				   $this->load->view('email/expense', $data);
				   // Unlink CSV after mail
				   $file_path = EXPENSE_CSV_PATH.$filename;
				   if (file_exists($file_path)){
						unlink($file_path); 
				   } 
 				   // ---------------------------------------------------
				   $this->send_success_message('The report has been emailed successfully. If you do not receive, please check spam folder.'); 
		
				}
			   else {
					$this->send_fail('There is no log to be printed');
			   }
 			
           }
        else {
             $this->send_fail('Insufficient Data.');
        }
    }
	
 
    //Created By : ID on 01-05-2017
    //Created for : Add user Expense
    public function addUserExpense_post()
    {
        $postData=$this->post();
        extract($postData);
       // if(checkparams($postData,array('iExpenseCateID','vExpanseTitle','dAmount','vBusinessName','dDate','vDetail'),array('vExpenseImage')))
        if(checkparams($postData,array('iExpenseCateID','vExpanseTitle','dAmount','vBusinessName','dDate','vDetail'),array('vExpenseImage')))
        {
            if($iExpenseCateID == "")
            {
                $this->send_fail('Please provide expense category.');
            }
            
            if($vExpanseTitle == "")
            {
                $this->send_fail('Please provide expense title.');
            }
            
            if($dAmount == "")
            {
                $this->send_fail('Please provide expense amount.');
            }
            
            if($vBusinessName == ''){

                $this->send_fail('Please provide Business Name.');
            }
            
            if($dDate == '')
            {
                $this->send_fail('Please provide Expense date.');
            }
            
            /*if($vDetail == '')
            {
                $this->send_fail('Please provide Expense Detail.');
            }*/
            //------------Add user Expense Image-------------------

            if(isset($_FILES['vExpenseImage']) && !empty($_FILES))
            {
                $configImage['upload_path'] = EXPENSE_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vExpenseImage'];
                
                    $_FILES['vExpenseImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vExpenseImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vExpenseImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vExpenseImage']['error']= $files['error'];
                    $_FILES['vExpenseImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vExpenseImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vExpenseImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vExpenseImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {

                        $filename = $_FILES['vExpenseImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = EXPENSE_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = EXPENSE_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(EXPENSE_IMAGE_PATH . $image_name, EXPENSE_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vExpenseImage'] = $image_name;
                    }
            }

            //-----------------------------------------------------------
            $result = $this->user_model->addUserExpense($postData);
            if(!empty($result)) {				
				$this->send_success($result,EXPENSE_ADDED_SUCCESSFULLY);                
            }
            else {
                $this->send_fail('Unable to save data! Please try again');
            }
         }
        else {
             $this->send_fail('Insufficient Data.');
        }
    }


     //Created By : ID on 01-05-2017
    //Created for : Edit expense detail.
    public function editExpenseDetail_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserExpenseID','iExpenseCateID','vExpanseTitle','dAmount','vBusinessName','dDate','vDetail'),array('vExpenseImage')))
        {
            if($iUserExpenseID == "")
            {
                $this->send_fail('Please provide expense id.');
            }

            if($iExpenseCateID == "")
            {
                $this->send_fail('Please provide expense category.');
            }
            
            if($vExpanseTitle == "")
            {
                $this->send_fail('Please provide expense title.');
            }
            
            if($dAmount == "")
            {
                $this->send_fail('Please provide expense amount.');
            }
            
            if($vBusinessName == ''){

                $this->send_fail('Please provide Business Name.');
            }
            
            if($dDate == '')
            {
                $this->send_fail('Please provide Expense date.');
            }
            
           /* if($vDetail == '')
            {
                $this->send_fail('Please provide Expense Detail.');
            }*/
            //------------Add user Expense Image-------------------

            if(isset($_FILES['vExpenseImage']) && !empty($_FILES))
            {
                //$this->user_model->deleteUserExpenseImage();
				
                $configImage['upload_path'] = EXPENSE_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vExpenseImage'];
                
                    $_FILES['vExpenseImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vExpenseImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vExpenseImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vExpenseImage']['error']= $files['error'];
                    $_FILES['vExpenseImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vExpenseImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vExpenseImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vExpenseImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {

                        $filename = $_FILES['vExpenseImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = EXPENSE_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = EXPENSE_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else {
                            copy(EXPENSE_IMAGE_PATH . $image_name, EXPENSE_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vExpenseImage'] = $image_name;
                    }
            }

            //-----------------------------------------------------------
            $result = $this->user_model->editUserExpense($postData);
			
            if(!empty($result)){
  				$this->send_success($result,EXPENSE_SAVED_SUCCESSFULLY);
            }
            else{
                $this->send_fail('Unable to update data! Please try again');
            }
        }
        else {
             $this->send_fail('Insufficient Data.');
        }

    }

    //Created By : ID on 01-05-2017
    //Created for : Delete expense detail.
    public function deleteExpense_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserExpenseID')))
        {
            if($iUserExpenseID == "")
            {
                $this->send_fail('Please provide expense id.');
            } 
           $result=$this->user_model->deleteExpense($postData);  
           if($result)
           {
               $this->send_success_message('Expense Deleted.'); 
           }
           else
           {
                $this->send_fail('Unable to delete Expense!! Please try again.');
           }
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }

     //Created By : ID on 01-05-2017
    //Created for : Get my expense reminder.
    public function getMyExpenceReminderByDate_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page','dDate')))
        {
            $result = $this->user_model->getMyExpenceReminderByDate($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
	//Created By : Kp on 17-05-2017
    //Created for : Get my expense reminder Month Wise for calender view.
    public function getMyExpenceReminderByMonth_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iMonth', 'iYear')))
        {
            $result = $this->user_model->getMyExpenceReminderByMonth($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
	
	public function getMyExpenceReminderByID_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iReminderID')))
        {
            $result = $this->user_model->getMyExpenceReminderByID($postData);
            $this->send_success($result['vData']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 02-05-2017 
    //Created for : Get my expense reminder.
    public function addExpenseReminder_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('vTitle','dDate','tTime','vComment','vAddress','dLat','dLong'),array('vImage')))
        {
            if($vTitle == "")
            {
                $this->send_fail('Please provide Title.');
            }
            if($dDate == "")
            {
                $this->send_fail('Please provide date.');
            }
            if($tTime == "")
            {
                $this->send_fail('Please provide time.');
            }
            if($vComment == "")
            {
                $this->send_fail('Please provide comment.');
            }
            /*if($vAddress == ''){

                $this->send_fail('Please provide Address.');
            }
            if($dLat == '')
            {
                $this->send_fail('Please provide Latitude.');
            }
            
            if($dLong == '')
            {
                $this->send_fail('Please provide Longitude.');
            }*/
            //------------Add user Expense Image-------------------

            if(isset($_FILES['vImage']) && !empty($_FILES))
            {
                $configImage['upload_path'] = REMINDER_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vImage'];
                
                    $_FILES['vImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vImage']['error']= $files['error'];
                    $_FILES['vImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {
                        $filename = $_FILES['vImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = REMINDER_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = REMINDER_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(REMINDER_IMAGE_PATH . $image_name, REMINDER_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vImage'] = $image_name;
                    }
            }

            //-----------------------------------------------------------
            $result = $this->user_model->addReminderData($postData);
            if(!empty($result)) {
                 $this->send_success($result,REMINDER_ADDED_SUCCESSFULLY);
            }
            else {
                $this->send_fail('Unable to Insert data! Please try again');
            }

        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }

    }


     //Created By : ID on 02-05-2017
    //Created for : Get my expense reminder.
    public function editExpenseReminder_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iReminderID','vTitle','dDate','tTime','vComment','vAddress','dLat','dLong'),array('vImage')))
        {
            if($vTitle == "")
            {
                $this->send_fail('Please provide title.');
            }
            if($dDate == "")
            {
                $this->send_fail('Please provide date.');
            }
            if($tTime == "")
            {
                $this->send_fail('Please provide time.');
            }
            if($vComment == "")
            {
                $this->send_fail('Please provide comment.');
            }
            /*if($vAddress == ''){

                $this->send_fail('Please provide Address.');
            }
            if($dLat == '')
            {
                $this->send_fail('Please provide Latitude.');
            }
            
            if($dLong == '')
            {
                $this->send_fail('Please provide Longitude.');
            }*/
            //------------Add user Expense Image-------------------

            if(isset($_FILES['vImage']) && !empty($_FILES))
            {
                //$this->user_model->deleteUserReminderImage($iReminderID);
                $configImage['upload_path'] = REMINDER_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vImage'];
                
                    $_FILES['vImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vImage']['error']= $files['error'];
                    $_FILES['vImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {
                        $filename = $_FILES['vImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = REMINDER_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = REMINDER_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(REMINDER_IMAGE_PATH . $image_name, REMINDER_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vImage'] = $image_name;
                    }
            }

            //-----------------------------------------------------------
            $result = $this->user_model->editExpenseReminder($postData);
            if(!empty($result)) {
                $this->send_success($result,REMINDER_SAVED_SUCCESSFULLY);
            }
            else {
                $this->send_fail('Unable to Insert data! Please try again');
            }

        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }
    }


    public function deleteReminder_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iReminderID')))
        {
            if($iReminderID == "")
            {
                $this->send_fail('Please provide reminder id.');
            } 
           $result=$this->user_model->deleteReminder($postData);  
           if($result)
           {
               $this->send_success_message('Reminder deleted.'); 
           }
           else
           {
                $this->send_fail('Unable to delete Reminder!! Please try again.');
           }
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 19-04-2017
    //Created for : Get my loglist.
    public function getMyLogList_post(){
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page')))
        {
            $result = $this->user_model->getMyLogList($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
 
    public function exportLogbook_post(){
        
		$logbook_result = $this->user_model->exportLogbook();
  		$result['iTotalRecords'] = $logbook_result['iTotalRecords'];
 		
		$iUserID = $_SERVER['HTTP_IUSERID'];
		$userdata = $this->user_model->getuserprofilebyid($iUserID);
 
   		
		if($logbook_result['iTotalRecords'] > 0) {
			
			$datetime = date("YmdHis");
			$filename = "logbook_report_".$datetime."_".$iUserID.".csv";
			
			$fp = fopen(LOGBOOK_CSV_PATH.$filename, 'w');
  										
			$csv_header[] = array('Log ID','Start Datetime','End Datetime','Start Area','End Area','Start Address','Distance','End Address','Completed Status', 'Duration');
			
			$logbook_result_final = array_merge($csv_header, $logbook_result['vData']);
  			
			foreach ($logbook_result_final as $key => $value) {
				fputcsv($fp, $value);
			}
			
			fclose($fp);
			//$result['logbook_path'] = LOGBOOK_CSV_URL.$filename;
			
			// ----------------- Send Mail ---------------------
         	$this->load->library('email');
 
          	$data = array(
				     'mailto' => $userdata['vEmail'],
					//'mailto' => "krupal@openxcelltechnolabs.com",
					'from' => SUPPORT_EMAIL_ADDRESS,
					'my_replyto' => SUPPORT_EMAIL_ADDRESS,
					'name' => $userdata['vFirstName'],
					'my_file' => $filename,
					'my_path' => LOGBOOK_CSV_PATH
 	        	);
	       	$this->load->view('email/log', $data);
 			 
			// ---------------------------------------------------
		   $this->send_success_message('The report has been emailed successfully. If you do not receive, please check spam folder.'); 

 		}
 	   else {
			$this->send_fail('There is no log to be printed');
	   }
		   
       }
	 
	 // Mail with Attachment script
	 function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message) {
		 $file = $path.$filename;
		 $file_size = filesize($file);
		 $handle = fopen($file, "r");
		 $content = fread($handle, $file_size);
		 fclose($handle);
		 $content = chunk_split(base64_encode($content));
		 $uid = md5(uniqid(time()));
		 $header = "From: ".$from_name." <".$from_mail.">\r\n";
		 $header .= "Reply-To: ".$replyto."\r\n";
		 $header .= "MIME-Version: 1.0\r\n";
		 $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
		 $header .= "This is a multi-part message in MIME format.\r\n";
		 $header .= "--".$uid."\r\n";
		 $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
		 $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
		 $header .= $message."\r\n\r\n";
		 $header .= "--".$uid."\r\n";
		 $header .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use different content types here
		 $header .= "Content-Transfer-Encoding: base64\r\n";
		 $header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
		 $header .= $content."\r\n\r\n";
		 $header .= "--".$uid."--";
		 if (mail($mailto, $subject, "", $header)) {
		 echo "mail send ... OK"; // or use booleans here
		 } else {
		 echo "mail send ... ERROR!";
		 }
		}
	 
	   
    //Created By : ID on 19-04-2017
    //Created for : Get my loglist.
    public function addLogDetail_post(){
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('dDate','tStartTime','tEndTime','dStartLat','vStartAddress','dStartLong','vEndAddress','dEndLat','dEndLong','dDistance')))
        {
            if($dDate == '')
            {
                $this->send_fail('Please provide date !');
            }

            if($tStartTime == '')
            {
                $this->send_fail('Please provide starttime !');
            }

            if($tEndTime == '')
            {
                $this->send_fail('Please provide endtime !');
            }

            if($dStartLat == '')
            {
                $this->send_fail('Please provide start Latitude !');
            }

            if($vStartAddress == '')
            {
                $this->send_fail('Please provide start Address !');
            }

            if($dStartLong == '')
            {
                $this->send_fail('Please provide start Longitude !');
            }

            if($vEndAddress == '')
            {
                $this->send_fail('Please provide End Address !');
            }

            if($dEndLat == '')
            {
                $this->send_fail('Please provide End Latitude !');
            }

            if($dEndLong == '')
            {
                $this->send_fail('Please provide End Longitude !');
            }

            $result = $this->user_model->addLogDetail($postData);
            if($result != 0)
            {
                $this->send_success($result);
            }
            else
            {
                $this->send_fail('Log detail not inserted!');       
            }
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
	
	 //Created By : KK on 30-05-2017
    //Created for : Add start log
    public function addStartLog_post(){
        $postData=$this->post();
        extract($postData);
		/*
		req Params:
			dDate
			dStartLat
			dStartLong
			tStartTime
		*/
        if(checkparams($postData,array('iStartDatetimeUnix', 'dStartLat','vStartAddress','vStartArea','dStartLong')))
        {
            if($iStartDatetimeUnix == '') {
                $this->send_fail('Please provide start datetime!');
            }
             if($dStartLat == '') {
                $this->send_fail('Please provide start Latitude!');
            }
            if($vStartAddress == '') {
                $this->send_fail('Please provide start Address!');
            }
			if($vStartArea == '') {
                $this->send_fail('Please provide start Area!');
            }
            if($dStartLong == '') {
                $this->send_fail('Please provide start Longitude!');
            }
            
            $result = $this->user_model->addStartLog($postData);
            if($result != 0)
            {
                $this->send_success($result);
            }
            else
            {
                $this->send_fail('Log detail not inserted!');       
            }
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
	
	  //Created By : KK on 19-04-2017
    //Created for : Get my loglist.
    public function addEndLog_post(){
        $postData=$this->post();
        extract($postData);
		 
       // if(checkparams($postData,array('iLogID','dStartLat','dStartLong','tStartTime','tEndTime','dEndLat','dEndLong','vEndAddress', 'vEndArea')))
        if(checkparams($postData,array('iLogID','iEndDatetimeUnix','dEndLat','dEndLong','vEndAddress', 'vEndArea')))
        {
            if($iLogID == '') {
                $this->send_fail('Please provide LogID !');
            }
			if($iEndDatetimeUnix == '') {
                $this->send_fail('Please provide end datetime !');
            }
            if($vEndAddress == '') {
                $this->send_fail('Please provide End Address !');
            }
			 if($vEndArea == '') {
                $this->send_fail('Please provide End Area !');
            }
            if($dEndLat == '') {
                $this->send_fail('Please provide End Latitude !');
            }
            if($dEndLong == '') {
                $this->send_fail('Please provide End Longitude !');
            }
 			
            $result = $this->user_model->addEndLog($postData);
            if($result != 0)
            {
                $this->send_success($result);
            }
            else
            {
                $this->send_fail('Log detail not inserted!');       
            }
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 05-05-2017
    //Created for : Get my feeds.
    public function getMyFeeds_post(){
        $postData=$this->post();
        extract($postData);
        //if(checkparams($postData,array('page')))
		if(checkparams($postData,array('page'),array('iPostCatID','vKeyword'))){
            $result = $this->user_model->getMyFeeds($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else {
           $this->send_fail('Insufficient Data.');
        } 
    }
	
	
 	public function getFeedByID_post(){
        $postData=$this->post();
        extract($postData);
        //if(checkparams($postData,array('page')))
		if(checkparams($postData,array('iUserPostID'))){
            $result = $this->user_model->getFeedByID($iUserPostID);
            $this->send_success($result['vData']);
        }
        else {
           $this->send_fail('Insufficient Data.');
        } 
    }
	
	// Send Contact Details in Email
	public function sendContactDetailViaMail_post(){
        $postData=$this->post();
        extract($postData);
 		if(checkparams($postData,array('iUserPostID'))){
            $result = $this->user_model->sendContactDetailViaMail($iUserPostID);
            $this->send_success($result, "Contact detail has been sent successfully via mail.");
        }
        else {
           $this->send_fail('Insufficient Data.');
        } 
    }


    //Created By : ID on 05-05-2017
    //Created for : Get my feeds.
    public function getCommentListBypostID_post(){
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page','iUserPostID')))
        {
            if($iUserPostID == ''){
                $this->send_fail('Please provide post id.');
            }

            $result = $this->user_model->getCommentListBypostID($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }


    //Created By : ID on 05-05-2017
    //Created for : Get my feeds.
    public function getLikeListBypostID_post(){
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page','iUserPostID')))
        {
            if($iUserPostID == ''){
                $this->send_fail('Please provide post id.');
            }

            $result = $this->user_model->getLikeListBypostID($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }

    public function addPost_post() 
    {   
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('vDetail','vTitle','iPostCatID'),array('vPostImage')))
        {
            /*if($eIsInnerPurchase != '0' && $eIsInnerPurchase != '1' ) {
                $this->send_fail('Please provide Inner purchase 0 or 1');
            }*/

            if($vDetail == "") {
                $this->send_fail('Please provide post detail.');
            }

            if($vTitle == "") {
                $this->send_fail('Please provide post title.');
            }

            if($iPostCatID == "") {
                $this->send_fail('Please provide post category id.');
            }


            //------------Add user Post Image-------------------

            if(isset($_FILES['vPostImage']) && !empty($_FILES))
            {
				// Removed by KK
               // $this->user_model->deleteUserReminderImage($iReminderID);
                $configImage['upload_path'] = POST_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vPostImage'];
                
                    $_FILES['vPostImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vPostImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vPostImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vPostImage']['error']= $files['error'];
                    $_FILES['vPostImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vPostImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vPostImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vPostImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {
                        $filename = $_FILES['vPostImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = POST_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = POST_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(POST_IMAGE_PATH . $image_name, POST_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vPostImage'] = $image_name;
                    }
            }else{
                $postData['vPostImage'] = '';
            }

            //-----------------------------------------------------------

            $result = $this->user_model->addPost($postData);
            if($result == 2) {
 				$this->send_fail("Please purchase job category to post.");
            }
			else if(is_array($result)) {
 				$this->send_success($result,POST_ADDED_SUCCESSFULLY);
            }
            else {
                $this->send_fail('Post not added.');
            }
        }
        else {
           $this->send_fail('Insufficient Data.');
        }
    }
 
	public function editPost_post() {

        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserPostID','vDetail','vTitle','iPostCatID'),array('vPostImage')))
        {
            if($vDetail == "") {
                $this->send_fail('Please provide post detail.');
            }

            if($vTitle == "") {
                $this->send_fail('Please provide post title.');
            }

            if($iPostCatID == "") {
                $this->send_fail('Please provide post category id.');
            }
			
			//------------Add user Post Image-------------------

            if(isset($_FILES['vPostImage']) && !empty($_FILES))
            {
                 //$this->user_model->deleteUserReminderImage($iReminderID);
                $configImage['upload_path'] = POST_IMAGE_PATH;
                $configImage['allowed_types'] = '*';
                $configImage['max_size']  = '5120';
                $this->load->library('upload', $configImage);
                $this->load->library('image_lib');
                $files = $_FILES['vPostImage'];
                
                    $_FILES['vPostImage']['name'] = str_replace('&', '_', $files['name']);
                    $_FILES['vPostImage']['name'] = str_replace(' ', '_', $files['name']);
                    $_FILES['vPostImage']['tmp_name']= $files['tmp_name'];
                    $_FILES['vPostImage']['error']= $files['error'];
                    $_FILES['vPostImage']['size']= $files['size'];
                    $ext = explode('.',$_FILES['vPostImage']['name']);
                    $image_name = time() . "_" . uniqid().'.'.pathinfo($_FILES['vPostImage']['name'], PATHINFO_EXTENSION);
                    $configImage['file_name'] = $image_name;
                    $this->upload->initialize($configImage);
                    
                    if (!$this->upload->do_upload('vPostImage')) 
                    {                    
                        $this->send_fail($this->upload->display_errors());
                    } 
                    else 
                    {
                        $filename = $_FILES['vPostImage']['tmp_name'];
                        $size = getimagesize($filename);
                        list($widthIsg, $heightIsg) = getimagesize($filename);
                        if($widthIsg>150 && $heightIsg>150)
                        {
                            $config3 ['image_library'] = 'gd2';
                            $config3 ['source_image'] = POST_IMAGE_PATH . $image_name;
                            $config3 ['new_image'] = POST_IMAGE_PATH_THUMB . $image_name;
                            $config3 ['create_thumb'] = FALSE;
                            $config3 ['maintain_ratio'] = TRUE;
                            $config3 ['width'] = 150;
                            $config3 ['height'] = 150;              
                            $this->image_lib->initialize($config3); 
                            if ( ! $this->image_lib->resize())
                            {
                                $this->send_fail($this->image_lib->display_errors());
                            }
                        }
                        else
                        {
                            copy(POST_IMAGE_PATH . $image_name, POST_IMAGE_PATH_THUMB . $image_name);
                        }
                        $postData['vPostImage'] = $image_name;
                    }
            }else{
                $postData['vPostImage'] = '';
            }
			
			// Edit Post Date in Database
            $result = $this->user_model->editPost($postData);
            if($result != 0) {
 				$this->send_success($result,POST_SAVED_SUCCESSFULLY);
            }
            else {
                $this->send_fail('Post not added.');
            }
        }
        else {
           $this->send_fail('Insufficient Data.');
        }

    }

    //Created By : ID on 05-05-2017
    //Created for : Remove post by post id
    public function removePostByPostID_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserPostID')))
        {
            $result = $this->user_model->removePostByPostID($postData);
            if($result != 0){
                $this->send_success_message(POST_DELETED_SUCCESSFULLY);
            }else{
                $this->send_fail('Unable to remove post !! Please try again.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }

    }

    public function getPostCategory_get()
    {   
        $result = $this->user_model->getPostCategory();
        $this->send_success($result);
    }

	 //Created By : KK on 25-05-2017
    //Created for : Add LIKE/DISLIKE.
    public function addLikeDislikeOnPost_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iPostID','action')))
        {
            if($iPostID == '')
            {
                $this->send_fail('Please select Post.');
            }
			
            $result = $this->user_model->addLikeDislikeOnPost($postData);
            if($result != 0){
                //$this->send_success_message("SUCCESS");
                $this->send_success($result);
            }else{
                $this->send_fail('Something wrong!! Please try again.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }
	
	 

   //Created By : ID on 08-05-2017
    //Created for : Add comment.
    public function addComment_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserPostID','vComment'))) {
            if($vComment == '') {
                $this->send_fail('Please provide comment.');
            }
            $result = $this->user_model->addComment($postData);
            if($result != 0){
 				$this->send_success($result,COMMENT_ADDED_SUCCESSFULLY);
            }else{
                $this->send_fail('Unable to add post !! Please try again.');
            }
        }
        else {
            $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 08-05-2017
    //Created for : Add comment.
    public function editComment_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iPostCommentID','vComment')))
        {
            if($iPostCommentID == '')
            {
                $this->send_fail('Please provide post comment id.');
            }

            if($vComment == '')
            {
                $this->send_fail('Please provide comment.');
            }
            $result = $this->user_model->editComment($postData);
            if($result != 0){
                $this->send_success($result);
            }else{
                $this->send_fail('Unable to add post !! Please try again.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }

    //Created By : ID on 08-05-2017
    //Created for : Remove comment.
    public function removeComment_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iPostCommentID')))
        {
            $result = $this->user_model->removeComment($postData);
            if($result != 0){
                $this->send_success($result,COMMENT_DELETED_SUCCESSFULLY);
            }else{
                $this->send_fail('Unable to add post !! Please try again.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }
	


    //Created By : ID on 19-04-2017
    //Created for : Logout User.
    public function logout_post() 
    {
        $result=$this->user_model->logout_user(getuserid());
        if ($result) 
        {
            $this->send_success_message('User Logout Sucessfully.');
        }
        else
        {
            $this->send_fail('Logout opration fail.');
        }
    }


   function send_success($data, $message="", $code=200) {
        $row = array("DATA" => $data,"STATUS_CODE" => $code,"MESSAGE" => $message);
        /*if (!empty($additional)) {
            foreach ($additional as $key => $value) {
                $row[$key] = $value;
            }
        }*/
        $this->response($row, 200);
    }

    function send_success_with_pagination($data,$total,$pageCount,$code=200) 
    {
        //mprd($data);
        $row = array("DATA" => $data, "Total"=>$total, "PageCount"=>$pageCount, "STATUS_CODE" => $code);
        $this->response($row, 200);
    }


   /* function send_success_message($data,$code=201) {
        $row = array("MESSAGE" => $data, "STATUS_CODE" => $code);
        $this->response($row, 201);
    }*/
	
	 function send_success_message($data,$code=200) {
        $row = array("MESSAGE" => $data, "STATUS_CODE" => $code);
        $this->response($row, 200);
    }

    //Created by :: ID
    //created for :: Responce Data Structure
    //created date :: 18-01-17 :: Responce Data Structure
    function send_fail($msg,$code=202) {
        $row = array("MESSAGE" => $msg, "STATUS_CODE" => $code);
        $this->response($row, 201);
    }

    //Created By :ID on 20-04-2017
    //Created for :Update notification flag
    function updateNotificationFlag_post()
    {
        $result = $this->user_model->updateNotification();
        if($result)
        {   
            $this->send_success($result);
        }
        else
        {
            $this->send_fail('User not found!!');
        }
    }

    //Created By : ID on 20-04-2017
    //Created for : Change user password. 
    function changePassword_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('oldPassword','newPassword')))
        {
            if($oldPassword == "")
            {
                $this->send_fail('Please enter old password.');
            }

            if($newPassword == "")
            {
                $this->send_fail('Please enter new password.');
            }

            $result = $this->user_model->changePassword($postData);

            if($result == 2)
            {
                $this->send_success_message('Password changed successfully !! ');

            } 
            elseif($result == 3) 
            {
                $this->send_fail('Incorrect Old password.');
            } 
            else 
            {
                $this->send_fail('User not found!!');
            }
            
        }
        else
        {
             $this->send_fail('Insufficient Data.');
        }

    }

    function TestNotifica_post() 
    {
        $token = $postData=$this->post("token");
        $this->user_model->TestNotifica($token);
    }

    //Created By :ID on 21-02-2017
    //Created for :Get Static Pages
    public function getStaticPages_post()
    {
        $postData=$this->post();
        extract($postData);
        //array('2'=>'Terms & Condition','3'=>'Privacy policy');
        if(checkparams($postData,array('id')))
        {
            if($id=="")
            {
                $this->send_fail('Please provide Page Id');
            }
            $result = $this->user_model->getStaticPages($postData);
            $this->send_success($result);
        }
        else {
            $this->send_fail('Insufficient Data');
        }
    }


      //Created By : ID on 06-04-2017
    //Created for : Change user password. 
    function submitContactusDetail_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('vSubject','vComment'))) {
            if($vSubject == "") {
                $this->send_fail('Please provide subject.');
            }

            if($vComment == "") {
                $this->send_fail('Please provide comment.');
            }
            $result = $this->user_model->submitContactusDetail($postData);
            if($result) {
 				// ----------------- Send Mail ---------------------
 				$iUserID = $_SERVER['HTTP_IUSERID'];
				$userdata = $this->user_model->getuserprofilebyid($iUserID);
	 
				$this->load->library('email');
	 
				$data = array(
						 //'mailto' => ,
						//'mailto' => 'krupal@openxcelltechnolabs.com',
						'mailto' => 'CONTACT_EMAIL_ADDRESS',
						'from' => $userdata['vEmail'],
						'my_replyto' => SUPPORT_EMAIL_ADDRESS,
						'vEmail' => $userdata['vEmail'],
						'name' => $userdata['vFirstName'],
						'iPhoneNumber' => $userdata['iPhoneNumber'],
						'username' => $userdata['vUserName'],
						'vSubject' => $vSubject,
						'vComment' => $vComment						
					);
				$this->load->view('email/contact', $data);
 				// ---------------------------------------------------
			   $this->send_success_message('Your detail has been emailed successfully.'); 
              }
            else {
                $this->send_fail('Unable to save contactus detail!! Please try again.');
            }
        }
        else {
             $this->send_fail('Insufficient Data.');
        }
    }

    public function addUser_post() 
    {
        $result = $this->user_model->addUser();
        if($result==1){
             $this->send_success_message('data inserted !');
         }else{
             $this->send_success_message('data not inserted !');
         }
    }

    //Created By : ID on 25-02-2017
    //Created for : Update Badge 
    public function updateBadge_post()
    {
        $result = $this->user_model->updateBadge();
        if($result){
            $this->send_success_message('Badge Count Changed.');   
        }
        else {
            $this->send_fail('Badge Count Not Changed.');
        }
        $this->response($row,200);
    }
	
	
	 public function purchaseLogbook_post()
     {
		$purchaseData = $this->post();
 
		 if(checkparams($purchaseData,array('logbookPurchasedDatetime','logbookPurchasedPlatform','logbookPurchasedReceipt','logbookPurchasedAmount','logbookPurchasedCurrency'))) {
			$purchaseData['isLogbookPurchased'] = 'yes';
	
			$result = $this->user_model->purchaseLogbook($purchaseData);
			if($result){
				$this->send_success(array("isLogbookPurchased"=> $purchaseData['isLogbookPurchased']),'You have successfully purchased Logbook feature.');   
			}
			else {
				$this->send_fail('Something wrong during logbook purchase');
			}
		}
		 else {
             $this->send_fail('Insufficient Data.');
        }
				
     }
	 
 	
	public function updatePass_post()
    {
        $result = $this->user_model->updatePass();
        if($result){
            $this->send_success_message('Pass Changed.');   
        }
        else
        {
            $this->send_fail('Pass Not Changed.');
        }
        $this->response($row,200);
    }
	
	
	// To fetch Notification
 	 public function getNotificationList_post(){
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('page')))
        {
            $result = $this->user_model->getNotificationList($postData);
            $this->send_success_with_pagination($result['vData'],$result['iTotalRecords'],$result['iPages']);
        }
        else
        {
           $this->send_fail('Insufficient Data.');
        }
    }
	
	
	//Created By : KK on 25-07-2017
	//Created for : Add comment.
    public function report_post_post()
    {
        $postData=$this->post();
        extract($postData);
        if(checkparams($postData,array('iUserPostID'))) {
            if($iUserPostID == '') {
                $this->send_fail('Please select post.');
            }
			  			
            $result = $this->user_model->report_post($postData);
            if($result == 1){
 				$this->send_success_message("You have reported successfully, admin will take necessary actions.");
             }elseif ($result == 2){
                $this->send_fail('Unable to report post!! Please try again.');
             }
			 else {
			    $this->send_fail('You have already reported, admin will take necessary actions.');
			 }
        }
        else {
            $this->send_fail('Insufficient Data.');
        }
    }
	
	
	// Get Job Package list
 	 public function getJobPackage_post(){
  		$result = $this->user_model->getJobPackage();
		$this->send_success($result);
        
    }
	
	//Created By : KK on 25-07-2017
	//Created for : To purchase Job.
    public function purchase_job_post()
    {
        $puchaseData=$this->post();
        extract($puchaseData);
        if(checkparams($puchaseData,array('vPackageTitle','iJobCount','vPackageAmount','vPackageCurrency','tJobPurchaseReceipt','eJobPurchasePlatform','tJobPurchasedDatetime'))) {
          		
            $result = $this->user_model->purchase_job($puchaseData);
            if(is_array($result)){
 				//$this->send_success($result,"You have successfully purchased feature 'Post a Job'");
 				$this->send_success($result,"Now, You can post ".$result['jobPostRemainingCount']." jobs");
            }
			else {
			    $this->send_fail('There is something wrong during purchase of feature "Post a Job"');
			}
        }
        else {
            $this->send_fail('Insufficient Data.');
        }
    }
 	 
}
    