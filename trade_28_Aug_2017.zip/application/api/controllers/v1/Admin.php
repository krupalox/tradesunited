<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');
class Admin extends REST_Controller
{
	var $client;

	protected $methods = array(
		'index_post' => array('level' => 10, 'limit' => 10000),
		);

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	}

	function basic_registration_post()
	{
		$postData = $this->post();
		extract($postData);
		if (checkparams($postData,array('firstname','lastname','email_address','password','gender','phone_no','device_token','device_type','current_location','current_location_lat','current_location_long')))
		// if (checkparams($postData,array('firstname','lastname','email_address','password','gender','dob','phone_no','about_you','current_status','school','work_place','work_location','work_loc_lat','work_loc_long','position','prof_busi_objective','prof_busi_exp','prof_busi_achiev','values_traits','affiliations','language','relationship','personality','views','quality_leave','quality_tolerate','leisure_time_activity','work_status_id','religion_id','profession_id','device_token','device_type','current_location','current_location_lat','current_location_long')))
		{
			if($email_address == '') {
				$row = array("MESSAGE" => "Please provide email address","SUCCESS" => '0');
				$this->response($row,200);
			}
			if($password == '') {
				$row = array("MESSAGE" => "Please enter password","SUCCESS" => '0');
				$this->response($row,200);
			}

			$check_email = $this->user_model->check_email($postData['email_address']);

			if($check_email == 1)
			{
				$row = array("MESSAGE" => "Email is already registered","SUCCESS" => '0');
				$this->response($row,200);
			}
			else
			{
				if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['name'] != "" )
				{
					$targetpath = '../admin/files/profile_image/original/';
					$thumbpath  = '../admin/files/profile_image/thumb-big/';
					$compress_image_path = '../admin/files/profile_image/thumb-small/';
					$config['upload_path'] = $targetpath;
					/*$config['allowed_types'] = 'gif|jpg|png|doc|txt|pdf|xls|docx|xlsx';*/
					$config['allowed_types'] = '*';
	  				//$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size']  = 1024 * 5;
					$config['encrypt_name'] = TRUE;
					$config['overwrite'] = false;
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if ($this->upload->do_upload('profile_pic'))
					{
						extract($this->upload->data());
						$postData['profile_pic'] = $file_name;
						$this->load->library('image_lib');
						$thumb_config['image_library'] = 'gd2';
						$thumb_config['source_image'] = $targetpath.$postData['profile_pic'];
						$thumb_config['new_image'] = $thumbpath.$postData['profile_pic'];
						$thumb_config['create_thumb'] = FALSE;
						$thumb_config['maintain_ratio'] = TRUE;
						$thumb_config['width'] = 640;
						$thumb_config['height'] = 1096;
						$this->image_lib->clear();
						$this->image_lib->initialize($thumb_config);
						if($this->image_lib->resize()) {
							$postData['thumbnail'] = $file_name;
						}
						$thumb_config2['image_library'] = 'gd2';
						$thumb_config2['source_image'] = $targetpath.$postData['profile_pic'];
						$thumb_config2['new_image'] = $compress_image_path.$postData['profile_pic'];
						$thumb_config2['create_thumb'] = FALSE;
						$thumb_config2['maintain_ratio'] = TRUE;
						$thumb_config2['width'] = 100;
						$thumb_config2['height'] = 100;
						$this->image_lib->clear();
						$this->image_lib->initialize($thumb_config2);
						if($this->image_lib->resize()) {
							$postData['compress'] = $file_name;
						}
					}
					else
					{
						$err = array('MESSAGE' => $this->upload->display_errors(),"SUCCESS" => '0');
						$this->response($err, 200);
					}
				}
				else
				{
					$postData['profile_pic'] = '';
				}
				$iInsertID = $this->user_model->register_basic($postData);
				// mprd($iInsertID);
				if ($iInsertID != "")
				{
					$macstatus = genratemac($iInsertID);
					$response = $this->user_model->get_user_data($iInsertID);
					// mprd($response);
					if(!empty($response))
					{
						$response['accesstoken'] = $macstatus;
						$row = array("SUCCESS" =>'1',"DATA" => $response);
						$this->response($row, 200);
					}
					else
					{
						$row = array("MESSAGE" => "No data found.","SUCCESS" =>'0');
						$this->response($row, 200);
					}
					// mprd($macstatus);
				}
				else
				{
					$row = array("MESSAGE" => "User could not be registered.","SUCCESS" =>'0');
					$this->response($row, 200);
				}
			}
		}
		else
		{
			$row = array("MESSAGE"=>"Insufficient Data","SUCCESS" =>'0');
			$this->response($row, 200);
		}
	}
}