<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require(APPPATH.'/libraries/REST_Controller.php');
class Login extends REST_Controller 
{
	var $client;
	protected $methods = array(
		'index_post' => array('level' => 10, 'limit' => 10000),
		);

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	} 

	
    // Created By: ID on 19-04-2017 
    // Created For: User simple login
    public function simple_login_post()
    {
        $postData = $this->post();
        if (checkparams($postData,array('vEmail','vPassword','vDeviceToken','ePlatform')))
        {
            extract($postData);
            if($vEmail == '') 
            {
                $this->send_fail('Please provide email.');
            }
            if($vPassword == '') 
            {
                $this->send_fail('Please provide password.');
            }
            if($vDeviceToken == '') 
            {
                $this->send_fail('Please provide device token.');
            }

            if($ePlatform == '') 
            {
                $this->send_fail('Please provide platform.');
            } 

            $login = $this->user_model->login_check($vEmail,$vPassword,$vDeviceToken,$ePlatform);
            
            if($login != 1 && $login != 0)
            {
                $macstatus = genratemac($login['iUserID']);
                $login['accesstoken'] = $macstatus;
                $this->send_success($login);
            }
            else
            {
                $this->send_fail('Please provide correct credentials.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }


    // Created By: ID on 05-04-2017
    // Created For: User Login By Facebook API
    public function facebook_login_post()
    {
        $postData = $this->post();
        if (checkparams($postData,array('vEmail','vFbID','ePlatform','vDeviceToken','vFirstName','vLastName'), array('vUserName')))
        {
            extract($postData);
            if($vFirstName == '') {
                $this->send_fail('Please provide name.');
             }
            if($vFbID == '') {
                $this->send_fail('Please provide facebook id.');
            }
            if($ePlatform == '') {
                $this->send_fail('Please provide device token.');
            }
            if($vDeviceToken == '') {
                $this->send_fail('Please provide Device token.');
            }
			if(isset($vUserName) && $vUserName == '') {
                $this->send_fail('Please provide Username.');
            }
			
            $data1 = $this->user_model->fb_login($postData);
  			// Username exits
			if ($data1 == 2) {
                $this->send_fail('Username not available.');
			}
			// First time
			elseif ($data1 == 3) {
                $this->send_fail_fblogin("Email is not registered before");
			}			
            elseif($data1 != 0) {
                $macstatus = genratemac($data1['iUserID']);
                 $data = $this->user_model->getuserprofilebyid($data1['iUserID']);
                $data['accesstoken'] = $macstatus;
                $this->send_success($data);
            }
             else {
                $this->send_fail('No User Available.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }
	
	
	 public function facebook_login_test_post()
    {
        $postData = $this->post();
        if (checkparams($postData,array('vEmail','vFbID','ePlatform','vDeviceToken','vFirstName','vLastName'), array('vUserName')))
        {
            extract($postData);
            if($vFirstName == '') {
                $this->send_fail('Please provide name.');
             }
            if($vFbID == '') {
                $this->send_fail('Please provide facebook id.');
            }
            if($ePlatform == '') {
                $this->send_fail('Please provide device token.');
            }
            if($vDeviceToken == '') {
                $this->send_fail('Please provide Device token.');
            }
			if(isset($vUserName) && $vUserName == '') {
                $this->send_fail('Please provide Username.');
            }
			
            $data1 = $this->user_model->fb_login_test($postData);
  			// Username exits
			if ($data1 == 2) {
                $this->send_fail('Username not available.');
			}
			// First time
			elseif ($data1 == 3) {
                $this->send_fail_fblogin("Email is not registered before");
			}			
            elseif($data1 != 0) {
                $macstatus = genratemac($data1['iUserID']);
                 $data = $this->user_model->getuserprofilebyid($data1['iUserID']);
                $data['accesstoken'] = $macstatus;
                $this->send_success($data);
            }
             else {
                $this->send_fail('No User Available.');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data.');
        }
    }
    
    function send_success($data, $code=200) {
        $row = array("DATA" => $data, "STATUS_CODE" => $code);
        $this->response($row, 200);
    }

   /* function send_success_message($data,$code=201) {
        $row = array("MESSAGE" => $data, "STATUS_CODE" => $code);
        $this->response($row, 201);
    }*/
	
	function send_success_message($data,$code=200) {
        $row = array("MESSAGE" => $data, "STATUS_CODE" => $code);
        $this->response($row, 200);
    }
    
    function send_fail($msg,$code=202) {
        $row = array("MESSAGE" => $msg, "STATUS_CODE" => $code);
        $this->response($row, 201);
    }
	
	// Only for FB login WS
	function send_fail_fblogin($msg,$code=203) {
        $row = array("MESSAGE" => $msg, "STATUS_CODE" => $code);
        $this->response($row, 203);
    }

    //Created By : ID on 06-04-2017
    //Created for : Forgot Password
    public function forgotPassword_post()
    {
        $postData=$this->post();
        if(checkparams($postData,array('vEmail')))
        {
            extract($postData);
            if($vEmail == '') {
                $this->send_fail('Please provide Email');
            }
            $result=$this->user_model->forgotPassword($postData);
            
            if($result) {
                 $this->send_success_message('Email has been sent on your email address to reset your password');
            }
            else if($result == 0)  {
                $this->send_fail('Email not Available');
            }
            else {
                $this->send_fail('Unable to process!');
            }
        }
        else
        {
            $this->send_fail('Insufficient Data');
        }
    }

    function activate($id)
    {
        $id1    = base64_decode($id);
        if (is_numeric($id1)) 
        {
            $data   =   array(
                'id'    =>  $id1,
                'title' =>  'Reset Password'
            );
            $this->load->view('email/Reset_password_view',$data);
        } else {
            redirect();
        }
    }

    /*
    | -------------------------------------------------------------------
    |  RESET PASSWORD
    | -------------------------------------------------------------------
    */
    function reset_pass()
    {
        echo "Dfgfdsd";
        exit;
        mprd($this->input->post());
    }

}
/* End of file admin.php */