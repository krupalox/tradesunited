<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');
class Main extends REST_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	}


	function register_post()
	{
		$postData = $this->post();
		if (validateInputData($postData,array('email','password'))){
			mpr($postData);
		}
		else
		{
			$row = array("SUCCESS" =>'0',"MESSAGE"=>"Insufficient Data");
			$this->response($row, 200);
		}
	}








}