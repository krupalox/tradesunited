<?php
 /**
 * In this case, we want to increase the default cost for BCRYPT to 12.
 * Note that we also switched to BCRYPT, which will always be 60 characters.
 */
 
/*echo password_hash('krupal', PASSWORD_DEFAULT)."<br>";

echo password_hash("krupal", PASSWORD_BCRYPT)."<br>";
 
echo password_hash("krupal", PASSWORD_BCRYPT, array("cost" => 10))."<br>";
*/

$options = [
    'cost' => 11,
    'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
];
echo password_hash("krupal", PASSWORD_BCRYPT, $options)."<br>";

 
$hash = '$2y$15$D.NXw84RINdCTrkX4NmjDuJvNu6ykKDPWNawbfHjoXPVQ9IyXOBfS';

if (password_verify('krupal', $hash)) {
    echo 'Password is valid!';
} else {
    echo 'Invalid password.';
}


echo $_SERVER['REQUEST_METHOD'];

?>
