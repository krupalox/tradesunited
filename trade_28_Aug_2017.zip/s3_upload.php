<?php 
 
include_once("S3.php");
//arn:aws:s3:::tradesunited
$allowed = array('png' ,'jpg','jpeg','bmp','JPG','PNG','JPEG','BMP');
 $c = 0;
 $s3 = new S3('AKIAIJGBV3GKLZLTPVYA', 'qibHb0Rut8pxa0TLA8lkTRorP0utXnIoK3cWuJu4');


 
	/* $name = $files['name'][$i];
	 if(!empty($name)) 
	 {*/
		 /*$fileseg = explode('.', $name);
		 foreach ($fileseg as $key => $value) {
			 if(in_array($value, $allowed)){
				 $newimgname = rand().time().'.'.$value;
			 }
		 }*/
		 $targetpath_original = 'http://www.solxcell.com/tradesunite/images/user/1494498575_59143d0fa5f36.jpg';
		 $targetpath_thumb = 'http://www.solxcell.com/tradesunite/images/user/thumb/1494498575_59143d0fa5f36.jpg';
		 
		 $newimgname = "test.jpg";
		 define('USER_ORIGINAL', $_SERVER['DOCUMENT_ROOT'].'/tradesunite/images/user/');

		// move_uploaded_file($files['tmp_name'],USER_ORIGINAL.$newimgname);
		 $contentType = $files['type'][$i];
		 $tempArr = array();
		 //$s3->putObjectFile(DEAL_ORIGINAL.$newimgname, BUCKET_S3, $targetpath_original, S3::ACL_PUBLIC_READ, $tempArr, $contentType);
		 //$this->user_model->createThumbs($newimgname,USER_ORIGINAL,DEAL_THUMB);
		 $s3->putObjectFile($targetpath_thumb, 'tradesunited', $targetpath_thumb, S3::ACL_PUBLIC_READ, $tempArr, $contentType);
		 /*if(file_exists(DEAL_THUMB.$newimgname) && file_exists(USER_ORIGINAL.$newimgname)) {
			 unlink(DEAL_THUMB.$newimgname);
			 unlink(DEAL_ORIGINAL.$newimgname);
		 }*/

		 $insertArr['iDealID'] = $iDealID;
		 $insertArr['vImage'] = $newimgname;
		 $insertArr['dtCreated'] = date('Y-m-d H:i:s');
		 $addmultiple = $this->addDealImgs($insertArr);
	// }
// }
 


/* for ($i = 0; $i < count($files['name']); $i++)
 {
	 echo $i;
	 $c++;
	 $name = $files['name'][$i];
	 if(!empty($name)) 
	 {
		 $fileseg = explode('.', $name);
		 foreach ($fileseg as $key => $value) {
			 if(in_array($value, $allowed)){
				 $newimgname = rand().time().'.'.$value;
			 }
		 }
		 $targetpath_original = 'deal/'.$newimgname;
		 $targetpath_thumb = 'deal/thumb/'.$newimgname;
		 $newimgname = str_replace(" ", '_',$newimgname);
		 move_uploaded_file($files['tmp_name'][$i],DEAL_ORIGINAL.$newimgname);
		 $contentType = $files['type'][$i];
		 $tempArr = array();
		 $s3->putObjectFile(DEAL_ORIGINAL.$newimgname, BUCKET_S3, $targetpath_original, S3::ACL_PUBLIC_READ, $tempArr, $contentType);
		 $this->user_model->createThumbs($newimgname,DEAL_ORIGINAL,DEAL_THUMB);
		 $s3->putObjectFile(DEAL_THUMB.$newimgname, BUCKET_S3, $targetpath_thumb, S3::ACL_PUBLIC_READ, $tempArr, $contentType);
		 if(file_exists(DEAL_THUMB.$newimgname) && file_exists(DEAL_ORIGINAL.$newimgname)) {
			 unlink(DEAL_THUMB.$newimgname);
			 unlink(DEAL_ORIGINAL.$newimgname);
		 }

		 $insertArr['iDealID'] = $iDealID;
		 $insertArr['vImage'] = $newimgname;
		 $insertArr['dtCreated'] = date('Y-m-d H:i:s');
		 $addmultiple = $this->addDealImgs($insertArr);
	 }
 }*/

?>